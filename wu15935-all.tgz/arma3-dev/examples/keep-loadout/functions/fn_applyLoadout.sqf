// TAG_fnc_applyLoadout
// 运行端：请求方的客户端（服务端 remoteExec 回传过来）
// 用途：把服务端回传的 loadout 应用到玩家身上
// 参数：[玩家UID(string), loadout(array)]

params [
    ["_uid", "", [""]],
    ["_loadout", [], [[]]]
];

// 只在本人机上执行：UID 匹配且目标玩家存活
if (_uid isEqualTo "") exitWith {};
if (_uid != getPlayerUID player) exitWith {};
if (_loadout isEqualTo []) exitWith {};

player setUnitLoadout _loadout;