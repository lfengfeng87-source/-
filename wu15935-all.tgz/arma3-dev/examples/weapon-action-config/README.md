# weapon-action-config — CfgWeapons 武器动作字段参考（学习样例）

演示 Arma 3 自定义武器在 `CfgWeapons` 里**枪口 / 换弹 / 切枪 / 瞄准**四类动作相关字段的规范写法。这是对照原版武器 pbo（`\A3\weapons_f` 内 rifle/machine gun 的 config.bin）逐字段核对的骨架，不含可用模型/动画资源，只做配置结构参考。

## 核心约定：枪口/弹壳靠 memory 点，不靠 config 坐标

Arma 3 里枪口、弹壳、弹匣插入位置**不是**用 config 写坐标，而是由**模型 memory LOD 的 memory 点**驱动。config 只写挂点名（字符串），引擎按名字到模型里找投影：

| config 字段 | 对应模型 memory 点 | 作用 |
|------|------|------|
| `muzzlePos` | `muzzle` | 弹道起点（子弹从哪射出） |
| `muzzleEnd` | `muzzle_end` | 可选，弹道终点 |
| `ejectionPort` | `eject` | 弹壳抛出点 |
| `reloadMagazinePos` | `magazine_point` | 弹匣插入点 |
| `muzzleFlash`（ammo 侧） | `muzzleFlash` | 火光/烟雾特效挂点 |

**坑**：模型里缺某个点，引擎就回退到模型原点——开火从枪托冒火、弹匣从地面插，是武器 mod 最高频问题。核对时先用工具（Oxygen/Mikero 的 p3d 查看器）确认这些 memory 点是否存在、命名是否与 config 完全一致（大小写敏感）。

## 四类字段对照

### 1. 枪口（muzzle + flash）
- `muzzlePos` / `muzzleEnd`：弹道起点与终点 memory 点。
- `muzzleFlash`：开火特效/音效，配在 **ammo 的 `CfgAmmo>>muzzleFlash`** 类（引用 `\A3\data_f\...` 的特效），武器侧只需把 `muzzleFlash` memory 点挂上。特效时长建议略短于射速间隔，避免连续射击火光糊成白团。

### 2. 换弹（reload）
- `reloadMagazinePos`：弹匣插入点 memory 点。
- `reloadMagazineAnim`：换弹动画名（模型动画源）。
- `reloadAction`：换弹动作类（CfgMoves / CfgGestures 里的动作）。
- 换弹关键在**动画事件帧与补弹时机对齐**：动画播到"弹匣到位"那一帧触发补弹逻辑；空仓时用备用弹药量判定，为 0 播放空仓音效并中断换弹。

### 3. 切枪（slots / actions）
- `WeaponSlotsInfo`：附件槽（MuzzleSlot/CowsSlot/PointerSlot）用 `linkProxy` 引用官方 proxy 规范。
- 切枪动作走 `animClass`/枪挂载点，配合 CfgMoves 的 weaponState 状态。

### 4. 瞄准（optics）
- `opticsModel`：安装的瞄具模型。
- `OpticsModes`：准星/倍率/缩放，`memoryPointCamera` 定义瞄具后准星对齐点。
- 姿势/瞄准动画配在 CfgMoves，配合 `memoryPointCamera` 对齐瞄具视线。

## 与相关经验库条目的关联

- `CfgGestures` 手势动画挂载结构（lessons.md 2026-10-25）
- `CfgWeapons` 武器动作模块（lessons.md 2026-10-25）
- `动画 config 三坑`（lessons.md 2026-10-22，CfgMoves 继承链/sleep 执行上下文）

## 备注
本样例为**配置结构参考**，非可编译 addon。BI 官方 wiki 反爬不可直读，字段以社区实战 + 领域整理为准，仍以原版 pbo 内 config.bin 为权威出处（对照 `\A3\weapons_f\rifles\MX\config.bin` 可逐字段核对）。