// =============================================================
//  attachment-optics-config — 附件槽位 + 瞄具 optics 参考（学习样例）
// -------------------------------------------------------------
//  演示 Arma 3 附件体系的三件事：
//   1) 槽位系统 WeaponSlotsInfo / compatibleItems（附件为何"装不上"）
//   2) 瞄具 optic 类：ItemCore → ItemInfo → OpticsModes
//   3) 消音器 / 侧挂附件的 ItemInfo 系数
//  不含可用模型资源，仅作配置结构参考。
// =============================================================

class CfgPatches
{
    class TAG_Attachments
    {
        units[] = {};
        weapons[] = {"TAG_optic_1x", "TAG_suppressor_65", "TAG_pointer_IR"};
        requiredVersion = 1.96;
        requiredAddons[] = {"A3_Weapons_F", "A3_Weapons_F_Mark_Acc"};
    };
};

class CfgWeapons
{
    // ---------- 父类声明（原版已有，重定义只为继承） ----------
    class ItemCore;
    class InventoryOpticsItem_Base_F;
    class InventoryMuzzleItem_Base_F;
    class InventoryFlashLightItem_Base_F;
    class Rifle_Base_F;
    class SlotInfo;

    // =========================================================
    // 一、槽位系统
    // ---------------------------------------------------------
    // 附件可装 = 两道门：
    //   门1：武器 WeaponSlotsInfo 里的槽类有正确的 linkProxy
    //        （MUZZLE / TOP / SIDE / UNDERBARREL 模型代理）
    //   门2：附件类名在该槽的 compatibleItems 里
    // 缺门2 → 游戏内报 "is not compatible with the weapon"，附件做出来也装不上。
    //
    // 注意：CowsSlot / PointerSlot 是 CfgWeapons 根下的全局槽类（全游戏一份），
    //       在此重写 = 对所有武器同时生效（CBA Joint Rails 的 asdg_* 就是这么做的）。
    // =========================================================

    // 全局槽类覆盖示例：给 PointerSlot 追加本 mod 的 IR 激光
    class PointerSlot : SlotInfo
    {
        linkProxy = "\A3\data_f\proxies\weapon_slots\SIDE";
        displayName = "$STR_A3_PointerSlot0";
        compatibleItems[] = {"acc_flashlight", "acc_pointer_IR", "TAG_pointer_IR"};
    };

    // 等价类表写法（compatibleItems { 名字 = 1; }），=0 删除继承条目：
    // class CowsSlot : SlotInfo
    // {
    //     linkProxy = "\A3\data_f\proxies\weapon_slots\TOP";
    //     displayName = "$STR_A3_CowsSlot0";
    //     class compatibleItems
    //     {
    //         optic_Arco = 1;
    //         optic_ACO_grn = 1;
    //         optic_DMS = 0;      // 从父类列表里删掉 DMS
    //         TAG_optic_1x = 1;
    //     };
    // };

    // ---------- 武器侧：声明自己的槽（引用全局槽类） ----------
    class TAG_rifle_attachments : Rifle_Base_F
    {
        scope = 1;
        displayName = "TAG Rifle (attachments demo)";
        author = "TAG";

        // 消音器音效：sounds[] 索引由消音器的 soundTypeIndex 选择
        sounds[] = {"StandardSound", "SilencedSound"};
        class StandardSound { begin1[] = {""}; };
        class SilencedSound  { begin1[] = {""}; };

        class WeaponSlotsInfo
        {
            mass = 80;
            allowedSlots[] = {901};             // 库存槽（背包），不是附件槽！

            class CowsSlot : CowsSlot {};       // 引用全局槽类（TOP 导轨）
            class PointerSlot : PointerSlot {}; // 引用全局槽类（SIDE 导轨）

            class MuzzleSlot : SlotInfo
            {
                linkProxy = "\A3\data_f\proxies\weapon_slots\MUZZLE";
                compatibleItems[] = {"TAG_suppressor_65"};
            };
        };
    };

    // =========================================================
    // 二、瞄具 optic 类（装到 CowsSlot）
    // ---------------------------------------------------------
    // 结构：ItemCore → class ItemInfo : InventoryOpticsItem_Base_F → class OpticsModes
    // 类上的关键参数：
    //   scope           = 2（0/1 会不进 VA/Eden、游戏里不可见）
    //   weaponInfoType  引用 RscInGameUI 界面类，决定调零/测距 UI
    //   modelOptics     2D 准星贴图模型（开镜画面）
    // =========================================================
    class TAG_optic_1x : ItemCore
    {
        scope = 2;
        displayName = "TAG 1x Optic";
        author = "TAG";
        model = "\A3\weapons_f\acc\acco2_2d.p3d";      // 占位
        picture = "\A3\weapons_f\data\UI\gear_accv_01_ca.paa";
        weaponInfoType = "RscWeaponZeroing";            // 有倍率/测距需求时改 RscWeaponRangeZeroingFOV
        descriptionShort = "1x 分划瞄具（学习样例）";

        class ItemInfo : InventoryOpticsItem_Base_F
        {
            mass = 10;
            modelOptics = "\A3\weapons_f\acc\reticle_acco.p3d";
            allowedSlots[] = {801, 701, 901};    // 库存槽（制服/背心/背包），非附件槽
            opticType = 1;                      // 平衡参数（影响 AI/重量平衡）
            mountAction = "MountOptic";
            unmountAction = "DismountOptic";

            class OpticsModes
            {
                // 模式1：纯 FOV 机械瞄具（折叠机瞄/常开）
                class Iron
                {
                    opticsID = 1;
                    useModelOptics = 0;
                    opticsPPEffects[] = {};
                    opticsZoomMin = 0.375;
                    opticsZoomMax = 1.1;
                    discreteDistance[] = {100, 200, 300};
                    discreteDistanceInitIndex = 0;
                    memoryPointCamera = "eye";
                    visionMode[] = {"Normal"};
                    opticsFlare = 0;
                    opticsDisablePeripherialVision = 0;
                    cameraDir = "";
                };
                // 模式2：红点（2D 贴图，不遮挡视野）
                class Collimator
                {
                    opticsID = 2;
                    useModelOptics = 1;
                    opticsPPEffects[] = {};
                    opticsZoomMin = 0.5;
                    opticsZoomMax = 0.5;
                    discreteDistance[] = {100, 200};
                    discreteDistanceInitIndex = 0;
                    memoryPointCamera = "opticView";
                    modelOptics[] = {"\A3\weapons_f\acc\reticle_acco.p3d"};
                    visionMode[] = {"Normal"};
                    opticsFlare = 1;
                    opticsDisablePeripherialVision = 0;
                    cameraDir = "";
                };
            };
        };
    };

    // 多级变倍 + 夜视模式（SOS 风格，光学后处理 + 双倍镜）：
    // class Zoom
    // {
    //     opticsID = 3;
    //     useModelOptics = 1;
    //     opticsZoomMin = 0.10;        // 放大倍率高 → 数值小
    //     opticsZoomMax = 0.25;
    //     opticsZoomInit = 0.25;
    //     discreteDistance[] = {100, 200, 300, 400, 500, 600, 800, 1000};
    //     discreteDistanceInitIndex = 2;
    //     memoryPointCamera = "opticView";
    //     modelOptics[] = {"\A3\Weapons_F_Mark\Acc\reticle_SOS.p3d"};
    //     visionMode[] = {"Normal", "NVG"};            // 要夜视就加 NVG
    //     opticsPPEffects[] = {"OpticsCHAbera1", "OpticsBlur1"};
    // };

    // 继承原版瞄具改夜视（论坛实战写法，注意替代整段 OpticsModes）：
    // class TAG_optic_AMS_nv : optic_AMS
    // {
    //     scope = 2;
    //     class ItemInfo : ItemInfo
    //     {
    //         class OpticsModes : OpticsModes
    //         {
    //             class AMS
    //             {
    //                 visionMode[] = {"Normal", "NVG"};   // 原版 AMS 不支持 NVG
    //             };
    //         };
    //     };
    // };

    // =========================================================
    // 三、消音器（装到 MuzzleSlot）
    // ---------------------------------------------------------
    // 消音器不是"改音效"，而是通过 ItemInfo 三类系数改写发射行为：
    //   MagazineCoef{initSpeed}  初速
    //   AmmoCoef{hit, visibleFire, audibleFire, cost, typicalSpeed, airFriction}
    //        —— 可见/可听程度（AI 侦测核心）、命中、弹道
    //   MuzzleCoef{dispersionCoef, recoilCoef, min/mid/maxRangeCoef}
    //        —— 散布、后坐、射程
    // soundTypeIndex 选武器 sounds[] 索引（0 = 无消音器，1 = SilencedSound）
    // =========================================================
    class TAG_suppressor_65 : ItemCore
    {
        scope = 2;
        displayName = "TAG 6.5mm Suppressor";
        author = "TAG";
        model = "\A3\weapons_f\acc\muzzle_snds.p3d";
        picture = "\A3\weapons_f\data\UI\gear_muzzle_snds_ca.paa";

        class ItemInfo : InventoryMuzzleItem_Base_F
        {
            mass = 12;
            class MagazineCoef { initSpeed = 0.95; };
            class AmmoCoef
            {
                hit = 0.9;
                visibleFire = 0.5;          // 火光可见度（乘算）
                audibleFire = 0.4;          // 枪声可听度（AI 侦测关键）
                visibleFireTime = 3;
                audibleFireTime = 3;
                cost = 3;
                typicalSpeed = 0.95;
                airFriction = 1;
            };
            class MuzzleCoef
            {
                dispersionCoef = 0.9;
                artilleryDispersionCoef = 1;
                fireLightCoef = 0.1;        // 枪口火光强度
                recoilCoef = 0.8;
                recoilProneCoef = 0.7;
                minRangeCoef = 1;
                midRangeCoef = 1;
                maxRangeCoef = 0.9;
            };
            soundTypeIndex = 1;             // → 武器的 sounds[1] = "SilencedSound"
        };
    };

    // =========================================================
    // 四、侧挂附件（装到 PointerSlot）：战术手电 / IR 激光
    // ---------------------------------------------------------
    // ItemInfo 基类 InventoryFlashLightItem_Base_F；
    // class Pointer 的内部 memory 点（irLaserPos / irLaserEnd）决定激光
    // 从模型哪里射出、指向哪里；class FlashLight 为空表示只发光不投影。
    // =========================================================
    class TAG_pointer_IR : ItemCore
    {
        scope = 2;
        displayName = "TAG IR Laser";
        author = "TAG";
        model = "\A3\weapons_f\acc\acc_pointer_IR.p3d";
        picture = "\A3\weapons_f\data\UI\gear_accv_pointer_ca.paa";

        class ItemInfo : InventoryFlashLightItem_Base_F
        {
            mass = 4;
            class Pointer
            {
                irLaserPos = "laser_pos";
                irLaserEnd = "laser_dir";
            };
            class FlashLight {};
        };
    };
};

// =============================================================
// 脚本侧查兼容附件（论坛 182939 证实）：
//   getArray (configFile >> "CfgWeapons" >> _typeName
//             >> "WeaponSlotsInfo" >> "CowsSlot" >> "compatibleitems")
// 注意类名 WeaponSlotsInfo 带复数 s；槽名 CowsSlot 单数。
// =============================================================
