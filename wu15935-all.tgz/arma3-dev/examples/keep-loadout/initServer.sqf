// 运行端：仅服务端（专用服务器或单人主机），任务开始执行一次
// 职责：初始化跨机/跨重生/JIP 共享的 loadout 存储。
// 存储为 missionNamespace 变量 TAG_loadoutData，元素 [UID, loadout]，服务端权威。
// 客户端通过 TAG_fnc_setLoadout（写入）与 TAG_fnc_getLoadout（回读）读写，见 functions/。

if (!isServer) exitWith {};

// 若任务重载或首次执行，确保数组已分配
if (isNil { missionNamespace getVariable "TAG_loadoutData" }) then {
    missionNamespace setVariable ["TAG_loadoutData", [], true];
};