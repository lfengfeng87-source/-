# skill-framework — 可动态扩展的自进化技能系统

参照 arma3-dev 技能的自进化模式（读经验库 → 执行 → 自检 → 写回）抽象出的通用框架。**系统不写死任何领域内容，技能、清单、经验库都可以随时添加，无需改系统代码。**

## 设计原则

1. **发现代替注册**：`sks list` 在运行时扫描 `skills/*/SKILL.md`，往 `skills/` 丢新技能即被系统自动发现，没有硬编码清单。
2. **模板化脚手架**：`sks new` 用占位符模板生成技能骨架，领域逻辑只在生成后的技能文件里写，模板本身与领域无关。
3. **共享清单**：跨领域通用自检项集中在 `checks/`，改动一次，所有引用技能受益。
4. **自我进化**：每个技能自带 `lessons.md` 经验库，任务后写回踩坑，随使用持续变强。

## 目录结构

```
skill-framework/
├── sks                 # CLI 主入口
├── lib/                # 实现（scaffold 脚手架 / registry 动态发现）
├── template/           # 通用技能模板（占位符 {{NAME}} 等，领域无关）
├── checks/             # 跨领域通用自检清单（可增删）
└── skills/             # 技能容器：放任意技能，零注册自动发现
```

## 用法

```bash
# 动态添加一个新技能（任何领域）
./sks new sql-tips "SQL 查询优化与审查技能" "sql, query, index"

# 运行时发现全部技能（自动包含新增）
./sks list

# 查看某技能的自检清单 + 经验库
./sks check sql-tips

# 查看技能正文
./sks details sql-tips
```

## 随时添加内容的方式

| 想加什么 | 怎么做 | 是否改系统代码 |
|----------|--------|----------------|
| 新技能（新领域） | `./sks new <名> <描述> [关键词]`，或直接在 `skills/<名>/` 手写 SKILL.md | 否，自动发现 |
| 技能专属经验 | 编辑 `skills/<名>/lessons.md` | 否 |
| 跨领域通用自检项 | 编辑 `checks/common-checklists.md` | 否，共享生效 |
| 技能深度资料 | 在技能目录建 `references/` 子目录 | 否 |
| 模板缺的章节 | 编辑 `template/SKILL_TEMPLATE.md` | 影响后续新建技能 |

## 集成 opencode

生成的技能是标准 opencode 技能（frontmatter 含 name/description），把 `skills/<名>/` 复制进项目的 `.opencode/skills/` 即可被 opencode 自动加载；本系统负责生成、发现与维护。

## 依赖

仅需 bash（含 sed/grep），无第三方依赖。