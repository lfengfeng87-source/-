// IG5 数据工具车道驱动脚本 —— 不依赖静态引擎(linux-arm64)
// 直接 import IG5 插件的数据工具核心函数，对构造样本做真实分析与密钥恢复
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const here = dirname(fileURLToPath(import.meta.url));
const PLUGIN = '/root/projects/.dsh/profiles/web/node_modules/dsh-infinite-gen-5';
const SAMPLES = join(here, 'samples');

const { analyzeCrypto, CRYPTO_LIMITS } = await import(join(PLUGIN, 'source/crypto_analysis.js'));
const { analyzeProtocol } = await import(join(PLUGIN, 'source/protocol_analysis.js'));
const { analyzeProtocolState } = await import(join(PLUGIN, 'source/protocol_state.js'));

const bin = name => readFileSync(join(SAMPLES, name));
const hex = data => ({ encoding: 'hex', data: Buffer.isBuffer(data) ? data.toString('hex') : data });
const b64 = data => ({ encoding: 'base64', data: Buffer.isBuffer(data) ? data.toString('base64') : data });
const line = s => console.log('  ' + s);
const hr = () => console.log('='.repeat(70));

hr();
console.log('【1】ig5_crypto op=inspect —— 分析 XOR 单字节样本 (真实密钥 0x7F)');
hr();
{
  const r = analyzeCrypto({ op: 'inspect', input: hex(bin('sample_xor_single.bin')) });
  const a = r.result.analysis;
  line(`schema=${r.result.schema}  range=${JSON.stringify(r.result.range)}`);
  line(`entropy_bits_per_byte=${a.entropy_bits_per_byte.toFixed(3)}  (可打印文本~4.0-5.3, 高熵随机~7.9+)`);
  line(`printable_ascii_fraction=${a.printable_ascii_fraction.toFixed(3)}`);
  line(`valid_utf8=${a.valid_utf8}  zero_bytes=${a.zero_bytes}  distinct_bytes=${a.distinct_bytes}`);
  line(`interpretation=${a.interpretation}`);
  line(`verification=${JSON.stringify(r.result.verification)}`);
}

hr();
console.log('【2】ig5_crypto op=recover method=xor-single —— 自动恢复 XOR 单字节密钥');
hr();
{
  const r = analyzeCrypto({ op: 'recover', input: hex(bin('sample_xor_single.bin')), recovery: { method: 'xor-single' } });
  const rec = r.result.recovery;
  const c = rec.candidates[0];
  line(`status=${rec.status}  method=${rec.method}  trials=${rec.trials}  work_bytes=${rec.work_bytes}`);
  line(`★ 恢复密钥(单字节)=0x${c.keyMaterial.dataHex}  → 真实=0x7F  ${c.keyMaterial.dataHex==='7f'?'✓ 完全匹配':'✗'}`);
  line(`keyComplete=${c.keyComplete}  score=${c.score.toFixed(4)}  verification=${c.verification}`);
  line(`明文sha256=${c.plaintext.sha256}`);
  line(`明文预览=${Buffer.from(c.plaintext.dataHex,'hex').toString('utf8').slice(0,80)}...`);
}

hr();
console.log('【3】ig5_crypto op=recover method=xor-repeat —— 自动恢复 XOR 重复密钥 "ABC9"');
hr();
{
  const r = analyzeCrypto({ op: 'recover', input: hex(bin('sample_xor_repeat.bin')), recovery: { method: 'xor-repeat', key_lengths: [2,3,4,5,6,7,8] } });
  const rec = r.result.recovery;
  const c = rec.candidates[0];
  const key = Buffer.from(c.keyMaterial.dataHex,'hex').toString('latin1');
  line(`status=${rec.status}  method=${rec.method}  trials=${rec.trials}  work_bytes=${rec.work_bytes}`);
  line(`★ 恢复重复密钥="${key}" (${c.key_bytes}字节, hex=${c.keyMaterial.dataHex})  → 真实="ABC9"  ${key==='ABC9'?'✓ 完全匹配':'✗'}`);
  line(`normalized_hamming=${JSON.stringify(c.evidence.find(e=>e.kind==='repeating-xor-statistics')?.normalized_hamming)}`);
  line(`score=${c.score.toFixed(4)}  verification=${c.verification}  plaintext_len=${c.plaintext.length}`);
}

hr();
console.log('【4】ig5_crypto op=transform recipe=xor —— 用恢复的密钥 "ABC9" 解密 XOR repeat 样本');
hr();
{
  const key = Buffer.from('ABC9','latin1');
  const r = analyzeCrypto({ op: 'transform', input: hex(bin('sample_xor_repeat.bin')), recipe: { kind: 'xor', key: hex(key) } });
  const out = r.output || r.result.output;
  const plain = Buffer.isBuffer(out) ? out.toString('utf8') : '';
  line(`recipe=${JSON.stringify(r.result.recipe)}  authentication=${JSON.stringify(r.result.authentication)}`);
  line(`★ 解密明文(前120): ${plain.slice(0,120)}`);
  line(`明文匹配原文: ${plain.startsWith('This is a confidential') ? '✓' : '✗'}`);
}

hr();
console.log('【5】ig5_crypto op=transform recipe=aes-cbc —— AES-256-CBC 解密 (key=0011...eeff)');
hr();
{
  const key = Buffer.from('00112233445566778899aabbccddeeff00112233445566778899aabbccddeeff','hex');
  const iv = Buffer.from('0123456789abcdeffedcba9876543210','hex');
  const r = analyzeCrypto({ op: 'transform', input: hex(bin('sample_aes_cbc.bin')), recipe: { kind: 'aes-cbc', key: hex(key), iv: hex(iv), padding: 'pkcs7' } });
  const out = r.output || r.result.output;
  const plain = Buffer.isBuffer(out) ? out.toString('utf8') : '';
  line(`recipe=${JSON.stringify(r.result.recipe)}  verification=${JSON.stringify(r.result.verification)}`);
  line(`★ AES-CBC 解密明文(前100): ${plain.slice(0,100)}`);
  line(`明文匹配原文: ${plain.startsWith('This is a confidential') ? '✓' : '✗'}`);
}

hr();
console.log('【6】ig5_crypto op=recover method=aes-candidates —— AES-256-GCM 候选密钥校验(GCM tag认证)');
hr();
{
  const keyCand = hex(Buffer.from('00112233445566778899aabbccddeeff00112233445566778899aabbccddeeff','hex'));
  const r = analyzeCrypto({
    op: 'recover',
    input: hex(bin('sample_aes_gcm.bin')),
    recovery: {
      method: 'aes-candidates',
      key_candidates: [keyCand],
      aes: { kind: 'aes-gcm', iv: hex(bin('sample_aes_gcm.iv.bin')), tag: hex(bin('sample_aes_gcm.tag.bin')), aad: hex(Buffer.from('sample-aes-gcm-context','utf8')), padding: 'none' },
    },
  });
  const rec = r.result.recovery;
  const c = rec.candidates && rec.candidates[0];
  line(`status=${rec.status}  method=${rec.method}  trials=${rec.trials}  rejected=${rec.rejected}`);
  line(`★ AES-GCM 认证: ${r.result.authentication?.status}  → ${r.result.authentication?.status==='passed' ? '✓ 候选密钥正确 + GCM tag 16B 校验通过' : '✗'}`);
  if (c) line(`验证=${c.verification}  plaintext_sha256=${c.plaintext.sha256}`);
  line(`明文预览=${c ? Buffer.from(c.plaintext.dataHex,'hex').toString('utf8').slice(0,60)+'...' : '—'}`);
}

hr();
console.log('【7】ig5_protocol op=inspect —— 解析自定义 length-prefixed 报文 (IG5P|type|flags|len|payload)');
hr();
{
  const msg = Buffer.concat([
    Buffer.from('IG5P','latin1'), Buffer.from([0x01,0x00]),
    (()=>{const b=Buffer.alloc(2);b.writeUInt16BE(8);return b;})(),
    Buffer.from('HELLO-42','latin1'),
  ]);
  const r = analyzeProtocol({ action: 'inspect', data: msg.toString('hex'), encoding: 'hex' });
  const ks = Object.keys(r);
  line(`返回 keys: ${ks.join(', ')}`);
  line(`entropyBitsPerByte=${r.entropyBitsPerByte?.toFixed?.(3) ?? r.entropyBitsPerByte}`);
  if (r.observations && r.observations.length) {
    line(`observations(${r.observations.length}):`);
    for (const o of r.observations.slice(0,6)) line(`  · ${JSON.stringify(o)}`);
  }
  if (r.strings && r.strings.length) line(`strings: ${JSON.stringify(r.strings.slice(0,4))}`);
  if (r.interpretation) line(`interpretation: ${r.interpretation}`);
}

hr();
console.log('【8】ig5_protocol state_infer —— 观察状态机建模 (LOGIN/OK/QUERY/DATA 会话)');
hr();
{
  const manifest = { version:1, traces:[
    { id:'t1', start:'session-start', complete:true, events:[
      { direction:'client_to_server', symbol:'LOGIN', sourceId:'a', complete:true },
      { direction:'server_to_client', symbol:'OK', sourceId:'b', complete:true },
      { direction:'client_to_server', symbol:'QUERY', sourceId:'a', complete:true },
      { direction:'server_to_client', symbol:'DATA', sourceId:'b', complete:true }]},
    { id:'t2', start:'session-start', complete:true, events:[
      { direction:'client_to_server', symbol:'LOGIN', sourceId:'a', complete:true },
      { direction:'server_to_client', symbol:'ERR', sourceId:'b', complete:true },
      { direction:'client_to_server', symbol:'QUERY', sourceId:'a', complete:true },
      { direction:'server_to_client', symbol:'DATA', sourceId:'b', complete:true }]},
  ]};
  const manifestJson = JSON.stringify(manifest);
  const r = analyzeProtocolState({ action: 'state_infer', data: Buffer.from(manifestJson,'utf8').toString('hex'), encoding: 'hex', state_model: { merge: 'future-equivalent' } });
  const state = r.state;
  const ks = Object.keys(state);
  line(`schema=${r.schemaVersion}  action=${r.action}`);
  line(`status=${state.status}  method=${state.method}`);
  line(`states=${state.observedModel ? state.observedModel.states.length : '—'}  coverage=${JSON.stringify(state.coverage)}`);
  line(`modelDigest=${state.modelDigest}`);
  line(`holdout_status=${state.holdout ? state.holdout.status : '—'}`);
  line(`ambiguity: stateSemanticsUnknown=${state.ambiguity.stateSemanticsUnknown}  closedWorld=${state.ambiguity.closedWorld}`);
  line(`budget: work=${state.budget.work}  traces=${state.budget.traceCount}  events=${state.budget.eventCount}`);
}

hr();
console.log('✅ 数据工具车道驱动完成 —— 无静态引擎环境下 IG5 crypto/protocol 核心函数全部可用');
console.log(`CRYPTO_LIMITS: inputBytes=${CRYPTO_LIMITS.inputBytes} outputBytes=${CRYPTO_LIMITS.outputBytes} maxKeyBytes=${CRYPTO_LIMITS.maxKeyBytes} maxTrials=${CRYPTO_LIMITS.maxTrials}`);