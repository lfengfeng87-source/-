// TAG_fnc_getLoadout
// 运行端：服务端（客户端 remoteExecCall 调过来请求）
// 用途：按 UID 查出玩家最后一次保存的 loadout，并回传给请求方
// 参数：[玩家UID(string), 目标客户端(数字)]
// 触发：onPlayerRespawn.sqf 重生时、initPlayerLocal.sqf JIP 加入时

params [
    ["_uid", "", [""]],
    ["_targetClient", 0, [0]]
];

if (!isServer) exitWith {};
if (_uid isEqualTo "") exitWith {};

private _data = missionNamespace getVariable ["TAG_loadoutData", []];

// 找到该 UID 的 loadout，回传给指定客户端；找不到则回传空数组
private _loadout = [];
private _idx = _data findIf { (_x select 0) == _uid };
if (_idx >= 0) then {
    _loadout = (_data select _idx) select 1;
};

[_uid, _loadout] remoteExec ["TAG_fnc_applyLoadout", _targetClient];