// TAG_fnc_setLoadout
// 运行端：服务端（客户端 remoteExec 调过来）
// 用途：把玩家的 loadout 按 UID 存入服务端映射 TAG_loadoutData
// 参数：[玩家UID(string), loadout(array)]
// 触发：客户端 Killed 事件、以及玩家主动保存装备时

params [
    ["_uid", "", [""]],
    ["_loadout", [], [[]]]
];

if (!isServer) exitWith {};
if (_uid isEqualTo "") exitWith {};

private _data = missionNamespace getVariable ["TAG_loadoutData", []];

// 按 UID 找到旧条目并替换，不存在则追加（避免数组无限膨胀）
private _idx = _data findIf { (_x select 0) == _uid };
if (_idx >= 0) then {
    _data set [_idx, [_uid, _loadout]];
} else {
    _data pushBack [_uid, _loadout];
};

missionNamespace setVariable ["TAG_loadoutData", _data, true];