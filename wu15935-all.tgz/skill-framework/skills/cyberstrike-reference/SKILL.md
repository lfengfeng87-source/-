---
name: cyberstrike-reference
description: CyberStrike 功能参考技能。触发关键词：cyberstrike, cs, 功能, 完整列表
---
# CyberStrike 功能参考

本技能由 skill-framework 生成。核心工作流：先读经验库 → 按规范执行 → 强制自检 → 新经验写回。系统不写死领域逻辑，本文件与同目录 lessons.md 均可在使用中随时补充。

## 0. 自我进化机制（每次任务必做）

**任务开始前**：读本目录 `lessons.md`，逐条对照历史经验，涉及的坑直接套用已验证修复。

**任务结束后**：过第 3 节自检清单，发现新问题立即写回 `lessons.md`：

```
[YYYY-MM-DD] 问题一句话描述
- 现象：
- 原因：
- 修复：
- 来源任务：<一句话>
```

写回前查重，同主题合并更新原条目（更新日期），保持文件精简。跳过写回等于技能退化。

## 1. 责任与范围

**负责**：
- CyberStrike 所有功能的概览与分类记录
- 命令行工具完整列表与语法记录
- TUI 界面与 CLI 映射关系
- 模型、会话、提供商等高级功能概览

**不做**：
- 不提供非法入侵或未授权测试的使用指南
- 不绕过组织安全政策或合规要求

**边界**：
- 仅记录官方提供的功能与命令
- 用户必须在授权的测试范围内使用 CyberStrike
- Token 使用和成本需自行监控

## 2. 功能完整列表

CyberStrike 提供以下 **23 个主要功能**（按官方帮助输出分类）：

| 编号 | 功能 | 简介 | 关键命令 |
|------|------|------|----------|
| 1 | TUI 界面 | 启动图形化终端界面 | `cyberstrike [project]` |
| 2 | 版本信息 | 查看当前版本 | `cyberstrike --version` |
| 3 | 帮助文档 | 显示完整帮助 | `cyberstrike --help` |
| 4 | 执行任务 | 运行 CyberStrike 并发送消息 | `cyberstrike run [message]` |
| 5 | Web 爬虫 | 爬取 Web 应用并分析 | `cyberstrike hackbrowser <target>` |
| 6 | 服务器连接 | 连接到运行中的服务器 | `cyberstrike attach <url>` |
| 7 | 调试工具 | 调试和故障排查 | `cyberstrike debug` |
| 8 | 凭据管理 | 管理凭据和配置 | `cyberstrike auth` |
| 9 | 智能体管理 | 管理 AI 智能体 | `cyberstrike agent` |
| 10 | 版本升级 | 升级到最新版本 | `cyberstrike upgrade [target]` |
| 11 | 卸载移除 | 卸载 CyberStrike | `cyberstrike uninstall` |
| 12 | 头less 服务器 | 启动无头服务器模式 | `cyberstrike serve` |
| 13 | Web 界面 | 启动 Web 界面 | `cyberstrike web` |
| 14 | AI 模型 | 列出可用 AI 模型 | `cyberstrike models [provider]` |
| 15 | Token 统计 | 显示 Token 使用与成本 | `cyberstrike stats` |
| 16 | 会话导出 | 导出会话数据为 JSON | `cyberstrike export [sessionID]` |
| 17 | 会话导入 | 从 JSON 导入会话数据 | `cyberstrike import <file>` |
| 18 | GitHub 代理 | 管理 GitHub 智能体 | `cyberstrike github` |
| 19 | Git PR | 获取并检出 GitHub PR | `cyberstrike pr <number>` |
| 20 | 会话管理 | 管理会话 | `cyberstrike session` |
| 21 | 提供商管理 | 管理 AI 提供商 | `cyberstrike provider` |
| 22 | 技能管理 | 管理 offensive skills | `cyberstrike skill` |
| 23 | Shell 补全 | 生成 Shell 补全脚本 | `cyberstrike completion` |

## 3. 子命令分类概览

### 3.1 auth 子命令
- `cyberstrike auth list` - 列出已保存的凭据
- `cyberstrike auth add` - 添加新凭据
- `cyberstrike auth remove` - 移除凭据

### 3.2 agent 子命令
- `cyberstrike agent list` - 列出已配置的智能体
- `cyberstrike agent add` - 添加新智能体

### 3.3 github 子命令
- `cyberstrike github list` - 列出 GitHub 代理
- `cyberstrike github create` - 创建新代理

### 3.4 session 子命令
- `cyberstrike session list` - 列出会话
- `cyberstrike session new` - 创建新会话
- `cyberstrike session continue` - 继续上次会话

### 3.5 provider 子命令
- `cyberstrike provider list` - 列出提供商
- `cyberstrike provider add` - 添加新提供商
- `cyberstrike provider remove` - 移除提供商

### 3.6 skill 子命令
- `cyberstrike skill list` - 列出技能
- `cyberstrike skill install` - 安装技能

## 4. 全局选项参考

| 选项 | 简介 | 格式/范围 | 默认值 |
|------|------|----------|--------|
| `-h, --help` | 显示帮助 | 无 | 无 |
| `-v, --version` | 显示版本 | 无 | 无 |
| `-m, --model` | AI 模型 | `provider/model` 格式 | 系统默认 |
| `-c, --continue` | 继续上次会话 | 布尔值 | false |
| `-s, --session` | 会话 ID | 字符串 | 无 |
| `--fork` | fork 会话 | 布尔值 | false |
| `--prompt` | 提示词 | 字符串 | 无 |
| `--agent` | 智能体 | 字符串 | 无 |
| `--print-logs` | 打印日志 | 布尔值 | false |
| `--log-level` | 日志级别 | "DEBUG"|"INFO"|"WARN"|"ERROR" | "INFO" |
| `--port` | 监听端口 | 1-65535 | 4096 |
| `--hostname` | 监听地址 | IPv4/IPv6 | "127.0.0.1" |
| `--mdns` | mDNS 发现 | 布尔值 | false |
| `--mdns-domain` | mDNS 域名 | 字符串 | "cyberstrike.local" |
| `--cors` | CORS 域名 | 字符串数组 | [] |

## 5. 快速功能对照表

| 使用场景 | 推荐命令 | 说明 |
|----------|----------|------|
| 启动 CyberStrike | `cyberstrike` | 默认 TUI 模式 |
| 指定项目目录 | `cyberstrike /path/to/project` | 在特定目录开始 |
| 继续上次会话 | `cyberstrike --continue` | 恢复工作状态 |
| 使用特定模型 | `cyberstrike -m openai/gpt-4o` | 使用 OpenAI GPT-4o |
| Web 界面模式 | `cyberstrike web` | 启动 Web 界面 |
| 服务器模式 | `cyberstrike serve` | 启动 headless 服务器 |
| 爬取 Web 应用 | `cyberstrike hackbrowser https://target.com` | Web 爬虫分析 |
| 管理凭据 | `cyberstrike auth` | 凭据管理子菜单 |
| 查看模型列表 | `cyberstrike models` | 列出所有 AI 模型 |
| 查看 Token 使用 | `cyberstrike stats` | Token 成本统计 |
| 导出会话数据 | `cyberstrike export` | JSON 格式导出 |
| 卸载 CyberStrike | `cyberstrike uninstall` | 完全卸载 |

## 6. 自检清单（每次产出后逐条过）

通用项：引用 `checks/common-checklists.md`（跨领域通用，系统维护，所有技能共享）。
本领域追加项：

- [ ] 所列出的 23 个功能是否与官方 `cyberstrike --help` 输出一致？
- [ ] 所有子命令是否已正确分类到对应父命令？
- [ ] 全局选项的参数格式是否符合官方文档规定？
- [ ] 是否标注了每个功能的默认值和有效范围？
- [ ] 是否区分了"功能概览"（本技能）与"具体使用操作"（命令行/ TUI）的边界，没有越权？

## 7. 快速参考

**常用功能启动**:
```
# TUI 模式 (默认)
cyberstrike

# Web 界面模式
cyberstrike web

# 服务器模式
cyberstrike serve

# 爬取 Web 应用
cyberstrike hackbrowser https://target.com

# 管理功能
cyberstrike auth      # 凭据管理
cyberstrike models    # 模型列表
cyberstrike stats     # Token 统计
```

**模型格式**: `provider/model`，常用示例：
- `openai/gpt-4o`, `openai/gpt-4-turbo`
- `anthropic/claude-3-opus`, `anthropic/claude-3-sonnet`
- `google/gemini-pro`, `google/gemini-1.5-flash`

## 8. 完成标准

产出后：过完第 3 节清单 + 新经验写回 lessons.md，才算完成。回复给出：改动文件清单、执行说明、自检结果。