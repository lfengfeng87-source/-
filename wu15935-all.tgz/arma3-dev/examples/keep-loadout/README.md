# keep-loadout — 重生保留装备（JIP 安全版）

演示 Arma 3 任务里"重生后保留武器/装备"的规范写法，重点展示 **locality 与 JIP 处理**。

## 相比简单写法的改进

最朴素的写法是 `Killed` 时把装备存到旧 body 变量、`onPlayerRespawn` 从旧 body 取回：

```
Killed 事件 → _unit setVariable ["loadout", getUnitLoadout _unit]   // 存旧body
onPlayerRespawn → _corpse getVariable "loadout"                       // 取回
```

这套在"当场死亡重生"时能用，但有 3 个缺陷：

| 缺陷 | 后果 |
|------|------|
| 装备存旧 body 上 | 依赖尸体留存，尸体清理/despawn 后丢失 |
| 无 JIP 覆盖 | 中途加入的玩家不走 onPlayerRespawn，永远拿不到装备 |
| 跨机器状态错位 | loadout 存本地 body 变量，多端场景状态混乱 |

本示例改为**服务端权威存储**（UID → loadout 映射），同时覆盖当场重生与 JIP。

## 架构

```
description.ext        respawn 设置 + CfgFunctions 注册
initServer.sqf         服务端：分配 missionNamespace 存储 TAG_loadoutData
initPlayerLocal.sqf    玩家本地：Killed 同步装备到服务端 + JIP 加入时主动拉取
onPlayerRespawn.sqf    重生玩家本地：按 UID 从服务端请求装备回传
functions/fn_setLoadout.sqf    TAG_fnc_setLoadout  服务端写入 UID→loadout
functions/fn_getLoadout.sqf    TAG_fnc_getLoadout  服务端查询并回传客户端
functions/fn_applyLoadout.sqf  TAG_fnc_applyLoadout 客户端应用装备到 player
```

## 数据流

**当场死亡重生：**
```
[Killed] 客户端 getUnitLoadout → remoteExecCall TAG_fnc_setLoadout(服务端2) → 存 UID→loadout
[onPlayerRespawn] remoteExecCall TAG_fnc_getLoadout(2) → 服务端查表 → remoteExec TAG_fnc_applyLoadout(本人)
→ 客户端 player setUnitLoadout
```

**JIP 中途加入：**
```
[didJIP] initPlayerLocal → remoteExecCall TAG_fnc_getLoadout(2) → 服务端查表 → 回传 applyLoadout
→ 客户端 player setUnitLoadout
（第一次玩、服务端无记录则回传空数组，applyLoadout 忽略，保留默认出生装备）
```

## 执行端对照

| 文件 | 运行端 |
|------|--------|
| initServer.sqf | 仅服务端 |
| initPlayerLocal.sqf | 每个玩家本地 |
| onPlayerRespawn.sqf | 重生玩家本地 |
| fn_setLoadout.sqf | 服务端（客户端 remoteExec 触发） |
| fn_getLoadout.sqf | 服务端（客户端 remoteExec 触发） |
| fn_applyLoadout.sqf | 目标玩家客户端 |

## 自检清单核对

- [x] 执行端正确：每个脚本块均有明确执行端与守卫
- [x] JIP 覆盖：`didJIP` 分支主动拉取，弥补 onPlayerRespawn 缺失
- [x] 调度安全：无 sleep/waitUntil/while
- [x] 无废弃 API：全部 remoteExec/remoteExecCall，无 BIS_fnc_MP
- [x] 变量卫生：全 params/private，跨端状态用 missionNamespace 显式声明
- [x] 远程目标正确：写服务端(2)，读回传指定客户端
- [x] 错误兜底：UID 空检查、空 loadout 忽略、isServer 守卫

## 运行方式

把本目录 6 个 .sqf + description.ext 作为任务包根目录内容（与 mission.sqm 同层），进任务后击杀/死亡重生、或中途加入即可验证装备保留。