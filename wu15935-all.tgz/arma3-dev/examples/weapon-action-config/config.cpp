// =============================================================
//  weapon-action-config — CfgWeapons 武器动作字段参考（学习样例）
// -------------------------------------------------------------
//  演示自定义武器里"枪口 / 换弹 / 切枪 / 瞄准"四类动作相关字段。
//  这是可对照原版武器 pbo 逐字段核对的骨架，不含可用模型/动画资源。
//  关键约定：枪口、弹壳位置由 模型 memory LOD 的 memory 点 驱动，
//  config 只写挂点名，模型里必须有同名投影否则回退到模型原点。
// =============================================================

class CfgPatches
{
    class TAG_Weapons
    {
        units[] = {};
        weapons[] = {"TAG_rifle_F"};
        requiredVersion = 1.96;
        requiredAddons[] = {"A3_Weapons_F"};
    };
};

class CfgWeapons
{
    // 先声明原版父类再继承覆盖
    class Rifle_Base_F;

    class TAG_rifle_F: Rifle_Base_F
    {
        scope = 2;
        displayName = "TAG Rifle";
        author = "TAG";

        // ---------- 枪口 / 弹壳：memory 点挂载 ----------
        // 以下每项都引用模型 memory LOD 里同名的 memory 点：
        //   muzzle         枪口（弹道起点）
        //   muzzleFlash    火光/烟雾特效挂点
        //   eject          弹壳抛出点
        // 模型缺这些点 → 回退模型原点（开火从枪托冒火）。
        model = "\A3\weapons_f\rifles\MX\mx.p3d";       // 用占位模型，学习用
        muzzlePos = "muzzle";                           // 弹道起点 memory 点
        muzzleEnd = "muzzle_end";                       // 可选：弹道终点
        ejectionPort = "eject";                         // 弹壳出口 memory 点

        // 火光 + 音效：引用 ammo 里的 muzzleFlash 类（见本文件末尾弹药区）
        // 实际开火特效由 ammo 的 CfgAmmo>>muzzleFlash 声明，武器这里只把
        // memory 点"muzzleFlash"挂到特效上，命名须与模型一致。

        // ---------- 换弹：位置 + 动画 + 动作 ----------
        reloadMagazinePos = "magazine_point";           // 弹匣插入点 memory 点
        reloadMagazineAnim = "ReloadMagazine";          // 换弹动画名（模型动画源）
        reloadAction = "GestureReload";                 // 换弹动作类（CfgMoves/Gestures）
        // 换弹关键：动画事件帧（弹匣到位那帧）触发补弹逻辑；
        // 空仓时用备用弹药量判定，为 0 播放空仓音效并中断换弹。

        // ---------- 切枪：动作绑定 ----------
        class WeaponSlotsInfo
        {
            mass = 80;                              // 武器质量
            class MuzzleSlot
            {
                linkProxy = "\A3\data_f\proxies\weapon_slots\MUZZLE";
            };
            class CowsSlot
            {
                linkProxy = "\A3\data_f\proxies\weapon_slots\TOP";
            };
            class PointerSlot
            {
                linkProxy = "\A3\data_f\proxies\weapon_slots\SIDE";
            };
        };

        // 枪械模式与弹匣
        magazineWell[] = {"CBA_65x39_MX"};
        magazines[] = {"30Rnd_65x39_caseless_mag"};

        // ---------- 瞄准：瞄具模型 + 瞄准线 ----------
        // opticsModel 是安装的瞄具；memoryPointCamera 定义瞄具后准星对齐点。
        // 姿势/瞄准动画配在 CfgMoves（weaponState），配合记忆点对齐瞄具视线。
        opticsModel = "\A3\weapons_f\acc\acco2_2d.p3d"; // 占位红点瞄具
        class OpticsModes
        {
            class iron
            {
                opticsID = 1;
                useModelOptics = 0;
                opticsPPEffects[] = {};
                opticsZoomMin = 0.375;
                opticsZoomMax = 1.1;
                memoryPointCamera = "eye";
                opticsDisablePeripherialVision = 0;
                cameraDir = "";
                opticsFlare = 0;
                opticsUsesParallax = 0;
            };
        };

        // ---------- 基本手感参数（学习用占位） ----------
        cursor = "cursorEmpty";
        cursorSize = 1;
        reloadTime = 0.1;      // 两次开火最小间隔（秒），略大于开火动画时长
        drySound[] = {"", 1, 1};  // 空仓声
        // 附在弹药上：CfgAmmo>>muzzleFlash + 音效，武器只挂 memory 点
    };
};