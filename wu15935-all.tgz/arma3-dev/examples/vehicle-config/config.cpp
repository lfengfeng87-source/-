// =============================================================
//  vehicle-config — 载具 CfgVehicles 骨架（学习样例）
// -------------------------------------------------------------
//  演示 A3 载具的三件事：
//    1) 类型/继承树（LandVehicle → Tank/Tank_F、Car/Car_F）
//    2) 炮塔层级 Turrets 嵌套 + 炮塔光学 OpticsIn
//    3) 伤害模型 HitPoints（含炮塔自带 HitTurret/HitGun）
//  A3 内部继承树（NewTurret / MainTurret / CommanderOptics 等空壳）
//  是从原版 pbo 对照抄的，**不要改**——只在自己的 _base 类上继承。
//  资料来源：原版 PLZ05/HMMWV 配置、BI Cars Config Guidelines、
//           Turret Config Reference、Damage Description。
// =============================================================

class CfgPatches
{
    class TAG_Vehicles
    {
        units[] = {"TAG_MBT"};
        weapons[] = {};
        requiredVersion = 2.0;
        requiredAddons[] = {"A3_Armor_F", "A3_Soft_F", "A3_Weapons_F"};
    };
};

// ---------- 0) 枚举：stabilizedInAxes / 摧毁类型 ----------
// 不定义这些枚举，配置里就得写数字（stabilizedInAxes=3），可读性差。
enum
{
    stabilizedInAxesNone = 0,
    stabilizedInAxesX    = 1,
    stabilizedInAxesY    = 2,
    stabilizedInAxesBoth = 3,
    stabilizedInAxesXYZ  = 4,

    destructNo       = 0,
    destructBuilding = 1,
    destructEngine   = 2,
    destructTree     = 3,
    destructTent     = 4,
    destructMan      = 5,
    destructDefault  = 6,
    destructWreck    = 7
};

class CfgVehicles
{
    // =========================================================
    //  1) A3 默认继承树（照抄原版，勿改内部结构）
    // =========================================================
    class LandVehicle;

    // 装甲车/坦克
    class Tank: LandVehicle
    {
        class NewTurret;         // 炮塔空壳，MainTurret 从它派生
        class Sounds;
        class HitPoints;
    };

    class Tank_F: Tank
    {
        class Turrets
        {
            class MainTurret: NewTurret
            {
                class Turrets
                {
                    class CommanderOptics;   // 车长周视镜炮塔
                };
            };
        };
        class AnimationSources;
        class ViewPilot;         // 驾驶员视镜
        class ViewOptics;        // 光学视镜基类（炮塔 OpticsIn 从它派生）
        class ViewCargo;
        class HeadLimits;        // 车长转头范围
        class HitPoints: HitPoints
        {
            class HitHull;
            class HitEngine;
            class HitLTrack;
            class HitRTrack;
        };
        class Sounds: Sounds
        {
            class Engine;
            class Movement;
        };
    };

    // 轮式车辆
    class Car: LandVehicle
    {
        class NewTurret;
    };

    class Car_F: Car
    {
        class AnimationSources;
        class Turrets
        {
            class MainTurret: NewTurret {};
        };
        class HitPoints
        {
            class HitLFWheel;
            class HitLF2Wheel;
            class HitRFWheel;
            class HitRF2Wheel;
            class HitGlass1;
            class HitGlass2;
            class HitGlass3;
            class HitGlass4;
        };
    };

    // =========================================================
    //  2) 自行火炮/坦克 _base 类
    // =========================================================
    class TAG_MBT_base: Tank_F
    {
        scope = 0;
        displayName = "TAG MBT";
        model = "\TAG_vehicles\TAG_mbt\TAG_mbt.p3d";     // 占位
        picture = "\TAG_vehicles\TAG_mbt\data\ui\icon_ca.paa";
        icon = "\TAG_vehicles\TAG_mbt\data\ui\map_ca.paa";
        mapSize = 11.6;
        vehicleClass = "Armored";
        editorSubcategory = "EdSubcat_Tanks";

        // ---- 车辆级装甲 ----
        // armor：整车结构强度（与包围球体积一起参与计算）
        // armorStructural：打在 hull 上的伤害先除以它，>1 更耐打
        armor = 425;
        armorStructural = 4.5;

        // ---- 乘员 ----
        crew = "B_crew_F";
        typicalCargo[] = {"B_crew_F"};
        transportSoldier = 0;
        crewVulnerable = 1;          // 乘员可被穿甲弹直击伤害
        crewCrashProtection = 0.15;

        // ---- AI/编辑器识别 ----
        unitInfoType = "RscUnitInfoTank";       // HUD 显示哪个界面类
        accuracy = 0.5;                          // AI 识别难度（>4 基本认不出）
        threat[] = {0.8, 0.6, 0.3};              // 对 步兵/装甲/空中 的威胁分

        // ---- 烟幕发射器（坦克标配）----
        smokeLauncherGrenadeCount = 8;
        smokeLauncherVelocity = 14;
        smokeLauncherOnTurret = 1;               // 1=烟幕器在炮塔上
        smokeLauncherAngle = 120;

        // =====================================================
        //  3) 伤害模型：整个载具的 HitPoints
        // =====================================================
        // 七个字段：
        //   armor              该点的装甲系数（越大越难打穿）
        //   material           -1 = 用装甲材质
        //   name               绑定模型上的 selection / bone 名
        //   visual             受损时换材质的视觉 selection（""=无）
        //   passThrough        1 = 要害（打爆它整车报废）
        //                      0 = 局部件（打爆只报废该件）
        //                      0<p<1 = 中间态（穿透后仍传伤害）
        //   minimalHit         低于此值的伤害不记（过滤掉步枪弹）
        //   explosionShielding 爆炸伤害系数，**唯一能挡 indirectHit 的手**
        //                      1=不挡，>1 减伤（2.0 很硬），<1 更脆
        //   radius             命中球半径
        class HitPoints: HitPoints
        {
            class HitHull: HitHull
            {
                armor = 0.8;
                material = -1;
                name = "telo";
                visual = "zbytek";        // A3 坦克车体损伤贴图用 zbytek
                passThrough = 1;
                minimalHit = 0.14;
                explosionShielding = 2.0;
                radius = 0.25;
            };
            class HitEngine: HitEngine
            {
                armor = 1;
                material = -1;
                name = "motor";
                passThrough = 0.8;
                minimalHit = 0.24;
                explosionShielding = 1;
                radius = 0.33;
            };
            class HitLTrack: HitLTrack
            {
                armor = 0.5;
                material = -1;
                name = "pas_L";
                passThrough = 0;          // 断履带不等于整车报废
                minimalHit = 0.08;
                explosionShielding = 1.44;
                radius = 0.3;
            };
            class HitRTrack: HitRTrack
            {
                armor = 0.5;
                material = -1;
                name = "pas_P";
                passThrough = 0;
                minimalHit = 0.08;
                explosionShielding = 1.44;
                radius = 0.3;
            };
        };

        // =====================================================
        //  4) 炮塔层级：Turrets 可无限嵌套
        // =====================================================
        class Turrets: Turrets
        {
            class MainTurret: MainTurret
            {
                // ---- 动画：body=水平转，gun=俯仰 ----
                body = "mainTurret";
                gun = "mainGun";
                animationSourceBody = "mainTurret";
                animationSourceGun = "mainGun";
                animationSourceHatch = "hatchCommander";
                selectionFireAnim = "";        // 炮口火光动画 selection

                // ---- 转速：1 = 45°/秒 ----
                maxHorizontalRotSpeed = 0.78;
                maxVerticalRotSpeed = 0.26;
                // 稳定器：0 无 / 1 仅 X / 2 仅 Y / 3 双轴 / 4 三轴
                stabilizedInAxes = stabilizedInAxesBoth;

                // ---- 伺服音 ----
                soundServo[] = {"A3\Sounds_F\vehicles\armor\noises\servo_armor_gunner", 0.15848932, 1, 50};
                soundServoVertical[] = {"A3\Sounds_F\vehicles\armor\noises\servo_armor_gunner_vertical", 0.15848932, 1, 50};

                // ---- 转角限位（度）----
                minElev = -5;
                maxElev = 80;
                initElev = 10;
                minTurn = -360;
                maxTurn = 360;
                initTurn = 0;
                maxCamElev = 30;
                elevationMode = 3;

                // ---- 挂武器：weapons[] 与 magazines[] 成对 ----
                weapons[] = {"cannon_120mm"};
                magazines[] = {"24Rnd_120mm_APFSDS_shells_Tracer_Red"};
                // 弹种多于武器是允许的（同一门炮带多种弹）
                // 车载武器必须用 CfgWeapons 里的 VehicleWeapon 派生类

                // ---- 炮口定位：gunBeg 尾 / gunEnd 口 / memoryPointGun 出弹点 ----
                gunBeg = "usti hlavne";
                gunEnd = "konec hlavne";
                memoryPointGun = "usti hlavne2";

                // ---- 火控：调零界面 + 预设距离 ----
                turretInfoType = "RscWeaponRangeZeroingFOV";
                discreteDistance[] = {100, 200, 400, 600, 800, 1000, 1200, 1500, 2000, 2500, 3000};
                discreteDistanceInitIndex = 3;   // 默认 600m

                // ---- 炮手光学：视点 memory 点 + 2D 镜 P3D ----
                memoryPointGunnerOptics = "gunnerview";
                memoryPointGunnerOutOptics = "commanderview";
                gunnerOpticsModel = "\A3\weapons_f\reticle\optics_empty";
                gunnerOutOpticsModel = "";       // 空串 = 探出时不要光学视图
                gunnerOpticsEffect[] = {};       // 后处理特效（如 {"OpticsBlur1"}）
                gunnerHasFlares = 1;             // 看强光时出现光晕
                gunnerForceOptics = 0;
                forceHideGunner = 0;

                // ---- 单档视镜：FOV 数值 1 = 120° ----
                class ViewOptics: ViewOptics
                {
                    initAngleX = 0;
                    minAngleX = -30;
                    maxAngleX = 30;
                    initAngleY = 0;
                    minAngleY = -100;
                    maxAngleY = 100;
                    initFov = 0.155;
                    minFov = 0.034;
                    maxFov = 0.155;
                    visionMode[] = {"Normal", "TI"};   // TI = 热成像
                    thermalMode[] = {0, 1};            // 热成像配色索引
                };

                // ---- 多档镜：OpticsIn（宽/中/窄），游戏里可切换 ----
                class OpticsIn
                {
                    class Wide: ViewOptics
                    {
                        initFov = 0.3;
                        minFov = 0.3;
                        maxFov = 0.3;
                        opticsDisplayName = "W";       // HUD 上显示的名字
                        visionMode[] = {"Normal", "NVG"};
                        thermalMode[] = {4, 5};
                        gunnerOpticsModel = "\A3\weapons_f\reticle\optics_empty";
                    };
                    class Medium: Wide
                    {
                        initFov = 0.07;
                        minFov = 0.07;
                        maxFov = 0.07;
                        opticsDisplayName = "M";
                        gunnerOpticsModel = "\A3\weapons_f\reticle\optics_empty";
                    };
                    class Narrow: Wide
                    {
                        initFov = 0.028;
                        minFov = 0.028;
                        maxFov = 0.028;
                        opticsDisplayName = "N";
                        gunnerOpticsModel = "\A3\weapons_f\reticle\optics_empty";
                    };
                };

                // ---- 炮手动作 ----
                gunnerAction = "Gunner_MBT_01_cannon_F_out";
                gunnerInAction = "Gunner_MBT_01_cannon_F_in";
                gunnerGetInAction = GetInHigh;
                gunnerGetOutAction = GetOutHigh;
                // 扳机手骨骼名写错会 CTD
                gunnerLeftHandAnimName = "OtocHlaven_shake";
                gunnerRightHandAnimName = "OtocHlaven_shake";

                // ---- 交互开关 ----
                commanding = 1;            // 炮塔指挥权（数字大的当车长）
                hasGunner = 1;
                startEngine = 0;           // 转炮塔不点火
                viewGunnerInExternal = 1;  // 外部可见炮手身体，穿甲弹才打得死
                outGunnerMayFire = 1;
                inGunnerMayFire = 1;

                // ---- 炮塔自己的伤害块：HitTurret / HitGun 命名固定 ----
                class HitPoints
                {
                    class HitTurret
                    {
                        armor = 0.8;
                        material = -1;
                        name = "vez";
                        visual = "vez";
                        passThrough = 0;
                        minimalHit = 0.02;
                        explosionShielding = 0.3;   // 炮塔顶部脆
                        radius = 0.25;
                    };
                    class HitGun
                    {
                        armor = 0.3;
                        material = -1;
                        name = "zbran";
                        visual = "";
                        passThrough = 0;
                        minimalHit = 0;
                        explosionShielding = 1;
                        radius = 0.25;
                    };
                };

                // ---- 子炮塔：车长周视镜（再嵌一层）----
                class Turrets: Turrets
                {
                    class CommanderOptics: CommanderOptics
                    {
                        body = "obsTurret";
                        gun = "obsGun";
                        animationSourceBody = "obsTurret";
                        animationSourceGun = "obsGun";
                        maxHorizontalRotSpeed = 3.6;
                        maxVerticalRotSpeed = 3.6;
                        stabilizedInAxes = stabilizedInAxesBoth;
                        soundServo[] = {"A3\Sounds_F\vehicles\armor\noises\servo_best", db-40, 1.0, 50};
                        minElev = -5;
                        maxElev = 80;
                        minTurn = -360;
                        maxTurn = 360;
                        weapons[] = {"SmokeLauncher"};
                        magazines[] = {"SmokeLauncherMag"};
                        turretInfoType = "RscWeaponRangeZeroing";
                        discreteDistance[] = {100, 200, 300, 400, 500, 600, 700, 800};
                        discreteDistanceInitIndex = 2;
                        memoryPointGunnerOptics = "commanderview";
                        gunnerOpticsModel = "\A3\weapons_f\reticle\optics_empty";
                        gunnerOpticsEffect[] = {};
                        class ViewOptics: ViewOptics
                        {
                            initFov = 0.155;
                            minFov = 0.034;
                            maxFov = 0.155;
                            visionMode[] = {"Normal", "NVG"};
                            thermalMode[] = {0, 1};
                        };
                    };
                };
            };
        };

        // =====================================================
        //  5) 武器驱动的动画源（后坐/转管/换弹由武器触发）
        // =====================================================
        class AnimationSources: AnimationSources
        {
            class muzzle_rot_cannon { source = "ammorandom"; weapon = "cannon_120mm"; };
            class recoil_source   { source = "reload";     weapon = "cannon_120mm"; };
            // 其它常用 source：reloading / reloadmagazine / revolving / trigger
        };

        // =====================================================
        //  6) 损伤贴图：mat[] 三元组 = 完好 / 受损 / 报废
        // =====================================================
        class Damage
        {
            tex[] = {};
            mat[] =
            {
                "\TAG_vehicles\TAG_mbt\data\body.rvmat",
                "\TAG_vehicles\TAG_mbt\data\body_damage.rvmat",
                "\TAG_vehicles\TAG_mbt\data\body_destruct.rvmat",

                "\TAG_vehicles\TAG_mbt\data\turret.rvmat",
                "\TAG_vehicles\TAG_mbt\data\turret_damage.rvmat",
                "\TAG_vehicles\TAG_mbt\data\turret_destruct.rvmat"
            };
        };

        // =====================================================
        //  7) 车灯（Reflectors）+ 尾气（Exhausts）
        // =====================================================
        class Reflectors
        {
            class Left
            {
                color[] = {1900, 1300, 950};
                ambient[] = {5, 5, 5};
                position = "Light_L";
                direction = "Light_L_end";
                hitpoint = "Light_L";
                selection = "Light_L";
                size = 1;
                innerAngle = 100;
                outerAngle = 179;
                coneFadeCoef = 10;
                intensity = 1;
                useFlare = 0;          // 1 = 加光晕
                dayLight = 0;
                flareSize = 1.0;
                class Attenuation
                {
                    start = 1.0;
                    constant = 0;
                    linear = 0;
                    quadratic = 0.25;
                    hardLimitStart = 30;
                    hardLimitEnd = 60;
                };
            };
            class Right: Left
            {
                position = "Light_R";
                direction = "Light_R_end";
                hitpoint = "Light_R";
                selection = "Light_R";
            };
        };
        // 把多盏灯合并计算，省性能
        aggregateReflectors[] = {{"Left", "Right"}};

        class Exhausts
        {
            class Exhaust1
            {
                position = "exhaust";
                direction = "exhaust_dir";
                effect = "ExhaustEffectTankBack";
            };
        };

        // ---- 驾驶员 ----
        driverOpticsModel = "\A3\weapons_f\reticle\optics_empty";
        viewDriverInExternal = 1;
        driverAction = "Driver_MBT_03_cannon_F_out";
        driverInAction = "Driver_MBT_03_cannon_F_in";
        driverLeftHandAnimName = "drivewheel";     // IK：手搭方向盘
        driverRightHandAnimName = "drivewheel";
        driverLeftLegAnimName = "pedal_brake";
        driverRightLegAnimName = "pedal_thrust";
    };

    // 出厂可用类
    class TAG_MBT: TAG_MBT_base
    {
        scope = 2;
        scopeCurator = 2;      // 2 = Zeus 里也能刷
        side = 1;
        faction = "BLU_F";
        accuracy = 1000;       // 编辑器里直接可辨认
    };

    // =========================================================
    //  8) 轮式车辆：PhysX 3 行驶参数（simulation="carx"）
    // =========================================================
    class TAG_Truck_base: Car_F
    {
        scope = 0;
        displayName = "TAG Truck";
        model = "\TAG_vehicles\TAG_truck\TAG_truck.p3d";  // 占位
        simulation = "carx";                 // 轮式载具必须 carx（旧 car 已弃用）
        armor = 80;
        armorStructural = 2;
        transportSoldier = 3;
        crew = "B_Soldier_F";
        typicalCargo[] = {"B_Soldier_F", "B_Soldier_F", "B_Soldier_F"};

        // ---- 发动机 ----
        enginePower = 276;
        maxOmega = 471;
        peakTorque = 1253;
        idleRpm = 800;
        redRpm = 4500;
        brakeIdleSpeed = 1.78;               // 低于此速度(m/s)自动刹停
        thrustDelay = 0.2;                   // 静止起步油门爬升时间
        fuelCapacity = 250;
        dampingRateFullThrottle = 0.08;
        dampingRateZeroThrottleClutchEngaged = 2.0;
        dampingRateZeroThrottleClutchDisengaged = 0.35;
        // 扭矩曲线 {归一化转速, 扭矩系数}
        torqueCurve[] =
        {
            {0.0, 0.0},
            {0.278, 0.5},
            {0.461, 1.0},
            {0.6, 0.95},
            {0.8, 0.75},
            {1.0, 0.5}
        };

        // ---- 变速箱 ----
        class complexGearbox
        {
            GearboxRatios[] = {"R1", -5.75, "N", 0, "D1", 4.3, "D2", 2.3, "D3", 1.5, "D4", 1.0, "D5", 0.73};
            TransmissionRatios[] = {"High", 6.759};   // 可选：高低档
            gearBoxMode = "auto";
            moveOffGear = 1;
            driveString = "D";
            neutralString = "N";
            reverseString = "R";
        };
        // 自动换挡：空档给低值(~0.15)，前进档给高值(~0.95)防抖动
        changeGearMinEffectivity[] = {0.95, 0.15, 0.95, 0.95, 0.95, 0.95, 0.95};
        switchTime = 0.31;                   // 换挡耗时
        latency = 1.0;                       // 两次换挡最短间隔（须 > switchTime）

        // ---- 差速器 ----
        differentialType = "all_limited";     // all_open/all_limited/front_open/...
        frontRearSplit = 0.5;
        frontBias = 1.3;
        rearBias = 1.3;
        centreBias = 1.3;
        clutchStrength = 20.0;
        dampersBumpCoef = 6.0;

        // ---- 防侧倾杆：forceCoef=0 即关闭 ----
        antiRollbarForceCoef = 12;
        antiRollbarForceLimit = 10;
        antiRollbarSpeedMin = 20;
        antiRollbarSpeedMax = 50;

        // ---- 轮胎/悬挂：每个轮子一个子类 ----
        // 模型 memory 点命名：wheel_<纵>_<横>_axis / _bound
        //   纵 = 从车头数的位置，横 = 1 左 / 2 右
        //   _axis 是转轴点，_bound 到轴的距离 = 轮半径
        class Wheels
        {
            class LF
            {
                boneName = "wheel_1_1_damper";
                steering = 1;
                side = "left";
                center = "wheel_1_1_axis";
                boundary = "wheel_1_1_bound";
                width = 0.126;
                mass = 30;
                MOI = 12.8;
                dampingRate = 0.1;
                maxBrakeTorque = 10000;
                maxHandBrakeTorque = 0;
                suspTravelDirection[] = {0, -1, 0};
                suspForceAppPointOffset = "wheel_1_1_axis";
                tireForceAppPointOffset = "wheel_1_1_axis";
                maxCompression = 0.05;
                mMaxDroop = 0.1;
                sprungMass = 825;
                springStrength = 51625;
                springDamperRate = 8920;
                longitudinalStiffnessPerUnitGravity = 10000;
                latStiffX = 25;
                latStiffY = 180;
                frictionVsSlipGraph[] = {{0, 1}, {0.5, 1}, {1, 1}};
            };
            class LR: LF
            {
                boneName = "wheel_1_2_damper";
                steering = 0;
                center = "wheel_1_2_axis";
                boundary = "wheel_1_2_bound";
                suspForceAppPointOffset = "wheel_1_2_axis";
                tireForceAppPointOffset = "wheel_1_2_axis";
                maxHandBrakeTorque = 3500;
            };
            class RF: LF
            {
                boneName = "wheel_2_1_damper";
                center = "wheel_2_1_axis";
                boundary = "wheel_2_1_bound";
                suspForceAppPointOffset = "wheel_2_1_axis";
                tireForceAppPointOffset = "wheel_2_1_axis";
                side = "right";
            };
            class RR: RF
            {
                boneName = "wheel_2_2_damper";
                steering = 0;
                center = "wheel_2_2_axis";
                boundary = "wheel_2_2_bound";
                suspForceAppPointOffset = "wheel_2_2_axis";
                tireForceAppPointOffset = "wheel_2_2_axis";
                maxHandBrakeTorque = 3500;
            };
        };

        // ---- 轮子损坏阈值 ----
        wheelDamageThreshold = 0.7;
        wheelDestroyThreshold = 0.99;
        wheelDamageRadiusCoef = 0.95;
        wheelDestroyRadiusCoef = 0.45;
        wheelCircumference = 2.834;
    };

    class TAG_Truck: TAG_Truck_base
    {
        scope = 2;
        scopeCurator = 2;
        side = 1;
        faction = "BLU_F";
    };
};

// 备注：
// - 炮塔 Turrets 可任意嵌套（MainTurret → CommanderOptics → ...），
//   每层自成一套 body/gun/weapons/optics/hitpoints。
// - weapons[] 里必须是 CfgWeapons 的 VehicleWeapon 派生类；
//   士兵枪械类（Rifle_Base_F）不能直接挂到炮塔。
// - 所有 memory 点（gunBeg/gunEnd/memoryPointGun/gunnerview/...）都要在
//   模型 memory LOD 里存在，拼错或缺失 = 不报错但功能静默失效。
// - 想改装甲/伤害先想清楚"打在哪个 HitPoint 上"：
//   动能弹走 FireGeometry 命中球 → HitPoints；爆炸走 indirectHit，
//   直接穿 FireGeometry 只受 explosionShielding 影响。
