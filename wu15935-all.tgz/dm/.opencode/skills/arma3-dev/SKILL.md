---
name: arma3-dev
description: 武装突袭3 (Arma 3) 代码开发技能：查看分析 SQF 脚本与 config.cpp 配置、生成任务/mod 代码、按自检清单查错并自我进化。当用户提到 Arma 3、武装突袭、SQF、mission.sqm、description.ext、init.sqf、CfgVehicles、模组、任务脚本时使用。
---

# Arma 3 开发技能

用于 Arma 3 的 SQF 脚本编写、配置文件分析与代码生成。核心工作流：先读经验库，再按规范生成，最后强制自检并把新经验写回。

## 0. 自我进化机制（每次任务必做）

**任务开始前**：读取本技能目录下的 `lessons.md`。里面是历史踩坑记录，处理当前任务时逐条对照，凡涉及的坑直接套用已验证的修复方式。

**任务结束后**：执行第 3 节自检清单。若发现新问题并已修复，立即追加到 `lessons.md`，格式：

```
[YYYY-MM-DD] 问题一句话描述
- 现象：
- 原因：
- 修复：
- 来源任务：<一句话>
```

追加前先查重：已有同主题条目时合并更新原条目（更新日期），保持文件精简。这条纪律是技能进化的唯一途径，跳过写回等于技能退化。

## 1. 代码查看与分析

### 1.1 典型文件结构

任务文件夹 `MissionName.Altis/`：

| 文件 | 作用 | 执行时机 |
|------|------|----------|
| `mission.sqm` | Eden 编辑器生成的任务描述，实体/触发器/标记定义 | 自动；手动编辑易被编辑器覆盖 |
| `description.ext` | 任务配置：CfgFunctions、CfgSounds、CfgMusic、Respawn 设置、onLoad 声明 | 任务加载时 |
| `init.sqf` | 全局初始化（旧式，服务端+客户端都跑） | 任务开始 |
| `initServer.sqf` | 仅服务端初始化（推荐） | 服务端任务开始 |
| `initPlayerLocal.sqf` | 仅每个玩家本地初始化 | 玩家进入 |
| `onPlayerRespawn.sqf` | 玩家重生事件 | 重生时 |
| `functions/fn_*.sqf` | 函数库，经 description.ext 的 CfgFunctions 注册后可用 `TAG_fnc_name` 调用 | 按需 |

Mod/Addon 解包后目录：

```
addon_source/
  config.cpp            # 核心配置：CfgPatches、CfgVehicles、CfgWeapons 等
  $PBOPREFIX$.txt       # pbo 前缀声明
  textures/ scripts/    # 资源
```

### 1.2 分析流程

1. 读 `mission.sqm` 头部确认地图、任务名、模组依赖（`AddonsMetaData`）
2. 读 `description.ext` 拿到 CfgFunctions 映射表——函数名到文件路径的对应关系全在这里
3. 顺着 `initServer.sqf` / `initPlayerLocal.sqf` / 触发器 `init` 字段追执行入口
4. 用 grep 搜关键词定位逻辑：`addEventHandler`、`remoteExec`、`spawn`、`execVM`、`waitUntil`、`while`、函数调用 `xxx_fnc_yyy`
5. 判断每个脚本块的**执行端**（服务端/客户端/JIP）后再评估逻辑正确性

### 1.3 RPT 日志排查（运行时自查找问题）

RPT 是 Arma 3 的运行日志，任务/脚本报错的第一现场，排查顺序：先 RPT 后代码。

**文件位置**

- 客户端默认：`%LOCALAPPDATA%\Arma 3\logs\Arma3_x64_日期_时间.rpt`（Linux 服务器在 `-profiles=` 指定的 profile 目录下）
- 服务器：启动参数 `-profiles=<目录>` 指定目录内的 `.rpt`
- 开发期建议启动参数：`-showScriptErrors`（脚本错误弹窗）、`-filePatching`（允许加载外置文件）

**grep 优先级（从上到下，第一个命中往往就是根因）**

| 关键词 | 含义 |
|--------|------|
| `Error in expression` / `Error position:` | SQF 语法/运行时错误，报错行号前先看它 |
| `Warning Message: No entry 'bin\config.bin/CfgVehicles.xxx'` | 类缺失：mod 没加载或 requiredAddons 缺失 |
| `Script error` | addEventHandler / 函数内错误，附文件路径 |
| `Cannot load ... .pbo` | pbo 缺失或损坏 |
| `Duplicate ... handler` | 事件处理重复注册 |
| `Unexpected switch type` / `division by zero` | 逻辑错误 |

**闭环动作**：定位错误 → 修复 → 让用户重进任务 → 再读最新 RPT 确认该错误消失且无新增。每次修复按第 0 节写回 lessons.md。

## 2. 代码生成规范

### 2.1 SQF 语法要点

```sqf
// 变量：局部必须 private，命名带下划线
private _unit = param [0, objNull];
params ["_pos", ["_radius", 50]];

// 判断执行端（最常用的三件套）
if (isServer) then { };          // 服务端（含单人）
if (hasInterface) then { };      // 有界面的客户端（排除 dedicated server）
if (isDedicated) then { };       // 专用服务器

// 调度环境：sleep/waitUntil 只能在 spawn 或 execVM 的脚本里用
[] spawn {
    sleep 5;
    waitUntil { uiSleep 0.5; !alive player };  // 循环内必须 sleep，防止死循环锁死调度器
};

// 远程执行（BIS_fnc_MP 已废弃，一律用 remoteExec）
[objNull, "hint", 0] remoteExec ["globalChat", -2];   // -2 所有客户端
[objNull, 2] remoteExec ["fncName", 2];               // 2 = 服务端

// 数组遍历与筛选
{ _x setDamage 0; } forEach units _grp;
private _alive = (units _grp) select { alive _x };

// 字符串与格式
hint format ["距离: %1 米", round _dist];

// 事件处理
_player addEventHandler ["Killed", {
    params ["_unit", "_killer", "_instigator", "_useEffects"];
}];
```

### 2.2 强制约定

1. **locality 优先**：写任何代码前先回答"这段代码在哪个机器上跑、操作的对象在哪台机器上"。对象状态（setDamage、setPos、setVariable 普通模式）由服务端或所属端执行；show/hint/UI 类只在本地执行。
2. **JIP 安全**：玩家中途加入（didJIP 为 true）会跑 initPlayerLocal.sqf，但任务开始时的 init.sqf 不会重跑。依赖任务开始状态的代码须在 `initServer` 中维护状态变量，客户端加入时主动拉取（如 publicVariableClient 或 remoteExec 回调）。
3. **函数注册**：自定义函数一律走 `description.ext` 的 CfgFunctions，声明 `class TAG { class myTag { class functions { class myFunc { file = "functions\fn_myFunc.sqf"; }; }; }; };`，调用用 `[] call TAG_fnc_myFunc`。
4. **坐标统一**：全任务统一一种坐标制（推荐 `getPosATL` / `getPosWorld`），混用 ASL/ATL/AGL 是高度偏差 bug 的头号来源。
5. **调度器保护**：`waitUntil` 条件里禁止执行重逻辑；每次迭代带 `uiSleep`；超时兜底：`waitUntil { uiSleep 1; _i = _i + 1; (_cond) || _i > 60 }`。
6. **参数防御**：函数入口用 `params` 带默认值；对象参数先 `isNull` 检查。
7. **配置类名**：引用载具/武器类名前确认属于哪个 mod（任务依赖列表里要有），拼错类名是任务报错最常见原因。

## 3. 自检清单（每次生成/修改代码后逐条过）

- [ ] **执行端正确**：每个脚本块能用 isServer / hasInterface / isDedicated 说清在哪跑；对象修改在所属端执行
- [ ] **JIP 覆盖**：中途加入的玩家能拿到正确状态，或明确声明本功能不需要 JIP 支持
- [ ] **调度安全**：sleep/waitUntil/while 只出现在 spawn/execVM 环境里；waitUntil 有 sleep 和超时
- [ ] **无废弃 API**：没用 BIS_fnc_MP、没用 serverCommand 滥用、没直接改 mission.sqm 实体定义
- [ ] **变量卫生**：函数内全部 private/params，无全局变量泄漏（下划线缺失）
- [ ] **坐标一致**：同一段逻辑内没有混用 getPos/getPosATL/getPosASL
- [ ] **远程执行目标**：remoteExec 的 target 参数与意图一致（0=所有含DS、-2=所有客户端、2=服务端、JIP 考虑用 remoteExec 的 JIP 队列参数）
- [ ] **错误兜底**：isNull/参数默认值覆盖；关键 remoteExec 有条件保护
- [ ] **性能**：无 EveryFrame 中的重逻辑；大循环有节流；触发器条件没有每帧全图查询
- [ ] **依赖声明**：用到第三方 mod 类名时，确认任务/mod 依赖列表已包含

自检发现的问题当场修复，修复方式按第 0 节写回 lessons.md。

## 4. 快速参考

### 常用命令速查

| 场景 | 命令 |
|------|------|
| 生成单位/载具 | `(typeOf x) createVehicle _pos`；步兵 `createUnit` |
| 阵营/编组 | `createGroup east; _grp addUnit "O_Soldier_F"` |
| 移动与路径 | `doMove`、`addWaypoint`、`setWaypointStatements` |
| 检测 | `triggers`、`nearEntities`、`nearestObjects`、`inArea` |
| 任务提示 | `hint`、`titleText`、`BIS_fnc_showNotification` |
| 任务状态 | `taskCreate`、`taskState`、`taskSetState`（或 modules） |
| 音效/音乐 | description.ext 的 CfgSounds/CfgMusic + `playSound`/`playMusic` |
| 随机化 | `selectRandom`、`BIS_fnc_randomPos` |

### description.ext 骨架

```sqf
class CfgFunctions {
    class TAG {
        class functions {
            class myFunc {
                file = "functions\fn_myFunc.sqf";
            };
        };
    };
};
respawn = "BASE";
respawnDelay = 10;
class CfgSounds { class mySound { name=""; sound[]={"\\mySound.ogg",1,1}; titles[]={}; }; };
#include "CfgHints.hpp"
```

### 常见错误信息与根因

| 错误 | 根因 |
|------|------|
| `Sleep in non-scheduled environment` | 在 call 直调的函数里用了 sleep |
| `WaitUntil exits with false` 无限刷 | waitUntil 返回值未处理/条件每帧报错 |
| `Cannot resync` / 消息丢失 | publicVariable 在 JIP 后丢失，改用 remoteExec |
| `_x undefined` | forEach 作用域外使用了 `_x` |
| 单位不同步/瞬移 | 服务端与客户端同时 setPos，执行端冲突 |
| 类名不存在静默失败 | mod 未加载或类名拼写错误 |

### 原版规范差异（二开代码 vs BI 官方惯例）

生成或审查代码时按本表对齐 BI 官方惯例（Coding Conventions / SQF_syntax / CfgPatches）：

| 维度 | 原版规范 | 常见二开写法 | 后果 |
|------|----------|--------------|------|
| 函数注册 | CfgFunctions 注册 + TAG 前缀 | execVM 散装调用全局脚本 | 重编译困难、命名冲突 |
| 变量 | private + missionNamespace 前缀 | 全局变量裸奔 `myVar = 5` | 覆盖冲突、内存驻留 |
| 事件 | EventHandler / 触发器 | `while {true}` 每帧轮询 | 调度器卡顿、掉帧 |
| 联网 | remoteExec 带目标端和 JIP 队列 | publicVariable 广播 | JIP 玩家状态错误 |
| 继承 | `class X: O_Soldier_F` 只覆盖差异属性 | 整类复制重定义 | 原版更新即失效、mod 冲突 |
| 依赖 | `requiredAddons[]` 齐全 | 缺失或乱填 | 加载顺序错、类找不到 |
| 文本 | `$STR_` stringtable 全覆盖 | 硬编码提示 | 无法本地化 |

config.cpp 三个硬性结构：`CfgPatches` 必填 `units[]`/`weapons[]`/`requiredVersion`/`requiredAddons[]`；继承前先外部类声明 `class O_Soldier_F;`；文本一律 `$STR_TAG_name` 引用 stringtable。模型动画放独立 `model.cfg`；扩展事件用原生 `class Extended_Killed_EventHandlers`；运行时读配置用 `configFile >> ...` + `getText/getNumber/getArray`。核心三原则：多人同步正确性、依赖加载顺序、可继承性。

### 构建与离线验证（HEMTT）

现代标准构建工具 HEMTT 可在无游戏环境验证产出（`hemtt build` / `hemtt check`：rapify config.cpp、编译 SQF、校验 stringtable），生成/mod 代码后建议跑一遍：

- v1.22 项目配置在 `.hemtt/project.toml`（根目录 hemtt.toml 已迁移）；无 git 仓库时 `[version]` 需加 `git_hash = 0`
- 每个 addon 文件夹必须有 `$PBOPREFIX$`（无扩展名），内容 = `mainprefix\prefix\addons\文件夹名`（如 `z\tag\addons\tag_myunit`），且文件夹名与其末段一致，否则报 `Addon prefix not found` / `Duplicate prefix`
- 纯 config addon 的构建无需 Arma 3 Tools，`BBW1` 警告仅涉及纹理/模型二进制化，可忽略

## 5. 任务完成标准

代码生成或修改后：过完第 3 节清单 + 把新增经验写回 lessons.md，才算完成。回复用户时给出：改动文件列表、执行端说明（哪段代码在哪台机器上跑）、自检结果。
