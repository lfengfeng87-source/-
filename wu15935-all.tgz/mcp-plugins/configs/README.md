# configs/

MCP 客户端配置文件：
- mcp-config.json（通用 MCP 配置）
- claude_desktop_config.json（Claude Desktop）

⚠️ 不要提交包含真实令牌/密钥的配置，令牌用环境变量占位。

