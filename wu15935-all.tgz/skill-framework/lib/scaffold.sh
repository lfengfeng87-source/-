#!/usr/bin/env bash
# 脚手架：从模板动态生成新技能，不写死领域逻辑。
set -euo pipefail
BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

name="${1:?用法: sks new <技能名(小写-连字符)> <描述> [关键词]}"
desc="${2:?缺少描述}"
kw="${3:-}"

[[ "$name" =~ ^[a-z][a-z0-9-]*$ ]] || { echo "错误: 名称须为小写字母/数字/连字符，形如 my-skill"; exit 1; }

dir="$BASE/skills/$name"
[ -d "$dir" ] && { echo "错误: 技能已存在: $name（如需修改请直接编辑文件）"; exit 1; }

# 转义 sed 替换值中的特殊字符（& 与分隔符）
esc() { printf '%s' "$1" | sed 's/[&|\\]/\\&/g'; }
name_e="$(esc "$name")"; desc_e="$(esc "$desc")"; kw_e="$(esc "$kw")"

mkdir -p "$dir"
sed -e "s|{{NAME}}|$name_e|g" -e "s|{{DESCRIPTION}}|$desc_e|g" -e "s|{{KEYWORDS}}|$kw_e|g" \
  "$BASE/template/SKILL_TEMPLATE.md" > "$dir/SKILL.md"
sed -e "s|{{NAME}}|$name_e|g" \
  "$BASE/template/LESSONS_TEMPLATE.md" > "$dir/lessons.md"

echo "已生成技能: $name"
echo "  - $dir/SKILL.md"
echo "  - $dir/lessons.md"
echo "运行 ./sks list 确认系统已自动发现它（无需注册）。"