#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""disasm.py — 基于 capstone 的跨平台反汇编工具（ELF/PE/Mach-O 全格式）。

用法:
  ./venv/bin/python disasm.py <文件> [架构] [偏移] [字节数] [选项...]

架构: arm64(默认) | arm | thumb | x86 | x64
偏移/字节数 可选，默认从文件入口或 0 反汇编。

选项:
  --funcs            列出检测到的函数边界（基于 call/ret/符号）
  --strings          提取可打印字符串（ascii）
  --xrefs            标注跳转/调用目标地址
  --hex              每条指令前输出原始字节 hex
  --max-size N      文件超过 N 字节时不整读入内存（防 OOM），改用分块读取
  --sections         列出已识别的节（仅 ELF）

示例:
  ./venv/bin/python disasm.py /usr/bin/python3.13 arm64 --funcs --strings
  ./venv/bin/python disasm.py app.so arm64 0 128 --hex --xrefs
  ./venv/bin/python disasm.py big.bin arm64 --max-size 16777216
"""
import sys, struct, re

try:
    from capstone import Cs, CS_ARCH_ARM64, CS_MODE_ARM, CS_MODE_THUMB, \
        CS_ARCH_ARM, CS_ARCH_X86, CS_MODE_32, CS_MODE_64, CS_OP_IMM
except ImportError:
    sys.stderr.write("错误: 需要 capstone，请先 `pip install capstone`\n")
    sys.exit(3)

ARCHES = {
    'arm64': (CS_ARCH_ARM64, CS_MODE_ARM),
    'arm':   (CS_ARCH_ARM,   CS_MODE_ARM),
    'thumb': (CS_ARCH_ARM,   CS_MODE_THUMB),
    'x86':   (CS_ARCH_X86,   CS_MODE_32),
    'x64':   (CS_ARCH_X86,   CS_MODE_64),
}

ELF_MIN = 64
DEFAULT_COUNT = 96
DEFAULT_MAX_SIZE = 256 * 1024 * 1024      # 默认 256MB 上限防 OOM
MIN_STR_LEN = 4


# ---------------------------------------------------------------- 格式识别
def detect_format(data):
    """返回 ('elf', class, endian) / ('pe', None, None) / ('macho', bits, endian) / (None, None, None)"""
    if len(data) >= 4 and data[:4] == b'\x7fELF':
        if len(data) < ELF_MIN:
            return ('elf_too_small', None, None)
        ei_class, ei_data = data[4], data[5]
        endian = 'little' if ei_data == 1 else 'big'
        return ('elf', ei_class, endian)
    if len(data) >= 2 and data[:2] == b'MZ':
        return ('pe', None, None)
    # Mach-O 魔数：32/64 位，大小端变体
    if len(data) >= 4:
        m = struct.unpack('<I', data[0:4])[0]
        mb = struct.unpack('>I', data[0:4])[0]
        if m in (0xfeedface, 0xfeedfacf, 0xcefaedfe, 0xcffaedfe):
            bits = 64 if m in (0xfeedfacf, 0xcffaedfe) else 32
            endian = 'little' if m in (0xfeedface, 0xfeedfacf) else 'big'
            return ('macho', bits, endian)
        if mb in (0xfeedface, 0xfeedfacf, 0xcefaedfe, 0xcffaedfe):
            bits = 64 if mb in (0xfeedfacf, 0xcffaedfe) else 32
            endian = 'big' if mb in (0xfeedface, 0xfeedfacf) else 'little'
            return ('macho', bits, endian)
    return (None, None, None)


# ---------------------------------------------------------------- ELF 解析
def _elf_header_safe(data):
    if len(data) < ELF_MIN:
        raise ValueError(f"ELF 头不足 {ELF_MIN} 字节（实际 {len(data)}）")
    ei_class, ei_data = data[4], data[5]
    if ei_class not in (1, 2):
        raise ValueError(f"未知 ELF class {ei_class}")
    if ei_data not in (1, 2):
        raise ValueError(f"未知 ELF 端序 {ei_data}")
    endian = '<' if ei_data == 1 else '>'
    return ei_class, endian


def elf_entry(data):
    ei_class, endian = _elf_header_safe(data)
    if ei_class == 2:
        return struct.unpack(endian + 'Q', data[0x18:0x20])[0]
    return struct.unpack(endian + 'I', data[0x18:0x1c])[0]


def elf_sections(data):
    """用 pyelftools 列出 (name, off, addr, size)；失败回退到手工解析。"""
    try:
        from elftools.elf.elffile import ELFFile
        import io
        e = ELFFile(io.BytesIO(data))
        out = []
        for sec in e.iter_sections():
            out.append((sec.name, sec['sh_offset'], sec['sh_addr'], sec['sh_size'], sec['sh_type']))
        return out
    except Exception:
        # 手工兜底：只列程序头
        try:
            ei_class, endian = _elf_header_safe(data)
            phoff = struct.unpack(endian + 'Q' if ei_class == 2 else endian + 'I', data[0x20:0x28] if ei_class == 2 else data[0x1c:0x20])[0]
            return [('(phdr)', phoff, 0, 0, 'PT_LOAD-*')]
        except Exception:
            return []


# ---------------------------------------------------------------- PE 解析
def pe_entry(data):
    """PE：e_lfanew -> PE 头 -> Optional header AddressOfEntryPoint + ImageBase。"""
    try:
        e_lfanew = struct.unpack('<I', data[0x3c:0x40])[0]
        if e_lfanew + 4 > len(data) or data[e_lfanew:e_lfanew + 4] != b'PE\x00\x00':
            return 0, 'x86'
        # COFF 头 optional 头 magic 决定 32/64
        coff = e_lfanew + 4
        opt = coff + 20
        magic = struct.unpack('<H', data[opt:opt + 2])[0]
        if magic == 0x20b:   # PE32+
            image_base = struct.unpack('<Q', data[opt + 24:opt + 32])[0]
            entry_rva = struct.unpack('<I', data[opt + 16:opt + 20])[0]
            arch = 'x64'
        else:                # PE32
            image_base = struct.unpack('<I', data[opt + 28:opt + 32])[0]
            entry_rva = struct.unpack('<I', data[opt + 16:opt + 20])[0]
            arch = 'x86'
        return image_base + entry_rva, arch
    except Exception:
        return 0, 'x86'


# ---------------------------------------------------------------- Mach-O 解析
def macho_entry(data):
    """Mach-O：读 entryoff (LC_MAIN)，粗略返回入口。"""
    try:
        magic = struct.unpack('<I', data[0:4])[0]
        if magic in (0xfeedfacf, 0xcffaedfe):
            fmt, endian = 'I', '<'
            if magic == 0xcffaedfe:
                endian = '>'
            ncmds = struct.unpack(endian + 'I', data[16:20])[0]
            off = 32
            for _ in range(ncmds):
                if off + 8 > len(data):
                    break
                cmd, cmdsize = struct.unpack(endian + 'II', data[off:off + 8])
                if cmd == 0x80000028:  # LC_MAIN
                    entryoff = struct.unpack(endian + 'Q', data[off + 8:off + 16])[0]
                    return entryoff, 'arm64'
                off += cmdsize
        else:  # 32 位
            fmt, endian = 'I', '<'
            ncmds = struct.unpack(endian + 'I', data[16:20])[0]
            off = 28
            for _ in range(ncmds):
                if off + 8 > len(data):
                    break
                cmd, cmdsize = struct.unpack(endian + 'II', data[off:off + 8])
                if cmd == 0x80000028:
                    entryoff = struct.unpack(endian + 'I', data[off + 8:off + 12])[0]
                    return entryoff, 'arm'
                off += cmdsize
    except Exception:
        pass
    return 0, 'arm64'


# ---------------------------------------------------------------- vaddr->offset（用于 ELF）
def vaddr_to_offset(data, vaddr):
    """ELF 虚拟地址转文件偏移；失败/越界原样返回。"""
    try:
        ei_class, endian = _elf_header_safe(data)
        if ei_class == 2:
            phoff = struct.unpack(endian + 'Q', data[0x20:0x28])[0]
            phentsize = struct.unpack(endian + 'H', data[0x36:0x38])[0]
            phnum = struct.unpack(endian + 'H', data[0x38:0x3a])[0]
        else:
            phoff = struct.unpack(endian + 'I', data[0x1c:0x20])[0]
            phentsize = struct.unpack(endian + 'H', data[0x2a:0x2c])[0]
            phnum = struct.unpack(endian + 'H', data[0x2c:0x2e])[0]
        if phnum == 0 or phentsize < 32:
            return vaddr
        if phoff < ELF_MIN or phoff + phnum * phentsize > len(data):
            return vaddr
        for i in range(phnum):
            ph = data[phoff + i * phentsize: phoff + (i + 1) * phentsize]
            ptype = struct.unpack(endian + 'I', ph[0:4])[0]
            if ptype != 1:
                continue
            if ei_class == 2:
                p_offset = struct.unpack(endian + 'Q', ph[8:16])[0]
                p_vaddr = struct.unpack(endian + 'Q', ph[16:24])[0]
                p_filesz = struct.unpack(endian + 'Q', ph[32:40])[0]
            else:
                p_offset = struct.unpack(endian + 'I', ph[4:8])[0]
                p_vaddr = struct.unpack(endian + 'I', ph[8:12])[0]
                p_filesz = struct.unpack(endian + 'I', ph[16:20])[0]
            if p_vaddr <= vaddr < p_vaddr + p_filesz:
                return p_offset + (vaddr - p_vaddr)
    except (ValueError, struct.error):
        pass
    return vaddr


# ---------------------------------------------------------------- 跳转目标提取
def branch_target(insn):
    """从 capstone 指令的 immediate 操作数提取跳转/调用目标地址；无则 None。"""
    try:
        for op in insn.operands:
            if op.type == CS_OP_IMM:
                return op.imm
    except Exception:
        pass
    return None


def is_return(insn):
    try:
        return 'return' in [insn.group_name(g) for g in insn.groups]
    except Exception:
        return False


def is_call(insn):
    try:
        return 'call' in [insn.group_name(g) for g in insn.groups]
    except Exception:
        return False


def is_jump(insn):
    try:
        return 'jump' in [insn.group_name(g) for g in insn.groups]
    except Exception:
        return False


# ---------------------------------------------------------------- 字符串提取
def extract_strings(data, minlen=MIN_STR_LEN):
    """提取可打印 ASCII 字符串，返回 [(offset, string)]。"""
    out = []
    cur_start = None
    cur = []
    printable = set(range(0x20, 0x7f))
    for i, b in enumerate(data):
        if b in printable:
            if cur_start is None:
                cur_start = i
            cur.append(b)
        else:
            if cur_start is not None:
                s = bytes(cur)
                if len(s) >= minlen:
                    out.append((cur_start, s.decode('ascii')))
                cur_start = None
                cur = []
    if cur_start is not None and len(cur) >= minlen:
        out.append((cur_start, bytes(cur).decode('ascii')))
    return out


# ---------------------------------------------------------------- 主流程
def main(argv):
    path = argv[0]
    arch = None
    opts = {
        'funcs': False, 'strings': False, 'xrefs': False, 'hex': False,
        'sections': False, 'max_size': DEFAULT_MAX_SIZE,
    }

    # 解析选项与位置参数：第一个非选项词若非已知架构则视为架构（可缺省=arm64）
    offset_arg = None
    count = DEFAULT_COUNT
    i = 1
    while i < len(argv):
        a = argv[i]
        if a in ('--funcs', '--strings', '--xrefs', '--hex', '--sections'):
            opts[a[2:]] = True
        elif a == '--max-size':
            i += 1
            if i >= len(argv):
                print("错误: --max-size 需要数值", file=sys.stderr); return 2
            try:
                opts['max_size'] = int(argv[i], 0)
            except ValueError:
                print(f"错误: --max-size 数值非法: {argv[i]!r}", file=sys.stderr); return 2
        elif a.startswith('-'):
            print(f"错误: 未知选项 {a}", file=sys.stderr); return 2
        else:
            # 非选项词：若还没定架构且是已知架构 -> 架构；否则尝试数值(偏移/字节数)
            if arch is None and a in ARCHES:
                arch = a
            else:
                try:
                    if offset_arg is None:
                        offset_arg = int(a, 0)
                    else:
                        count = int(a, 0)
                except ValueError:
                    print(f"错误: 参数 {a!r} 必须是整数（支持 0x 前缀）或已知架构", file=sys.stderr); return 2
        i += 1

    if arch is None:
        arch = 'arm64'
    if arch not in ARCHES:
        print(f"错误: 未知架构 {arch}，可选: {sorted(ARCHES)}", file=sys.stderr)
        return 2

    # --- 读文件（防 OOM：超过 --max-size 且无法定位入口时拒绝） ---
    force_base = None          # 超大数据流式读取时，记录入口地址供后续反汇编用
    force_start = None
    try:
        with open(path, 'rb') as f:
            import os
            fsize = os.fstat(f.fileno()).st_size
            if fsize > opts['max_size']:
                # 超大文件：先读头部判定能否定位入口；可定位则从入口区按需读取
                head = f.read(min(65536, fsize))
                fmt, _, _ = detect_format(head)
                entry = None
                entry_off = None
                if fmt == 'elf':
                    try:
                        entry = elf_entry(head)
                        entry_off = vaddr_to_offset(head, entry)
                    except Exception:
                        entry_off = None
                elif fmt == 'pe':
                    entry, _ = pe_entry(head)
                    entry_off = 0
                elif fmt == 'macho':
                    entry, _ = macho_entry(head)
                    entry_off = entry
                if entry_off is None:
                    print(f"错误: 文件 {fsize} 字节超过 --max-size {opts['max_size']}，且无法定位代码入口以按需读取", file=sys.stderr)
                    return 2
                f.seek(entry_off)
                data = f.read(DEFAULT_COUNT)
                force_base = entry if entry is not None else 0
                force_start = 0
            else:
                data = f.read()
    except FileNotFoundError:
        print(f"错误: 文件不存在: {path}", file=sys.stderr); return 2
    except IsADirectoryError:
        print(f"错误: 这是一个目录，不是文件: {path}", file=sys.stderr); return 2
    except PermissionError:
        print(f"错误: 无权限读取: {path}", file=sys.stderr); return 2
    except OSError as e:
        print(f"错误: 无法读取 {path}: {e}", file=sys.stderr); return 2

    md = Cs(*ARCHES[arch])
    md.detail = True

    fmt, fmt_class, fmt_endian = detect_format(data)

    # --- 确定入口地址与反汇编起点 ---
    base = 0
    start_off = offset_arg if offset_arg is not None else 0
    label = "原始字节"
    if force_base is not None:
        # 超大数据流式读取路径：直接用已定位的入口
        base = force_base
        start_off = force_start
        fmt = 'elf'
        label = "ELF(流式)"
    elif fmt == 'elf':
        try:
            base = elf_entry(data)
            label = f"ELF{32 if fmt_class == 1 else 64}-bit"
            if offset_arg is None:
                start_off = vaddr_to_offset(data, base)
        except ValueError as e:
            fmt = 'elf_too_small'
            label = f"ELF-异常({e})"
    elif fmt == 'pe':
        base, _ = pe_entry(data)
        label = "PE"
        start_off = offset_arg if offset_arg is not None else 0
    elif fmt == 'macho':
        base, _ = macho_entry(data)
        label = f"Mach-O{fmt_class}-bit" if fmt_class else "Mach-O"
        start_off = offset_arg if offset_arg is not None else base
    elif fmt == 'elf_too_small':
        label = "ELF(头过短)"

    # --- 若为 ELF 且未显式给偏移，用 --funcs 扫描整个 .text 节（而非仅入口窗口） ---
    text_info = None
    if fmt == 'elf' and opts['funcs'] and offset_arg is None:
        for name, off, addr, size, stype in elf_sections(data):
            if name == '.text' and size > 0:
                text_info = (off, addr, size)
                break

    # --- 越界诊断：入口/偏移落在文件末尾之外，或窗口被截断 ---
    fsize = len(data)
    if start_off >= fsize:
        print(f"错误: 偏移 0x{start_off:x} 超出文件大小 0x{fsize:x}（{fsize} 字节）", file=sys.stderr)
        if base:
            print(f"提示: 文件内声明的入口地址为 0x{base:x}，但该位置不在文件内"
                  f"（可能入口指向未映射内存、文件被截断，或偏移应为 RVA 而非文件偏移）", file=sys.stderr)
        return 2
    avail = fsize - start_off
    want = len(data[start_off:start_off + count])
    print(f"# {path}  ({label} 入口=0x{base:x}) 架构={arch} 偏移=0x{start_off:x} 长度={want}字节")
    if want < count:
        print(f"提示: 请求 {count} 字节，实际仅剩 {avail} 字节可用（文件末尾截断）", file=sys.stderr)

    # --- --sections：列出节 ---
    if opts['sections']:
        if fmt == 'elf':
            for name, off, addr, size, stype in elf_sections(data):
                if stype in ('SHT_PROGBITS', 'SHT_NOTE') or (size > 0 and addr > 0):
                    print(f"  节 {name:16s} off=0x{off:x} addr=0x{addr:x} size=0x{size:x}")
        else:
            print("  (--sections 仅对 ELF 有意义)")

    # --- --strings：提取字符串 ---
    if opts['strings']:
        print("  -- 字符串 --")
        shown = 0
        for off, s in extract_strings(data):
            print(f"  0x{off:08x}:  {s}")
            shown += 1
            if shown >= 200:
                print(f"  ...(已显示 200 条，共更多)")
                break

    # --- 反汇编主体 ---
    code = data[start_off:start_off + count]
    addr = base if (fmt in ('elf',) and offset_arg is None) else (offset_arg if offset_arg is not None else start_off)
    disasm_base = addr

    # 预扫描：收集分支目标（供 --xrefs 标注）
    target_set = set()
    func_starts = set()
    # 若 --funcs 且可定位 .text 节，扫描整个 .text 收集调用目标（更全的函数边界）
    if opts['funcs'] and text_info is not None and offset_arg is None:
        toff, taddr, tsize = text_info
        tcode = data[toff:toff + tsize]
        for i in md.disasm(tcode, taddr):
            t = branch_target(i)
            if t is not None and is_call(i):
                func_starts.add(t)
        func_src = f".text (0x{taddr:x}..0x{taddr + tsize:x})"
    else:
        insns = list(md.disasm(code, addr))
        for insn in insns:
            t = branch_target(insn)
            if t is not None and is_jump(insn):
                target_set.add(t)
            # 函数边界：调用目标（bl）是函数起点
            if is_call(insn) and t is not None:
                func_starts.add(t)
        func_src = "入口窗口"

    # -- --funcs：列出函数边界 ---
    if opts['funcs']:
        print(f"  -- 检测到的函数入口(call 目标, 扫描{func_src}) --")
        for t in sorted(func_starts):
            print(f"  0x{t:08x}")
        if not func_starts:
            print("  (未检测到 call 目标)")
    if 'insns' not in locals():
        insns = list(md.disasm(code, addr))

    # 输出反汇编
    for insn in insns:
        line_parts = []
        if opts['hex']:
            line_parts.append(f"{insn.bytes.hex():24s}")
        line_parts.append(f"0x{insn.address:08x}:  {insn.mnemonic:12s}{insn.op_str}")
        # --xrefs 标注：跳转/调用目标
        if opts['xrefs']:
            t = branch_target(insn)
            if t is not None and (is_jump(insn) or is_call(insn)):
                kind = 'call' if is_call(insn) else 'br'
                line_parts.append(f"  ; {kind} -> 0x{t:x}")
        print("  " + "".join(line_parts))

    if not insns:
        print("  (无反汇编输出 — 可能是数据区/非指令字节，试试给对偏移)")

    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))