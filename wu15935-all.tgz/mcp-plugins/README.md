# wu15935/mcp-plugins — MCP 插件合集库

本仓库用于存放我（wu15935）编写和维护的**所有 MCP 插件**（MCP Server 源码、配置文件、示例与文档）。

## 📁 目录结构

| 目录 | 说明 |
|------|------|
| `plugins/` | 已开发完成的 MCP 插件（每个插件一个子目录） |
| `examples/` | MCP 使用示例 / 演示脚本 |
| `configs/` | MCP 客户端配置文件（如 `mcp-config.json`、`claude_desktop_config.json` 等） |
| `docs/` | 文档、调研笔记、教程 |

## 🚀 如何添加一个新 MCP 插件

每个插件建议在 `plugins/` 下建独立子目录，推荐结构：

```
plugins/<插件名>/
├── README.md          # 插件说明、安装方式、环境变量
├── src/               # 源码
├── package.json       # (如为 Node 实现)
├── go.mod             # (如为 Go 实现)
└── config.example.json # 示例配置
```

## 🔧 常用命令

- **克隆本仓库**
  ```bash
  git clone https://gitee.com/wu15935/mcp-plugins.git
  ```

- **推送新插件**
  ```bash
  git add plugins/<插件名>
  git commit -m "add: <插件名> MCP 插件"
  git push origin main
  ```

## 📌 相关链接

- [Gitee MCP 官方文档](https://help.gitee.com)
- [Gitee 社区版 MCP `oschina/mcp-gitee`](https://gitee.com/oschina/mcp-gitee)

---

© 2025 wu15935 · MIT License