# magazine-ammo-config — 弹匣 magazineWell + 弹药与弹道参考（学习样例）

演示 Arma 3 弹药体系的规范写法：**弹匣可装性（CfgMagazineWells）**、**弹药继承（CfgAmmo）**、**初速 initSpeed 三级联动**、**空气阻力 airFriction 与伤害模型**。这是对照原版 pbo（`\A3\weapons_f\data` 的 config.bin）与 BI 官方指南、Bohemia 论坛实测案例核对的骨架，不含可用模型资源。

## 核心约定：弹匣能装 = magazineWell 是关键

自定义弹匣"在军械库里显示、悬停也提示兼容，却装不进武器"是弹药 mod 最高频问题。根因：**弹匣类名必须出现在武器所关联的某个 magazineWell 的列表里**；军械库悬停提示只是静态文本，不代表真兼容（BI 开发者 reyhard 明确说过）。

| 项 | 位置 | 说明 |
|---|---|---|
| 弹匣类 | `CfgMagazines` | 通过 `ammo` 字符串指向 `CfgAmmo` 弹类 |
| 弹药类 | `CfgAmmo` | 继承原版弹类，改 hit/initSpeed/airFriction |
| 弹匣组 | `CfgMagazineWells` | 独立根类，决定弹匣可装入哪些武器 |

## 正确 vs 错误：magazineWell 扩展

**正确**——扩展原版"共用 well"的内容（mod 也共享，reyhard 推荐）：

```cpp
class CfgMagazineWells
{
    class AK_762x39   // 所有 7.62x39 AK 家族共用的 well
    {
        TAG_762x39_Mags[] =
        {
            "TAG_30Rnd_762x39_Mag"
        };
    };
};
```

**错误**——在武器上 `+=` 新增 well（会覆盖/冲突，且仍需同名 CfgMagazineWells 类定义）：

```cpp
class CfgWeapons
{
    class arifle_MSBS65_base_F : Rifle_Base_F
    {
        magazineWell[] += { "Test_Custom_Promet_Magwell" };
    };
};
```

## 字段对照

### 1. 弹匣 CfgMagazines

- **`ammo`**：弹匣指向弹类的字符串（必填）。改弹药要先继承 CfgAmmo 弹类，再让弹匣 `ammo` 指向它。
- **`initSpeed`**：本弹匣初速（m/s），武器 initSpeed 存在时被覆盖。
- 继承原版弹匣（`class X : 30Rnd_762x39_Mag_F`）可少写 count/displayName 等字段。

### 2. 弹药 CfgAmmo

- **`hit`**：弹丸能量（伤害值），越大越痛。
- **`airFriction`**：弹丸所受空气阻力加速度（质量已计入，单位≈m/s²）；负值=减速，数值越大衰减越快，决定下坠/射程。
- **`caliber` / `armor`**（命中块配合）：caliber>0 且够高可穿透材质，caliber=0 直接杀死。
- 高级玩法：`shotSubmunition`（子母弹）/ `shotDeploy`（落地变地雷）。

### 3. 初速 initSpeed 三级联动

优先级 **武器 > 弹匣 > 附件**：

1. 武器 `initSpeed>0` → 直接用；
2. 否则取 `CfgMagazines` 对应条目 `initSpeed` × 其绝对值；
3. 枪口附件再乘 `ItemInfo >> MagazineCoef >> initSpeed`（消音器常见 1.05=增快）。

> 1.42 之前初速只由弹匣决定（同弹匣不同枪无差别），之后武器可覆盖/修饰（OPREP Muzzle Velocity）。

## 脚本参考

```sqf
// 取武器初速
getNumber(configfile >> "CfgWeapons" >> _weapon >> "initSpeed")
// 取弹丸阻力（须经弹匣 ammo 间接，不能把 currentMagazine 当 CfgAmmo 类名）
_airFric = getNumber(configFile >> "CfgAmmo"
    >> getText(configFile >> "CfgMagazines" >> currentMagazine _unit >> "ammo")
    >> "airFriction");
```

## 关联经验库

- `lessons.md` 三条：[弹匣 magazineWell 关键机制]、[初速 initSpeed 三级联动]、[空气阻力与动力学伤害]。
- 上一主题 `examples/attachment-optics-config/`：附件槽位两道门 + 消音器 MagazineCoef（初速联动第 3 级）。
- `examples/vehicle-weapon-action/`：车载武器 weapons[]/magazines[] 成对，也涉及弹匣关联。

## 备注

- **资料源**：BIKI *Arma 3 Weapon Config Guidelines*（Magazine compatibility groups 章节）、*Weapons settings*（动力学仿真=空气阻力+重力）、*Arma 3 Damage Description*、OPREP Muzzle Velocity（dev.arma3.com，1.42 初速改动）、Bohemia 论坛 topic 229351/189305（实测案例）、Steam「Arma 3 Damage explained」、fextralife Ballistics。
- 直抓 `community.bistudio.com`（BIKI 本体）与 `dev.arma3.com` 均 403/timeout，正文经 PMC 镜像（pmc.editing.wiki）与搜索片段交叉核对。
- `CfgPatches` 的 `requiredAddons` 必须含原版加载序（如 `A3_Data_F_Enoch_Loadorder`），否则覆盖不生效。