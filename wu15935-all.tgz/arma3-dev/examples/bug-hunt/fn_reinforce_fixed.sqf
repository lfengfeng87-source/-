// 修复版：对照 fn_reinforce_buggy.sqf 与 ANALYSIS.md 逐条查看差异
// 本文件应注册进 description.ext 的 CfgFunctions，调用名 TAG_fnc_reinforce
// （落实 ANALYSIS 第 1 条：函数走 CfgFunctions + TAG 前缀，不再用裸 spawnGroup）
params [["_pos", [], [[]]], ["_objective", [], [[]]]];

if (!isServer) exitWith {};

// B1 修复：空坐标守卫，防止调用方漏传位置时静默生成到地图原点 [0,0,0]
if (_pos isEqualTo []) exitWith { ["未提供生成位置，已取消刷兵"] remoteExec ["systemChat", -2]; };
if (_objective isEqualTo []) exitWith { ["未提供移动目标，已取消刷兵"] remoteExec ["systemChat", -2]; };

private _grp = createGroup east;
"O_Soldier_F" createUnit [_pos, _grp];

// B3 修复：createUnit 后新单位尚未完成初始化/入组，同帧 doMove 命令可能被丢弃，
// 移入 spawn 并等一帧再下移动命令；清理循环同放这里，带 uiSleep 与超时兜底
[_grp, _objective] spawn {
    params ["_grp", "_objective"];

    // 等一帧（约 1 个帧间隔），确保单位入组完成
    uiSleep 0.05;

    { _x doMove _objective } forEach units _grp;

    ["援军已出发"] remoteExec ["hint", -2];

    // 清理循环：带 uiSleep 与超时，条件满足即退出（不空转满 120 次）
    private _ticks = 0;
    waitUntil {
        uiSleep 5;
        _ticks = _ticks + 1;
        ({ alive _x } count units _grp) == 0 || _ticks > 120
    };
    if (!isNull _grp) then { deleteGroup _grp; };
};