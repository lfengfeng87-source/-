---
name: cyberstrike
description: CyberStrike 使用与操作技能。触发关键词：cyberstrike, cs, 红队, 渗透测试, ai安全
---

# CyberStrike 使用技能

本技能由 skill-framework 生成。核心工作流：先读经验库 → 按规范执行 → 强制自检 → 新经验写回。系统不写死领域逻辑，本文件与同目录 lessons.md 均可在使用中随时补充。

## 0. 自我进化机制（每次任务必做）

**任务开始前**：读本目录 `lessons.md`，逐条对照历史经验，涉及的坑直接套用已验证修复。

**任务结束后**：过第 3 节自检清单，发现新问题立即写回 `lessons.md`：

```
[YYYY-MM-DD] 问题一句话描述
- 现象：
- 原因：
- 修复：
- 来源任务：<一句话>
```

写回前查重，同主题合并更新原条目（更新日期），保持文件精简。跳过写回等于技能退化。

## 1. 责任与范围

**负责**：
- CyberStrike CLI 工具的日常使用、命令行操作与会话管理
- TUI 界面交互、Web 自动化与爬虫操作
- AI 模型配置、提供商管理与 Token 成本控制
- 会话导入导出、技能库管理与数据持久化

**不做**：
- 不直接执行非法入侵、破坏目标系统或获取未授权访问
- 不在未授权的系统上使用 CyberStrike 功能
- 不绕过组织安全政策或绕过合规审查

**边界**：
- 必须在拥有或被明确授权进行安全测试的系统上使用
- 企业网络（有 Zscaler/Netskoe 等 SSL 检测）需配置企业根 CA 证书
- Token 使用需监控成本，避免超支

## 2. 执行规范

### 2.1 安装与验证

```bash
# 安装 CyberStrike (npm 全局)
npm install -g @cyberstrike-io/cyberstrike@latest

# 验证安装
cyberstrike --version
# 应输出: cyberstrike v1.1.16 (或更高版本)
```

### 2.2 常用命令速查

| 命令 | 说明 | 示例 |
|------|------|------|
| `cyberstrike [project]` | 启动 TUI 界面 (默认模式) | `cyberstrike` |
| `cyberstrike --help` | 显示帮助信息 | `cyberstrike --help` |
| `cyberstrike --version` | 显示版本号 | `cyberstrike --version` |
| `cyberstrike run [message]` | 运行 CyberStrike 并发送消息 | `cyberstrike run "test"` |
| `cyberstrike hackbrowser <target>` | 爬取 Web 应用并打开 TUI 实时分析 | `cyberstrike hackbrowser https://example.com` |
| `cyberstrike auth` | 管理凭据 | `cyberstrike auth` |
| `cyberstrike models [provider]` | 列出可用 AI 模型 | `cyberstrike models` |
| `cyberstrike stats` | 显示 Token 使用统计和成本 | `cyberstrike stats` |

### 2.3 TUI 界面操作

- 使用方向键/WASD 导航
- Enter 确认/执行操作
- Tab 在选项间切换
- Q/Esc 退出当前层级

### 2.4 会话管理

```bash
# 创建新会话
cyberstrike -c my-session

# 继续上次会话
cyberstrike --continue

# 指定会话继续
cyberstrike --session my-session-id

# 导出会话数据
cyberstrike export my-session-id

# 导入会话数据
cyberstrike import /path/to/session.json
```

### 2.5 模型与提供商管理

```bash
# 列出所有可用模型
cyberstrike models

# 使用指定模型
cyberstrike -m provider/model "我的提示"

# 切换提供商
cyberstrike --provider provider-name
```

### 2.6 升级与维护

```bash
# 升级到最新版本
cyberstrike upgrade

# 或指定版本
cyberstrike upgrade @cyberstrike-io/cyberstrike@latest
```

## 3. 自检清单（每次产出后逐条过）

通用项：引用 `checks/common-checklists.md`（跨领域通用，系统维护，所有技能共享）。
本领域追加项：

- [ ] CyberStrike 是否已成功安装并验证版本？
- [ ] 使用的命令是否在官方文档中有记录？
- [ ] 是否在授权的测试范围内使用？
- [ ] Token 成本是否已预估并记录？
- [ ] 环境配置（代理、根 CA）是否已就绪？
- [ ] 是否区分了"工具使用"（本技能）与"实际攻击操作"（红队/攻击路径）的边界，没有越权？

## 4. 快速参考

**常用启动参数**:
```
cyberstrike [project] [options]
  -h, --help              显示帮助
  -v, --version           显示版本
  -m, --model             model to use (provider/model)
  -c, --continue          继续上次会话
  -s, --session           session id to continue
      --fork              fork the session when continuing
      --prompt            prompt to use
      --agent             agent to use
      --print-logs        print logs to stderr
      --log-level         log level (DEBUG/INFO/WARN/ERROR)
      --port              port to listen on (default: 4096)
      --hostname          hostname to listen on (default: "127.0.0.1")
      --mdns              enable mDNS service discovery
      --mdns-domain       custom domain name for mDNS (default: cyberstrike.local)
      --cors              additional domains to allow for CORS
```

**常用 model 格式**: `provider/model`，例如 `openai/gpt-4o`, `anthropic/claude-3-opus`, `google/gemini-pro`

## 5. 完成标准

产出后：过完第 3 节清单 + 新经验写回 lessons.md，才算完成。回复给出：改动文件清单、执行说明、自检结果。