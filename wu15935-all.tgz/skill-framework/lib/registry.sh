#!/usr/bin/env bash
# 动态注册表：运行时扫描 skills/*/SKILL.md，不维护硬编码列表。
# 用法: registry.sh list | registry.sh check <name> | registry.sh details <name>
set -euo pipefail
BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SKILLS="$BASE/skills"
MODE="${1:?用法: registry.sh list|check <name>|details <name>}"
shift || true

case "$MODE" in
  list)
    # 发现所有技能并读取 frontmatter，命中即显示，零注册
    for f in "$SKILLS"/*/SKILL.md; do
      [ -f "$f" ] || continue
      name="$(grep -m1 '^name:' "$f" | cut -d: -f2- | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"
      desc="$(grep -m1 '^description:' "$f" | cut -d: -f2- | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"
      printf '%-24s %s\n' "${name:-(unnamed)}" "${desc:-(无描述)}"
    done | sort
    ;;

  check)
    name="${1:?用法: registry.sh check <name>}"
    skill="$SKILLS/$name"
    [ -f "$skill/SKILL.md" ] || { echo "错误: 未找到技能 $name（用 sks list 查看）"; exit 1; }
    echo "=== 技能: $name ==="
    echo "--- 通用自检清单 ---"
    cat "$BASE/checks/common-checklists.md"
    echo "--- 本技能经验库 lessons.md ---"
    if [ -f "$skill/lessons.md" ]; then cat "$skill/lessons.md"; else echo "(暂无)"; fi
    ;;

  details)
    name="${1:?用法: registry.sh details <name>}"
    skill="$SKILLS/$name"
    [ -f "$skill/SKILL.md" ] || { echo "错误: 未找到技能 $name"; exit 1; }
    echo "=== $name/SKILL.md ==="
    cat "$skill/SKILL.md"
    ;;

  *)
    echo "未知模式: $MODE（可用: list / check / details）"; exit 1;;
esac