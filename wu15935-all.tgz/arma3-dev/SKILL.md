---
name: arma3-dev
description: 武装突袭3 (Arma 3) 代码开发技能：查看分析 SQF 脚本与 config.cpp 配置、生成任务/mod 代码、按自检清单查错并自我进化。当用户提到 Arma 3、武装突袭、SQF、mission.sqm、description.ext、init.sqf、CfgVehicles、模组、任务脚本时使用。
---

# Arma 3 开发技能

## ⚡ 激活指令

**「武装突袭3」**为本技能的显式激活口令。

收到该口令后立即执行启动序列：

1. **读取经验库**：加载本目录 `lessons.md`，全部条目进入工作记忆
2. **报告就绪**：输出当前知识规模（SKILL.md 章节 + lessons 条目数 + examples 清单）
3. **等待任务**：列出可执行的 6 类任务（任务脚本生成 / 代码审查 / RPT 排错 / mod 开发 / 任务包分析 / HEMTT 构建），等待用户下达具体任务
4. **全程挂载**：后续对话中所有 Arma 3 相关操作自动按本技能规范执行（7 条强制约定 + 10 项自检），直到用户说「解除武装突袭3」

口令变体（等价）：`创建武装突袭3` / `启动arma3` / `激活arma3-dev` / `进入武装突袭3模式`。

普通对话中若出现 Arma 3、SQF、mission.sqm、CfgVehicles 等关键词，无需口令也自动按本技能处理；口令的作用是**强制进入完整启动序列**（显式读库+报告就绪）。

## 1. 代码查看与分析## 1. 代码查看与分析

### 1.1 典型文件结构

任务文件夹 `MissionName.Altis/`：

| 文件 | 作用 | 执行时机 |
|------|------|----------|
| `mission.sqm` | Eden 编辑器生成的任务描述，实体/触发器/标记定义 | 自动；手动编辑易被编辑器覆盖 |
| `description.ext` | 任务配置：CfgFunctions、CfgSounds、CfgMusic、Respawn 设置、onLoad 声明 | 任务加载时 |
| `init.sqf` | 全局初始化（旧式，服务端+客户端都跑） | 任务开始 |
| `initServer.sqf` | 仅服务端初始化（推荐） | 服务端任务开始 |
| `initPlayerLocal.sqf` | 仅每个玩家本地初始化 | 玩家进入 |
| `onPlayerRespawn.sqf` | 玩家重生事件 | 重生时 |
| `functions/fn_*.sqf` | 函数库，经 description.ext 的 CfgFunctions 注册后可用 `TAG_fnc_name` 调用 | 按需 |

Mod/Addon 解包后目录：

```
addon_source/
  config.cpp            # 核心配置：CfgPatches、CfgVehicles、CfgWeapons 等
  $PBOPREFIX$.txt       # pbo 前缀声明
  textures/ scripts/    # 资源
```

### 1.2 分析流程

1. 读 `mission.sqm` 头部确认地图、任务名、模组依赖（`AddonsMetaData`）
2. 读 `description.ext` 拿到 CfgFunctions 映射表——函数名到文件路径的对应关系全在这里
3. 顺着 `initServer.sqf` / `initPlayerLocal.sqf` / 触发器 `init` 字段追执行入口
4. 用 grep 搜关键词定位逻辑：`addEventHandler`、`remoteExec`、`spawn`、`execVM`、`waitUntil`、`while`、函数调用 `xxx_fnc_yyy`
5. 判断每个脚本块的**执行端**（服务端/客户端/JIP）后再评估逻辑正确性

### 1.3 RPT 日志排查（运行时自查找问题）

RPT 是 Arma 3 的运行日志，任务/脚本报错的第一现场，排查顺序：先 RPT 后代码。

**文件位置**

- 客户端默认：`%LOCALAPPDATA%\Arma 3\logs\Arma3_x64_日期_时间.rpt`（Linux 服务器在 `-profiles=` 指定的 profile 目录下）
- 服务器：启动参数 `-profiles=<目录>` 指定目录内的 `.rpt`
- 开发期建议启动参数：`-showScriptErrors`（脚本错误弹窗）、`-filePatching`（允许加载外置文件）

**grep 优先级（从上到下，第一个命中往往就是根因）**

| 关键词 | 含义 |
|--------|------|
| `Error in expression` / `Error position:` | SQF 语法/运行时错误，报错行号前先看它 |
| `Warning Message: No entry 'bin\config.bin/CfgVehicles.xxx'` | 类缺失：mod 没加载或 requiredAddons 缺失 |
| `Script error` | addEventHandler / 函数内错误，附文件路径 |
| `Cannot load ... .pbo` | pbo 缺失或损坏 |
| `Duplicate ... handler` | 事件处理重复注册 |
| `Unexpected switch type` / `division by zero` | 逻辑错误 |

**闭环动作**：定位错误 → 修复 → 让用户重进任务 → 再读最新 RPT 确认该错误消失且无新增。每次修复按第 0 节写回 lessons.md。

## 2. 代码生成规范

### 2.1 SQF 语法要点

```sqf
// 变量：局部必须 private，命名带下划线
private _unit = param [0, objNull];
params ["_pos", ["_radius", 50]];

// 判断执行端（最常用的三件套）
if (isServer) then { };          // 服务端（含单人）
if (hasInterface) then { };      // 有界面的客户端（排除 dedicated server）
if (isDedicated) then { };       // 专用服务器

// 调度环境：sleep/waitUntil 只能在 spawn 或 execVM 的脚本里用
[] spawn {
    sleep 5;
    waitUntil { uiSleep 0.5; !alive player };  // 循环内必须 sleep，防止死循环锁死调度器
};

// 远程执行（BIS_fnc_MP 已废弃，一律用 remoteExec）
[objNull, "hint", 0] remoteExec ["globalChat", -2];   // -2 所有客户端
[objNull, 2] remoteExec ["fncName", 2];               // 2 = 服务端

// 数组遍历与筛选
{ _x setDamage 0; } forEach units _grp;
private _alive = (units _grp) select { alive _x };

// 字符串与格式
hint format ["距离: %1 米", round _dist];

// 事件处理
_player addEventHandler ["Killed", {
    params ["_unit", "_killer", "_instigator", "_useEffects"];
}];
```

### 2.2 强制约定

1. **locality 优先**：写任何代码前先回答"这段代码在哪个机器上跑、操作的对象在哪台机器上"。对象状态（setDamage、setPos、setVariable 普通模式）由服务端或所属端执行；show/hint/UI 类只在本地执行。
2. **JIP 安全**：玩家中途加入（didJIP 为 true）会跑 initPlayerLocal.sqf，但任务开始时的 init.sqf 不会重跑。依赖任务开始状态的代码须在 `initServer` 中维护状态变量，客户端加入时主动拉取（如 publicVariableClient 或 remoteExec 回调）。
3. **函数注册**：自定义函数一律走 `description.ext` 的 CfgFunctions，声明 `class TAG { class myTag { class functions { class myFunc { file = "functions\fn_myFunc.sqf"; }; }; }; };`，调用用 `[] call TAG_fnc_myFunc`。
4. **坐标统一**：全任务统一一种坐标制（推荐 `getPosATL` / `getPosWorld`），混用 ASL/ATL/AGL 是高度偏差 bug 的头号来源。
5. **调度器保护**：`waitUntil` 条件里禁止执行重逻辑；每次迭代带 `uiSleep`；超时兜底：`waitUntil { uiSleep 1; _i = _i + 1; (_cond) || _i > 60 }`。
6. **参数防御**：函数入口用 `params` 带默认值；对象参数先 `isNull` 检查。
7. **配置类名**：引用载具/武器类名前确认属于哪个 mod（任务依赖列表里要有），拼错类名是任务报错最常见原因。

## 3. 自检清单（每次生成/修改代码后逐条过）

- [ ] **执行端正确**：每个脚本块能用 isServer / hasInterface / isDedicated 说清在哪跑；对象修改在所属端执行
- [ ] **JIP 覆盖**：中途加入的玩家能拿到正确状态，或明确声明本功能不需要 JIP 支持
- [ ] **调度安全**：sleep/waitUntil/while 只出现在 spawn/execVM 环境里；waitUntil 有 sleep 和超时
- [ ] **无废弃 API**：没用 BIS_fnc_MP、没用 serverCommand 滥用、没直接改 mission.sqm 实体定义
- [ ] **变量卫生**：函数内全部 private/params，无全局变量泄漏（下划线缺失）
- [ ] **坐标一致**：同一段逻辑内没有混用 getPos/getPosATL/getPosASL
- [ ] **远程执行目标**：remoteExec 的 target 参数与意图一致（0=所有含DS、-2=所有客户端、2=服务端、JIP 考虑用 remoteExec 的 JIP 队列参数）
- [ ] **错误兜底**：isNull/参数默认值覆盖；关键 remoteExec 有条件保护
- [ ] **性能**：无 EveryFrame 中的重逻辑；大循环有节流；触发器条件没有每帧全图查询
- [ ] **依赖声明**：用到第三方 mod 类名时，确认任务/mod 依赖列表已包含

自检发现的问题当场修复，修复方式按第 0 节写回 lessons.md。

## 4. 快速参考

### 常用命令速查

| 场景 | 命令 |
|------|------|
| 生成单位/载具 | `(typeOf x) createVehicle _pos`；步兵 `createUnit` |
| 阵营/编组 | `createGroup east; _grp addUnit "O_Soldier_F"` |
| 移动与路径 | `doMove`、`addWaypoint`、`setWaypointStatements` |
| 检测 | `triggers`、`nearEntities`、`nearestObjects`、`inArea` |
| 任务提示 | `hint`、`titleText`、`BIS_fnc_showNotification` |
| 任务状态 | `taskCreate`、`taskState`、`taskSetState`（或 modules） |
| 音效/音乐 | description.ext 的 CfgSounds/CfgMusic + `playSound`/`playMusic` |
| 随机化 | `selectRandom`、`BIS_fnc_randomPos` |

### description.ext 骨架

```sqf
class CfgFunctions {
    class TAG {
        class functions {
            class myFunc {
                file = "functions\fn_myFunc.sqf";
            };
        };
    };
};
respawn = "BASE";
respawnDelay = 10;
class CfgSounds { class mySound { name=""; sound[]={"\\mySound.ogg",1,1}; titles[]={}; }; };
#include "CfgHints.hpp"
```

### 常见错误信息与根因

| 错误 | 根因 |
|------|------|
| `Sleep in non-scheduled environment` | 在 call 直调的函数里用了 sleep |
| `WaitUntil exits with false` 无限刷 | waitUntil 返回值未处理/条件每帧报错 |
| `Cannot resync` / 消息丢失 | publicVariable 在 JIP 后丢失，改用 remoteExec |
| `_x undefined` | forEach 作用域外使用了 `_x` |
| 单位不同步/瞬移 | 服务端与客户端同时 setPos，执行端冲突 |
| 类名不存在静默失败 | mod 未加载或类名拼写错误 |

### 原版规范差异（二开代码 vs BI 官方惯例）

生成或审查代码时按本表对齐 BI 官方惯例（Coding Conventions / SQF_syntax / CfgPatches）：

| 维度 | 原版规范 | 常见二开写法 | 后果 |
|------|----------|--------------|------|
| 函数注册 | CfgFunctions 注册 + TAG 前缀 | execVM 散装调用全局脚本 | 重编译困难、命名冲突 |
| 变量 | private + missionNamespace 前缀 | 全局变量裸奔 `myVar = 5` | 覆盖冲突、内存驻留 |
| 事件 | EventHandler / 触发器 | `while {true}` 每帧轮询 | 调度器卡顿、掉帧 |
| 联网 | remoteExec 带目标端和 JIP 队列 | publicVariable 广播 | JIP 玩家状态错误 |
| 继承 | `class X: O_Soldier_F` 只覆盖差异属性 | 整类复制重定义 | 原版更新即失效、mod 冲突 |
| 依赖 | `requiredAddons[]` 齐全 | 缺失或乱填 | 加载顺序错、类找不到 |
| 文本 | `$STR_` stringtable 全覆盖 | 硬编码提示 | 无法本地化 |

config.cpp 三个硬性结构：`CfgPatches` 必填 `units[]`/`weapons[]`/`requiredVersion`/`requiredAddons[]`；继承前先外部类声明 `class O_Soldier_F;`；文本一律 `$STR_TAG_name` 引用 stringtable。模型动画放独立 `model.cfg`；扩展事件用原生 `class Extended_Killed_EventHandlers`；运行时读配置用 `configFile >> ...` + `getText/getNumber/getArray`。核心三原则：多人同步正确性、依赖加载顺序、可继承性。

### 构建与离线验证（HEMTT）

现代标准构建工具 HEMTT 可在无游戏环境验证产出（`hemtt build` / `hemtt check`：rapify config.cpp、编译 SQF、校验 stringtable），生成/mod 代码后建议跑一遍：

- v1.22 项目配置在 `.hemtt/project.toml`（根目录 hemtt.toml 已迁移）；无 git 仓库时 `[version]` 需加 `git_hash = 0`
- 每个 addon 文件夹必须有 `$PBOPREFIX$`（无扩展名），内容 = `mainprefix\prefix\addons\文件夹名`（如 `z\tag\addons\tag_myunit`），且文件夹名与其末段一致，否则报 `Addon prefix not found` / `Duplicate prefix`
- 纯 config addon 的构建无需 Arma 3 Tools，`BBW1` 警告仅涉及纹理/模型二进制化，可忽略

### 社区实战经验（Bohemia 论坛提炼）

**config/模组侧**
- 导弹飞行剖面：`flightProfiles` 的 `Cruise`（掠海/巡航）与 `topDown`（末端俯冲）参数互斥，`autoSeekTarget` 不能与巡航剖面同时生效；官方不支持运行中动态切换剖面（如 Cruise→topDown 的 pop-up 攻顶），需脚本兜底（锁剖面或 hit/到距时替换导弹改寻的参）；`topDown`+`descendDistance` 可自寻但无法掠海，`missileCruise` 用于掠海
- 脚本禁止运行时从外部网络（云端/网盘）拉取数据——安全风险且不受支持；数据随 pbo 打包，用 `preprocessFile`/`call compileFinal` 读入并缓存，避免每帧重读

**任务脚本架构惯例**
- lobby 参数集中在 `description.ext` 的 Parameters 区块定义，但要在 `initPlayerLocal.sqf` 里写代码才真正生效
- 大型 MP 任务严格分离 `initServer.sqf`（服务端逻辑）/ `initPlayerLocal.sqf`（玩家本地参数）；成熟任务复用社区脚本（EOS 区域刷敌、BTC revive 复活、巡逻脚本），不重复造轮子
- 性能约束优先：AI 生成设触发距离、限制同时激活区域数、用 HC 分流（≤2 个，需 `-serverMod=` 挂同 mod）；Autoinit on 会覆盖/阻止自定义 AI 参数，注意关闭
- 动态任务生成套路（User Missions 提炼）：目标/标记/触发器用脚本创建（`BIS_fnc_taskCreate`）而非堆进 mission.sqm，便于换图移植；刷敌走"数据池+找位函数校验合法落点"再 `createGroup/createUnit/createVehicle`；胜负用进度点计数 + `BIS_fnc_endMission`；简报 `BIS_fnc_createDiaryRecord`；旁观 `BIS_fnc_EGSpectator`
- 性能规范：刷怪放服务端（`isServer`）降网络流量；trigger 从 per-frame 降到秒级降服务器负载；巡逻按区域密度限上限；找位必须校验（避免刷进岩石/空中/地图边缘）
- 复活/重生：`description.ext` 用 `respawn=3; respawnTemplates[]={"MenuPosition"}`；自写 revive 用 `player setDamage 0; player setVariable ["incapacitated",false,true]`，但须与 ACE/官方 revive 对齐（否则命令失效）；FOB/MHQ 载具做移动重生点
- 胜负判定：判 fail 与判 complete 必须互斥（防同帧既败又胜）；全员阵亡要能正常结束任务防卡 spectator

**坑（已在 lessons.md 记录）**
- 触发器判定条件（半径/高度/条件表达式）不足是任务不触发的首要原因
- 任务 ID 必须唯一，任务初始化/完成调用顺序影响逻辑
- 巡逻队/手电类光照占用光照额度，过多会挤掉夜晚黑暗效果
- 反复 `createVehicle`/`deleteVehicle` 不释放内存（despawned objects 持续增长），长期服务器需轮换任务
- 重生脚本须处理尸体清理（防舔尸/防堆尸）
- 排错链路：先裸跑（无 mod）→ 看 `.rpt` 尾部 → 二分定位；本地跑不通，服务器一定跑不通

**服务器与多人（Servers / Multiplayer 提炼）**
- HC 是独立 local owner：HC 用 `-client` 参数启动、端口通常主服 +12；`headlessClients[]`/`localClient[]` 必须写**具体单一 IP**（通配符/网段无效），HC profile 加 `battleyeLicense=1;`；对象交给 HC 后 locality 移到 HC 进程
- 服务器 mod 文件名必须全小写（Workshop 自动转，手动安装需转小写）；多 mod 用 `-mod=mods\@a;mods\@b`
- locality 所有权铁律：`local` 为真的本地 owner（服务器/HC）才能驱动/`setVelocity`/`setDamage`；非 owner 端这些命令无效或不同步。载具驾驶权还受编组位分配约束——未预分配的客户端只能转炮塔/射击
- JIP 玩家 mod/DLC 集合与服务器不一致会拖垮整局，靠 launcher 按服务器集合自动加载 + 密码兜底
- addon 签名只针对单个 PBO；`.bisign` 与公钥 key 对应目标 PBO，未签名 addon 上签名服被拒

**完整 mod 结构（MODDING / COMPLETE 提炼）**
- 机制型 mod 挂编辑器 Module 激活：`CfgVehicles` 里继承 `Module_F`，设 `category` 与 `function`（如 `class X_Module: Module_F { category="LAxemann"; function="X_fnc_init"; };`）
- 装备/头部替换用事件处理器：`addEventHandler("Equipment",…)` 侦测穿戴，穿戴期换 head/face（modded 脸给 substitute face），卸下还原
- 载具/飞机 standalone 核心字段：`CfgVehicles` 的 `stealth`（隐身）、`radarType`、`hasPilotCamera`、`hitPoints[]`、动态挂载；`CfgAmmo` 定义新型武器
- 音频：wav 须转 wss/ogg；`CfgSoundShaders`（单层，pitch/volume）+`CfgSoundSets`（组合 shader 与传感器）两级；控制器名如 `CustomSoundController1` 首字母大写（小写静默失效）；每单位 5 个 sound controller，每帧参与计算且值仅本地（各端需各自同步）；引擎声 pitch 随转速靠 controller 数值驱动 shader，非改 wav。官方脚本命令：
```sqf
setCustomSoundController [(vehicle player), "CustomSoundController1", 0.5];
getCustomSoundController [(vehicle player), "CustomSoundController1"]; // 读当前值
```
  `"interior"` 控制器只对 player 有效，值由脚下地表贴图推断（贴图名须以 `"int_"` 开头）
- 弹道：`initSpeed`/`airFriction` 须按 ICAO/制造商弹道系数生成（ACE3 工具），乱填破弹道
- 武器手感：`armFatigue`>0.8 自动放下武器、卧倒恢复最快；疲劳主因是武器 mass；正确 mod 只叠加自己效应，不硬改 `recoil`（防与架设类 mod 冲突）

**载具炮塔与动画（MODDING 提炼，原版代码最易错区）**
- `Turrets{}` 从 `class Turret` 容器继承 BI 现成炮塔类（`MainTurret`/`RemoteControlM2`/`M2MachineGun`）只覆盖差异，不手写；`weapons[]`/`magazines[]` 成对且武器继承 `VehicleWeapon`（非士兵武器）
- 记忆点：`memoryPointGetWeaponDir` 必须存在（引擎靠它做 canHit 遮挡判定，缺失→炮塔能转但打不中）；`memoryPointGunnerOptics`+`OpticsIn/OpticsOut` 定炮手视角；`gunBeg/gunEnd`+`memoryPointGunOut`（炮口闪光）与模型 memory 严格一致
- proxy 命名写死字符串且须匹配模型 memory LOD：`memoryPointsGetInDriver="pos driver"`/`GetInGunner="pos gunner"`/`GetInCargo="pos cargo"`；A2→A3 移植时 proxy 规范变了（pilot 需 `pos driver`/`pos pilot`），名对不上座位失效
- 炮塔限位：`minTurn/maxTurn`（±180 默认全向）、`minElev/maxElev`（度，勿与弧度混）、`turnRate/elevateRate`；多人下炮塔朝向引擎自动广播，config 无需同步，全端 CfgVehicles 一致即可
- 移动速度：`CfgMovesMaleSdr>>States>>speed` 只改动画播放速率（假狂奔），真地速用 `relSpeedMin/Max`+`CfgVehicles maxSpeed`；`setAnimSpeedCoef` 同理仅改速率
- AnimationSource 隐藏/显现：`type="hide"`+`source`+`selection`+`minValue/maxValue`+`minPhase/maxPhase`；受损两段式（原件隐藏+烧毁件显现）用两个独立 source 各自绑 selection
- 动画继承链 `CfgMovesBasic ← CfgMovesMaleSdr`，用 `class CfgMovesMaleSdr : CfgMovesBasic` 派生而非平级新建（防与官方同名状态互相覆盖）
- 执行含 `sleep` 的自定义动画函数须 `[] spawn{}` 进 scheduled 上下文（preinit 直调报 `Suspending not allowed in this context`）；投掷惯性由脚本 `getVelocity` 读移动状态写入初速，动作只负责姿态位形

**.rpt 报错对照（Troubleshooting 提炼，写代码排错先查表）**
- `No entry 'bin\config.bin/...'` 族 → 引用了不存在的键/类（mod 或 description.ext 控件缺属性）→ 更新/重装对应 mod + 校验文件，或补控件属性（如 `widthRailWay = 1;`）
- `[BIS_fnc_*] Error: Type ANY, expected STRING` → 传参类型错/变量未初始化（`nil` 当参数传入）→ 修正参数类型并初始化
- `[BIS_fnc_baseWeapon] Class '%ALL' not found in CfgWeapons` → 把空/占位变量当武器类传入 → 校验类在 CfgWeapons 存在
- `include File ... not found`（如 CBA 调官方函数）→ addon 与当前游戏版本不匹配 → 更新 CBA 至兼容版本
- `Cannot load material file ...` / `No entry 'Cfg.world'` → 游戏文件缺失/损坏 → 校验/重装游戏，删配置缓存

**官方任务（Official Missions 提炼）**
- 官方剧情分支由任务状态变量 + 触发点脚本化驱动，可被 Debug 控制台干预（`setPos` 到触发坐标 + 设状态变量 + 放炸药可跳过结局流程）
- 地雷记录放置者身份，爆炸后仇恨归属到埋雷者；开放世界对象生命周期由清理脚本管理（藏匿箱会 despawn）
- 官方以未加密 EBO + APL-SA 许可交付，不要基于具体 class 名/文件路径做自有内容

**坑（已在 lessons.md 记录）**
- `ActiveRadarComponent` 改用后游戏内雷达默认关闭，改完必须核对开启逻辑；SAM/防空系统必须配雷达才工作
- 出生点放静态载具（航母/驱逐舰甲板）无效驾驶位，多人出生会被拒

## 5. 任务完成标准

代码生成或修改后：过完第 3 节清单 + 把新增经验写回 lessons.md，才算完成。回复用户时给出：改动文件列表、执行端说明（哪段代码在哪台机器上跑）、自检结果。
