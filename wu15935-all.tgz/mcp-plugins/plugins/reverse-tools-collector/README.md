# reverse-tools-collector — 逆向工具收集 MCP

一个 **MCP Server**（Model Context Protocol），用于**收集、检索、分类**逆向工程（Reverse Engineering）工具，供 AI 助手（Claude / Cursor / opencode / Trae / Cline 等）通过 MCP 协议查询。

> 定位：不是执行反汇编的引擎，而是**工具元数据目录/聚合器**——知道"有哪些逆向工具、用来做什么、怎么装、官网在哪"，并把它们按领域（静态分析 / 动态调试 / 脱壳 / 网络协议 / 加密分析 / 移动/固件 等）分类，方便选型与上手。

## 功能（Tools）

| 工具名 | 说明 |
|--------|------|
| `list_tools` | 列出全部已收录的逆向工具，支持 `category` 过滤 |
| `search_tools` | 按关键字（名称/用途/标签）检索工具 |
| `get_tool` | 查看单个工具的完整详情（用途/安装/官网/替代品） |
| `list_categories` | 列出所有工具分类 |
| `suggest_tool` | 根据"我想做什么"（反汇编/脱壳/协议解析…）推荐合适的工具 |
| `add_tool` | 向本地工具库新增一条工具记录（便于用户扩展） |

## 运行方式

纯 Node 实现，**零第三方依赖**，走 MCP **stdio** 传输：

```bash
node server.js
```

### 在 MCP 客户端里注册

以 Claude Desktop / 通用 mcp.json 为例：

```json
{
  "mcpServers": {
    "reverse-tools": {
      "command": "node",
      "args": ["/绝对/路径/到/plugins/reverse-tools-collector/server.js"],
      "env": {
        "RT_TOOLS_FILE": "/绝对/路径/到/plugins/reverse-tools-collector/tools.json"
      }
    }
  }
}
```

> 可选环境变量：
> - `RT_TOOLS_FILE`：工具数据文件路径（默认用同目录 `tools.json`）
> - `RT_PORT`：若设置，则改为走 HTTP/SSE 传输（监听该端口），否则走 stdio

## 目录结构

```
reverse-tools-collector/
├── README.md        # 本说明
├── server.js        # MCP Server 入口（stdio/可选HTTP）
├── tools.json       # 逆向工具数据（可编辑扩展）
└── package.json     # 元数据（无依赖）
```

## 数据文件

`tools.json` 是纯 JSON 数组，每条记录结构：

```json
{
  "name": "radare2",
  "category": "静态分析",
  "description": "开源命令行逆向框架，支持多种架构反汇编/分析",
  "tags": ["反汇编", "调试", "二进制分析"],
  "install": "apt install radare2 或 https://rada.re/r/ 下载",
  "homepage": "https://rada.re/r/",
  "alternatives": ["ghidra", "rizin", "cutter"]
}
```

> 说明：本 MCP 是**元数据收集器**，收录的是"工具本身的信息"，不是被逆向的样本数据。样本分析与加密恢复请配合 IG5 数据车道 / capstone 技能使用。

## 如何扩展

直接编辑 `tools.json` 添加条目即可，重启 MCP Server 生效。也可以用 MCP 工具 `add_tool` 在运行时新增。