class CfgPatches
{
    class TAG_MyUnits
    {
        units[] = {"TAG_Soldier_AT"};
        weapons[] = {};
        requiredVersion = 1.96;
        requiredAddons[] = {"A3_Characters_F"};
    };
};

class CfgVehicles
{
    // 先外部声明原版父类，再继承覆盖差异属性
    class B_Soldier_F;

    class TAG_Soldier_AT: B_Soldier_F
    {
        scope = 2;
        side = 1;
        faction = "BLU_F";
        displayName = "$STR_TAG_Soldier_AT_name";
        uniformClass = "U_B_CombatUniform_mcam";
        linkedItems[] = {"ItemMap", "ItemCompass", "ItemWatch", "ItemRadio", "NVGoggles"};
        respawnLinkedItems[] = {"ItemMap", "ItemCompass", "ItemWatch", "ItemRadio", "NVGoggles"};
    };
};
