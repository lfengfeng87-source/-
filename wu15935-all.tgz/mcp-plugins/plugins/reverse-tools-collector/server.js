#!/usr/bin/env node
/**
 * reverse-tools-collector — 逆向工具收集 MCP Server
 *
 * 纯 Node 实现，零第三方依赖。默认走 MCP stdio 传输（按 JSON-RPC 2.0 over
 * stdin/stdout 的 MCP 协议）；若设置环境变量 RT_PORT 则改走 HTTP/SSE。
 *
 * 数据来自同目录 tools.json（纯 JSON 数组，可编辑扩展），也可用 add_tool 在
 * 运行时新增并落盘。
 *
 * 设计：定位是"工具元数据收集/聚合器"，收录逆向工具本身的信息（用途/安装/
 * 官网/替代品），并按领域分类，帮助选型与上手。不执行反汇编/加密恢复。
 */
'use strict';

const fs = require('fs');
const path = require('path');
const { createServer } = require('http');

// ---------- 常量与配置 ----------
const SERVER_NAME = 'reverse-tools-collector';
const SERVER_VERSION = '1.0.0';
const PROTOCOL_VERSION = '2024-11-05';

const DEFAULT_TOOLS_FILE = path.join(__dirname, 'tools.json');
const TOOLS_FILE = process.env.RT_TOOLS_FILE || DEFAULT_TOOLS_FILE;

// 最大可交互 JSON 长度（防溢出）
const MAX_INPUT = 1024 * 1024; // 1MB

// ---------- 数据加载 ----------
function loadTools() {
  try {
    const raw = fs.readFileSync(TOOLS_FILE, 'utf8');
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr : [];
  } catch (e) {
    // 文件不存在或损坏时不崩，退回空库
    return [];
  }
}

function saveTools(tools) {
  fs.writeFileSync(TOOLS_FILE, JSON.stringify(tools, null, 2) + '\n', 'utf8');
}

// ---------- 工具逻辑 ----------
function listTools(category) {
  let tools = loadTools();
  if (category) {
    const c = String(category).trim();
    tools = tools.filter(t => t.category === c);
  }
  return tools.map(stripDetail);
}

function searchTools(query) {
  const q = String(query || '').toLowerCase().trim();
  if (!q) return [];
  const tools = loadTools();
  const norm = s => String(s || '').toLowerCase();
  return tools
    .filter(t => {
      const hay = [t.name, t.category, t.description, (t.tags || []).join(' ')]
        .map(norm).join(' ');
      return hay.includes(q);
    })
    .map(stripDetail);
}

function getTool(name) {
  const n = String(name || '').trim();
  const tools = loadTools();
  const t = tools.find(x => x.name === n);
  return t ? { ...t } : null; // 详情含 install/homepage/alternatives
}

function listCategories() {
  const tools = loadTools();
  const set = new Set(tools.map(t => t.category).filter(Boolean));
  return [...set].sort();
}

// 简单关键词 -> 分类推荐
const INTENT_MAP = [
  { kw: ['反汇编', '反编译', 'disassembl', 'decompil', '静态'], cat: '静态分析' },
  { kw: ['调试', '动态', 'debug', 'trace', '单步'], cat: '动态调试' },
  { kw: ['脱壳', 'unpack', '加壳', '壳', '混淆', 'obfuscat'], cat: '脱壳混淆' },
  { kw: ['协议', '抓包', 'network', 'packet', '捕获'], cat: '网络协议' },
  { kw: ['加密', '解密', 'crypto', 'cipher', 'key'], cat: '加密分析' },
  { kw: ['移动', 'android', 'ios', 'arm', 'app'], cat: '移动应用' },
  { kw: ['固件', 'iot', '路由器', 'firmware', '嵌入式'], cat: '固件嵌入式' },
];

function suggestTool(intent) {
  const q = String(intent || '').toLowerCase();
  const cat = INTENT_MAP.find(m => m.kw.some(k => q.includes(k)));
  if (!cat) {
    return { hint: '未识别具体意图，可试试：反汇编 / 调试 / 脱壳 / 协议 / 加密 / 移动 / 固件', tools: [] };
  }
  return {
    hint: `根据意图「${intent}」匹配到分类「${cat.cat}」`,
    tools: listTools(cat.cat),
  };
}

function addTool(record) {
  if (!record || typeof record !== 'object' || !record.name) {
    return { ok: false, error: '记录必须包含 name 字段' };
  }
  const tools = loadTools();
  if (tools.some(t => t.name === record.name)) {
    return { ok: false, error: `工具 ${record.name} 已存在` };
  }
  const entry = {
    name: record.name,
    category: record.category || '其他',
    description: record.description || '',
    tags: Array.isArray(record.tags) ? record.tags : [],
    install: record.install || '',
    homepage: record.homepage || '',
    alternatives: Array.isArray(record.alternatives) ? record.alternatives : [],
  };
  tools.push(entry);
  saveTools(tools);
  return { ok: true, tool: entry };
}

function stripDetail(t) {
  return { name: t.name, category: t.category, description: t.description, tags: t.tags };
}

// ---------- MCP 工具定义 ----------
const TOOLS = [
  {
    name: 'list_tools',
    description: '列出全部已收录的逆向工具，可按分类过滤',
    inputSchema: {
      type: 'object',
      properties: { category: { type: 'string', description: '分类名，省略则列出全部' } },
    },
    handler: args => ({ tools: listTools(args.category) }),
  },
  {
    name: 'search_tools',
    description: '按关键字（名称/用途/标签）检索逆向工具',
    inputSchema: {
      type: 'object',
      properties: { query: { type: 'string', description: '检索关键字' } },
      required: ['query'],
    },
    handler: args => ({ results: searchTools(args.query), count: searchTools(args.query).length }),
  },
  {
    name: 'get_tool',
    description: '查看单个逆向工具的完整详情（用途/安装/官网/替代品）',
    inputSchema: {
      type: 'object',
      properties: { name: { type: 'string', description: '工具名，如 radare2' } },
      required: ['name'],
    },
    handler: args => {
      const t = getTool(args.name);
      return t ? { tool: t } : { error: `未找到工具 ${args.name}` };
    },
  },
  {
    name: 'list_categories',
    description: '列出所有逆向工具分类',
    inputSchema: { type: 'object', properties: {} },
    handler: () => ({ categories: listCategories() }),
  },
  {
    name: 'suggest_tool',
    description: '根据想做的事推荐合适的逆向工具',
    inputSchema: {
      type: 'object',
      properties: { intent: { type: 'string', description: '如「反汇编某个ELF」「脱壳一个加壳exe」「抓包分析协议」' } },
      required: ['intent'],
    },
    handler: args => suggestTool(args.intent),
  },
  {
    name: 'add_tool',
    description: '向本地工具库新增一条逆向工具记录',
    inputSchema: {
      type: 'object',
      properties: {
        record: {
          type: 'object',
          description: '工具记录：{name, category, description, tags[], install, homepage, alternatives[]}',
        },
      },
      required: ['record'],
    },
    handler: args => addTool(args.record),
  },
];

const TOOL_MAP = new Map(TOOLS.map(t => [t.name, t]));

// ---------- MCP JSON-RPC 处理 ----------
function rpcResult(id, result) {
  return { jsonrpc: '2.0', id, result };
}
function rpcError(id, code, message) {
  return { jsonrpc: '2.0', id, error: { code, message } };
}

function handleRequest(msg) {
  if (msg.method === 'initialize') {
    return rpcResult(msg.id, {
      protocolVersion: PROTOCOL_VERSION,
      capabilities: { tools: {} },
      serverInfo: { name: SERVER_NAME, version: SERVER_VERSION },
    });
  }
  if (msg.method === 'notifications/initialized') {
    return null; // 无返回
  }
  if (msg.method === 'tools/list') {
    return rpcResult(msg.id, {
      tools: TOOLS.map(({ name, description, inputSchema }) => ({ name, description, inputSchema })),
    });
  }
  if (msg.method === 'tools/call') {
    const params = msg.params || {};
    const tool = TOOL_MAP.get(params.name);
    if (!tool) return rpcError(msg.id, -32602, `未知工具: ${params.name}`);
    try {
      const result = tool.handler(params.arguments || {});
      return rpcResult(msg.id, { content: [{ type: 'text', text: JSON.stringify(result, null, 2) }] });
    } catch (e) {
      return rpcError(msg.id, -32603, `工具执行失败: ${e.message}`);
    }
  }
  return rpcError(msg.id, -32601, `不支持的方法: ${msg.method}`);
}

// ---------- stdio 传输 ----------
function runStdio() {
  let buffer = '';
  process.stdin.setEncoding('utf8');
  process.stdin.on('data', chunk => {
    buffer += chunk;
    if (buffer.length > MAX_INPUT) {
      buffer = '';
      return;
    }
    let idx;
    while ((idx = buffer.indexOf('\n')) >= 0) {
      const line = buffer.slice(0, idx).trim();
      buffer = buffer.slice(idx + 1);
      if (!line) continue;
      let msg;
      try {
        msg = JSON.parse(line);
      } catch {
        continue; // 忽略非法行
      }
      const resp = handleRequest(msg);
      if (resp) process.stdout.write(JSON.stringify(resp) + '\n');
    }
  });
  process.stdin.on('end', () => process.exit(0));
}

// ---------- HTTP/SSE 传输 ----------
function runHttp(port) {
  const server = createServer((req, res) => {
    if (req.method === 'GET') {
      res.writeHead(200, { 'Content-Type': 'text/event-stream' });
      res.write('data: ' + JSON.stringify({
        jsonrpc: '2.0', method: 'notifications/message',
        params: { level: 'info', data: `${SERVER_NAME} v${SERVER_VERSION} SSE 就绪` },
      }) + '\n\n');
      return;
    }
    let body = '';
    req.on('data', d => { body += d; if (body.length > MAX_INPUT) req.destroy(); });
    req.on('end', () => {
      let msg;
      try { msg = JSON.parse(body); } catch { res.writeHead(400).end(); return; }
      const resp = handleRequest(msg);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(resp));
    });
  });
  server.listen(port, () => console.error(`reverse-tools-collector SSE on :${port}`));
}

// ---------- 启动 ----------
const port = parseInt(process.env.RT_PORT, 10);
if (Number.isInteger(port) && port > 0) {
  runHttp(port);
} else {
  runStdio();
}