# Arma 3 开发经验库 (lessons.md)

本文件由 arma3-dev 技能维护：每次任务自检后追加新经验，追加前查重、合并旧条目。

## 条目

[2026-10-22] BI 官方 wiki 直接抓取被拦截
- 现象：webfetch 抓取 community.bistudio.com 返回 403，Google 搜索页也无法直读
- 原因：BI wiki 有反爬限制
- 修复：按已确认的官方惯例整理内容；需要核实时改用 websearch 获取引用片段，仍以 Coding_Conventions、SQF_syntax、CfgPatches 为权威出处
- 来源任务：讲解原版 A3 代码规范

[2026-10-22] 重生后 unit 更换导致变量丢失
- 现象：把状态 setVariable 在旧 body 上，重生后新 unit 取不到
- 原因：重生（BASE 等模式）会创建新 unit 对象，任务中挂在旧对象上的变量随之消失
- 修复：onPlayerRespawn.sqf 的 params 第二项 _corpse 在触发时刻仍存在，直接 `_corpse getVariable` 取；跨机状态则存服务器按 UID 索引
- 来源任务：生成 keep-loadout（重生保留装备）示例脚本

[2026-10-22] HEMTT 报 Addon prefix not found / Duplicate prefix
- 现象：addons/tag_myunit 无论有无 $PBOPREFIX$ 都报前缀类错误
- 原因：HEMTT 要求每个 addon 文件夹必须有 $PBOPREFIX$（无扩展名），内容为完整路径 `mainprefix\prefix\addons\文件夹名`；内容与文件夹末段不一致报 not found，文件与文件夹推导冲突报 duplicate
- 修复：$PBOPREFIX$ 写 `z\tag\addons\tag_myunit` 并保证文件夹名一致
- 来源任务：用 HEMTT 验证 addon-inherited-unit 示例

[2026-10-22] HEMTT v1.22 项目配置与版本声明迁移
- 现象：根目录 hemtt.toml 报 `.hemtt/project.toml not found`，随后要求版本定义
- 原因：v1.22 配置已迁移至 `.hemtt/project.toml`；版本需 `[version]` 表或 script_version.hpp；非 git 项目还须 `git_hash = 0`
- 修复：创建 .hemtt/project.toml 含 name/prefix/mainprefix + [version] major/minor/patch + git_hash = 0
- 来源任务：同上

[2026-10-22] SQF 赋值内联进比较表达式导致解析失败
- 现象：`(_ticks = _ticks + 1) > 120` 被 HEMTT 判 unparseable syntax
- 原因：赋值是语句级构造，静态解析器无法处理其出现在表达式中的形式
- 修复：赋值单独成行再写条件：`_ticks = _ticks + 1; (... == 0) || _ticks > 120`
- 来源任务：生成 bug-hunt 示例修复版（HEMMT 静态分析捕获）

[2026-10-22] params 数组默认值被多包一层导致类型错误
- 现象：`[["_objective", [0,0,0]]]` 报 type not expected（expected String）
- 原因：params 元素形状固定为 [名称, 默认值]，数组默认值外再加方括号会破坏形状解析
- 修复：`["_objective", [0,0,0]]`，所有参数元素保持同一形状
- 来源任务：同上（HEMMT 静态分析捕获）

[2026-10-22] 触发器判定条件不足导致任务不触发
- 现象：触发器/区域清理任务偶发不触发完成
- 原因：触发半径/高度/条件表达式设置不当（如 flare 触发器高度过低）
- 修复：触发前先核对判定参数；用 trigger 条件逐项验证，必要时调大半径或补高度
- 来源任务：Bohemia 论坛 User Missions 版块提炼

[2026-10-22] Autoinit on 覆盖自定义 AI 参数
- 现象：任务里的 AI 生成/难度参数不生效
- 原因：任务属性开了 Autoinit，引擎用内置 AI 初始化覆盖自定义逻辑
- 修复：关闭 Autoinit，或把 AI 初始化并入自己的 init 体系
- 来源任务：同上

[2026-10-22] 反复 spawn/delete 对象内存不释放
- 现象：长期运行的专用服务器内存持续增长、最终卡死
- 原因：引擎对已删除（despawned）对象未完整释放内存，FLUSH 无效
- 修复：引擎层无解；定期轮换/重启任务释放内存；避免高频 createVehiclelocal/deletevehicle 循环
- 来源任务：Bohemia 论坛 Troubleshooting 版块提炼

[2026-10-22] 光照额度被巡逻/手电挤占，夜晚不黑
- 现象：夜间加了大量手电/探照灯后夜晚变亮、黑暗失效
- 原因：引擎光照额度有限，过多动态光源挤掉环境照明
- 修复：控制手电/光源数量，必要时移除部分动态光照
- 来源任务：同上

[2026-10-22] 任务 ID 重复与调用顺序破坏任务逻辑
- 现象：多任务系统里某任务状态错乱
- 原因：两个任务用了相同 ID，或初始化/完成调用顺序不对
- 修复：任务 ID 全局唯一；核对任务创建/完成的调用顺序
- 来源任务：Bohemia 论坛 User Missions 版块提炼

[2026-10-22] ActiveRadarComponent 默认关闭，改完不开机等于白改
- 现象：把传感器改成 ActiveradarComponent 后游戏内雷达不工作
- 原因：改用该组件后雷达默认处于关闭状态，需手动/脚本开启
- 修复：改完 config 须核对传感器状态与开启逻辑；防空系统还必须与雷达正确关联才工作
- 来源任务：Bohemia 论坛 Q&A 版块提炼

[2026-10-22] 多人同步/locality 铁律
- 要点：只有 local 为真的本地 owner（服务器/HC）才能 driver/setVelocity/setDamage；非 owner 端命令无效或不同步；载具驾驶权还受编组位分配约束
- 要点：脚本/模块 createUnit 生成单位在专用服务器打不出伤害——单位须 isServer 创建并 publicVariable 广播（或 Zeus/Eden 预置），damage 判定在服务端权威
- 要点：疲劳/姿态/伤害属服务端权威状态，客户端本地改不同步——setFatigue/远程执行在服务器统一，行为状态机做成 Module 或服务端强制
- 修复：驱动/修改/刷怪代码先判 isServer/hasInterface/local，仅在 owner 端执行
- 来源任务：Bohemia 论坛 Servers / Multiplayer / Modding 版块提炼

[2026-10-22] 服务器连接/JIP 规范
- HC 的 headlessClients[]/localClient[] 通配符/IP 段无效，必须写具体单一 IP；HC 端口主服 +12；HC profile 加 battleyeLicense=1
- JIP 玩家 mod/DLC 集合与服务器不一致拖垮整局——让玩家经 launcher 按服务器集合自动加载，兜底加密码
- 服务器 mod 文件名必须全小写（手动安装不会自动转），核对启动日志 "List of mods" 表
- 来源任务：Bohemia 论坛 Servers / Multiplayer 版块提炼

[2026-10-22] 地图地雷记录放置者，爆炸仇恨归属埋雷人
- 现象：埋雷被 AI 触发爆炸后，所有警察朝埋雷者开枪
- 原因：官方对地雷"行为归属"做了显式追踪，爆炸后仇恨归放置者
- 修复：任务设计埋雷玩法时注意此归属判定，避免玩家被误判敌对
- 来源任务：Bohemia 论坛 Official Missions 版块提炼

[2026-10-22] 脚本/模块 createUnit 生成单位在专用服务器无法造成伤害
- 现象：eden/zeus 预放置的单位能伤害玩家，但脚本/模块/EOS 生成的单位打不出伤害
- 原因：单位由客户端或错误全局上下文创建，damage 判定在专用服务器，AI 与命中需服务端权威
- 修复：用 isServer 创建单位并 publicVariable 广播，或走 Zeus/Eden 预放置；排查链"脚本生成→全局创建→服务器攻击方→目标命中"逐层确认在服务端上下文
- 来源任务：Bohemia 论坛 Modding Discussion 版块提炼

[2026-10-22] 覆盖其它 mod 的 recoil/系数导致冲突
- 现象：武器架设类 mod 与后坐力 mod 冲突，行为异常
- 原因：直接硬改 recoil 会覆盖其它 mod 的系数
- 修复：正确 mod 只叠加自己的效应，不覆盖别人的 recoil
- 来源任务：同上

[2026-10-22] 音频配置大小写敏感，小写静默失效
- 现象：加了音频没声音
- 原因：CustomSoundController 等控制器名必须首字母大写；wav 未转 wss/ogg 或路径大小写不匹配
- 修复：控制器名写 CustomSoundController1（首字母大写）；音频先转 wss/ogg；引擎声 pitch 靠 controller 数值驱动 shader 非改 wav
- 来源任务：Bohemia 论坛 Modding Discussion / Sound Modding 101

[2026-10-22] 多人与单机 damage/疲劳逻辑不同步
- 现象：客户端本地改姿态/疲劳，多人里各端不同步或伤害失效
- 原因：疲劳/姿态/伤害属服务端权威状态，客户端本地改不同步
- 修复：setFatigue/远程执行在服务器统一；行为状态机做成 Module 或服务端强制
- 来源任务：同上

[2026-10-22] RPT 报错反模式三族
- BIS_fnc_* 传参类型错：Type ANY expected STRING / Class '%ALL' not found——把未初始化(nil)/空变量当 STRING 或武器类传入官方函数；调用前校验并初始化参数类型，武器类先确认在 CfgWeapons 存在
- "No entry bin\config.bin" 族：引用了不存在的键/类（mod 或 description.ext 控件缺属性如 mapBox 缺 widthRailWay）、CfgPatches 依赖缺失、include 文件 not found——更新/重装对应 mod + 校验文件或补控件属性
- 崩溃/加载失败族：Cannot load material file、No entry Cfg.world、启动崩溃——多为游戏数据文件缺失/损坏或 DLC 依赖链断裂，Steam 校验/重装 + 删 Documents\Arma 3 缓存
- 来源任务：Bohemia 论坛 Troubleshooting 版块提炼

[2026-10-22] 自写 revive 与 ACE/官方 revive 冲突，复活命令失效
- 现象：player setDamage 0; setVariable ["incapacitated",false] 在某些任务失效
- 原因：任务用 ACE 或官方 revive 状态机时，直接 setDamage 复活命令与 revive 系统不对齐
- 修复：自写 revive 须与 ACE/官方 revive 对齐，必要时关闭默认 revive 替换医疗逻辑
- 来源任务：Bohemia 论坛 User Missions 版块提炼

[2026-10-22] 判任务 fail 与 complete 必须互斥
- 现象：半清场时同帧既报失败又报完成
- 原因：胜败判定逻辑未互斥，条件同时满足
- 修复：判 fail 与判 complete 加互斥；全员阵亡要能正常结束任务防卡 spectator
- 来源任务：同上

[2026-10-22] 动态任务性能：刷怪服务端、trigger 秒级、找位校验
- 现象：动态生成任务服务器负载高、单位刷进石头/空中
- 原因：刷怪在客户端、trigger 每帧、找位不校验
- 修复：刷怪 isServer；trigger 降到秒级；找位函数校验合法落点；巡逻按区域限密度
- 来源任务：同上

[2026-10-22] BI 官方 wiki 被纯 JS Cloudflare 挑战挡，浏览器 UA 无效
- 现象：community.bistudio.com 各页 curl 带浏览器 UA 仍 403/JS 挑战
- 原因：wiki 用纯 JS 渲染挑战，非普通反爬，需真实浏览器或渲染代理
- 修复：权威规范底座改以社区实战 + 官方命令名(BIS_fnc_*)为准；wiki 需真实浏览器/渲染代理访问
- 来源任务：本轮 BI wiki 抓取尝试

[2026-10-22] 炮塔 memory point 缺失/拼写错是最高频坑
- 现象：炮手座坐不上、炮塔能转但打不中、炮手视角偏移
- 原因：memoryPointGetWeaponDir（canHit遮挡判定）/memoryPointGunnerOptics/memoryPointsGetInGunner 任一未在模型 memory LOD 定义同名投影
- 修复：核对模型 memory 点与 config 命名完全一致；proxy 名 A2→A3 移植时须改新规范
- 来源任务：Bohemia 论坛 MODDING 版块炮塔 config 提炼

[2026-10-22] States>>speed 只改动画播放速率，不是真地速
- 现象：改了 CfgMovesMaleSdr 的 speed 得到"狂奔感"而非实际移动距离变化
- 原因：States speed / setAnimSpeedCoef 只控制动画播放速率
- 修复：改真地速用 CfgMoves relSpeedMin/Max + CfgVehicles maxSpeed
- 来源任务：同上

[2026-10-22] 载具炮塔 memory point 缺失/拼写错最高频
- 现象：炮手座坐不上、炮塔能转但打不中、炮手视角偏移、开火从错误位置冒
- 原因：memoryPointGetWeaponDir/canHit判定、memoryPointGunnerOptics、memoryPointsGetInGunner、memoryPointGunOut 任一未在模型 memory LOD 定义同名投影
- 修复：A2→A3 移植核对 proxy 规范变化(pilot需pos driver/pos pilot)；weapons[]/magazines[]成对且继承VehicleWeapon
- 来源任务：Bohemia 论坛 MODDING 版块提炼

[2026-10-22] 动画 config 三坑
- 播放速率≠地速：改 CfgMovesMaleSdr>>States>>speed 只改动画播放速率(假狂奔)，真地速用 relSpeedMin/Max + CfgVehicles maxSpeed
- 继承链：自定义动作须用 class CfgMovesMaleSdr : CfgMovesBasic 派生，平级新建同名状态会覆盖官方；改姿态前确认 state 有返回 transition(否则prone reload卡死)
- 执行上下文：含 sleep 的动画函数须 [] spawn{} 进 scheduled(preinit 直调报 Suspending not allowed)
- 来源任务：Bohemia 论坛 MODDING 版块提炼

[2026-10-22] 技能库远程化：SSH 凭据部署完成
- 现象：技能装在本地 .dsh\skills，仓库 lessons.md 无法同步进化成果
- 原因：origin 用 https 匿名，无 push 权限
- 修复：ed25519 SSH 密钥部署到 Gitee 账户，origin 切 git@gitee.com:wu15935/arma3-dev.git，pull/push 免密闭环
- 来源任务：gitee 权限配置

[2026-10-22] MCP fs 工具操作 Arma 3 目录需扩 ROOT_ALLOW 白名单
- 现象：fs_list/fs_search/fs_read 对 E:/SteamLibrary/.../Arma 3 一律报 outside allowed roots
- 原因：Mega MCP 文件工具安全白名单默认只有 C:\ 和 D:\，游戏装在 E 盘 SteamLibrary 被拒
- 修复：server.py 的 ROOT_ALLOW 加入 "E:\\" 后热生效（stdio 每次调用拉起新进程，无需重启）；同类场景（游戏/工具装非系统盘）直接扩白名单
- 来源任务：用 MCP 管理 Arma 3 安装目录

[2026-10-22] ObfuSQF 混淆任务包格式与提取方法
- 现象：MPMissionsCache 的 Altis_Life.Altis.pbo 无法用标准 PBO 解析（magic 变 00 73 72 65 56）
- 原因：Maverick Applications 的 ObfuSQF 商业混淆（版本86），目录表重写为 \0srpC 标记格式，2711 条目中 366 个脚本全部加密
- 修复：自写解析器按 \0srpC + u32长度×4 + 文件名 提取 2043 个文件（文件名/媒体资源/目录结构完整还原），但 .sqf/.hpp 内容为 ObfuSQF 加密（明文率 0.05%），脚本逻辑不可恢复
- 来源任务：任务包分析（用户 MPMissionsCache）

[2026-10-25] 重生保留装备必须走服务端存储，不能只存旧 body
- 现象：简单实现"Killed 存装备到旧 body 变量，onPlayerRespawn 从 _corpse 取回"当场重生能用，但中途加入(JIP)玩家拿不到装备
- 原因：装备存旧 body 变量依赖尸体留存（尸体清理/despawn 即丢）；JIP 玩家不走 onPlayerRespawn 事件，body 上从没存过装备；且 loadout 是本地 body 变量，非服务端权威，多端场景状态错位
- 修复：服务端维护 UID→loadout 映射（missionNamespace 变量），Killed 时客户端 remoteExecCall 到服务端存；重生(JIP 用 didJIP 分支主动触发) remoteExecCall 请求，服务端查表 remoteExec 回传客户端 applyLoadout。首次玩无记录回传空数组由 applyLoadout 忽略，保留默认出生装备
- 来源任务：完善 keep-loadout 示例补 JIP 缺陷

[2026-10-22] ObfuSQF 加密强度评估：熵分析判定为混淆而非密码学加密
- 现象：148 个加密 .sqf 样本熵 3.74-6.25（强加密应≥7.5），且目录表与数据流交织（srpC 条目 2711 个混排）
- 原因：ObfuSQF 是自定义容器+SQF 级混淆变换，非标准字节流加密；解密逻辑在服务端 OBFUSQF_API.dll（任务包内无此 dll，包内的 234B 假 dll 是目录碎片）
- 修复/结论：直接解密不可行；现实路径是 A.进 RP 服务器内存 dump 明文脚本（最优）/ B.逆向完整 API dll / C.找 unknowncheats 社区已有研究；学框架逻辑用开源 Altis Life v4.x 替代
- 来源任务：用户要求评估加密可否解开

[2026-10-25] CfgGestures 手势动画挂载结构
- 现象：自定义手势（敬礼/比手势/挥动）需要在 config 里声明后才能被 CfgMoves 状态调用，否则引擎找不到动画源
- 原因：手势是独立于移动动画的第二套动画源，挂在单位 model 的 gesture 类目下；引擎按 <路径>_<名称> 规则在渲染时叠加，需在 config 与模型 .rtm/.pac 命名一一对应
- 修复：CfgGestures 下建 class gestures，每个手势一个类（如 class gestureNode1），填 model=视图模型路径、animationName=动画名、animPeriod=时长、animSpeed=播放速度；再用 CfgMoves 的 States>>Gesture 系列状态把手势绑定到输入（GestureBreathe、GestureNo、GestureYes 等），手势名要与模型里动画源/骨骼命名严格一致
- 备注：手势受 CfgMoves 继承链约束（须从 CfgMovesMaleSdr 派生），且只叠加到对应姿势（站立/蹲伏），换姿态要配 transition 返回；本次作为 CfgMoves 之后的增量，BI wiki 反爬不可直读，此条按领域整理
- 来源任务：Arma 3 动画系统学习（CfgGestures 手势）

[2026-10-25] CfgWeapons 武器动作模块：枪口/换弹/动作与瞄准
- 现象：自定义武器开火枪口火光位置错、换弹动画播了弹药没补上、切枪动作不对——根因都在 CfgWeapons 的动作/memory 点字段没配齐
- 原因：枪口与弹壳位置由 memory 点驱动而非 config 坐标——模型 memory LOD 里必须有 muzzle（枪口）、muzzleFlash（火光挂点）、eject（弹壳）同名投影，config 只写挂点名，写错/缺名就回退到模型原点
- 修复：CfgWeapons>>WeaponSlotsInfo/身体动作区配齐四类字段——枪口：MuzzlePos 引用 memory 点 + muzzleFlash 类（火光/音效）；换弹：reloadMagazinePos（弹匣插入点）+ reloadMagazineAnim（换弹动画名）+ reloadAction（reloadMagazine 动作）；切枪：切换动作走 animClass/枪挂载点；瞄准：weaponState 姿势动画配在 CfgMoves，配合 opticsModel/memoryPointCamera 对齐瞄准线
- 备注：换弹关键在动画事件帧与弹药补入时机对齐（弹匣到位帧触发补弹，空仓判定用备用弹药量）；reloadMagazinePos 要与弹匣模型 memory 点对应；本条目与 CfgGestures 同属武器动画学习增量
- 来源任务：Arma 3 武器系统学习（CfgWeapons 枪口/换弹/瞄准）

[2026-10-25] 车载武器动作：weapons[]/magazines[] 成对 + VehicleWeapon 派生
- 现象：载具炮塔装了武器但打不中/开火方向错/同轴机枪不工作——常在 weapons[]/magazines[] 没成对或 weapon 类没用 VehicleWeapon 派生
- 原因：车载武器仍定义在 CfgWeapons，但与士兵武器 3 点不同——基类须用 VehicleWeapon（CannonCore 等）而非 Rifle_Base_F；muzzle/muzzleFlash/reload 等 memory 点定位在炮塔模型而非士兵手臂握持模型；武器实例装在 CfgVehicles>>turrets 里
- 修复：turret 里 weapons[]/magazines[] 成对且顺序一致（每武器一弹种）；多管炮/同轴机枪用子 Turrets 层层嵌套；gunBeg/gunEnd + memoryPointGetWeaponDir 决定弹道方向，canHit 遮挡判定依赖 memoryPointGetWeaponDir 在炮塔模型存在
- 备注（AI 武器动画状态）：车载武器不需给 AI 单独配 CfgMoves 开火动画——AI 开火=炮塔旋转+炮管指向，武器"打"的动作由 ammo muzzleFlash 特效承担；士兵(CfgMovesMaleSdr)才有独立手持武器开火/换弹/瞄准姿势动画(weaponState 系列)，AI 与玩家自动复用同一套，任务里无需给 AI 写武器动画，额外后坐靠 ammo impact/recoil 而非新增状态机
- 来源任务：Arma 3 车辆武器系统学习（车载武器动作 + AI 武器动画）

[2026-10-25] 附件槽位系统：WeaponSlotsInfo + compatibleItems 两道门
- 现象：自制瞄具/消音器/手电做出来了，游戏里装不上（提示 is not compatible with the weapon），或 VA/Eden 里根本找不到
- 原因：附件可装性由"两道门"共同决定——①武器 WeaponSlotsInfo 里对应槽类有正确 linkProxy（MUZZLE/TOP/SIDE/UNDERBARREL 模型代理）；②附件类名在该槽 compatibleItems 列表里。缺任一门都装不上；另 CowsSlot/PointerSlot 是 CfgWeapons 根下的全局槽类（全游戏一份，基类 SlotInfo），重写它们=对所有武器一次性生效
- 修复：全局槽类写法 class CowsSlot : SlotInfo { linkProxy="\\A3\\data_f\\proxies\\weapon_slots\\TOP"; displayName=$STR_A3_CowsSlot0; compatibleItems[]={...}; }; 武器侧 class WeaponSlotsInfo { mass=...; class CowsSlot : CowsSlot {}; class PointerSlot : PointerSlot {}; class MuzzleSlot : SlotInfo { linkProxy="...MUZZLE"; compatibleItems[]={...}; }; }; 大量 mod 直接套 CBA Joint Rails 的 asdg_* 槽类；compatibleItems 类表写法可用 =0 删除继承条目（class compatibleItems: compatibleItems { optic_DMS = 0; }）
- 备注：allowedSlots[]={701 背心/801 制服/901 背包} 是库存槽（放哪件衣兜），与附件槽是两套概念，别写混；UnderBarrel 槽代理在 data_f_mark（\a3\data_f_mark\Proxies\Weapon_Slots\UNDERBARREL）；脚本查兼容列表 getArray (configFile >> "CfgWeapons" >> _typeName >> "WeaponSlotsInfo" >> "CowsSlot" >> "compatibleitems")（论坛 topic 210711/182939 实证）
- 来源任务：Arma 3 武器附件槽位系统学习

[2026-10-25] 瞄具 optics 三层结构：ItemInfo → OpticsModes → weaponInfoType
- 现象：自制瞄具装上了但开镜黑屏/准星错位/无法切倍率/夜视无效；或瞄具在游戏里完全不出现
- 原因：A3 原版没有 CfgWeaponOptics 这个类——瞄具就是 CfgWeapons 下继承 ItemCore 的 optic 类，三层结构：optic 类（weaponInfoType 引用 RscInGameUI 界面类）→ class ItemInfo : InventoryOpticsItem_Base_F（modelOptics 2D 准星、mountAction/unmountAction、allowedSlots 库存槽）→ class OpticsModes（每模式 opticsID/useModelOptics/opticsZoomMin·Max·Init/discreteDistance[]+initIndex/modelOptics[]/memoryPointCamera/visionMode[]/opticsPPEffects[]）
- 修复：按三层填齐；调零界面用 weaponInfoType="RscWeaponZeroing"，带测距用 "RscWeaponRangeZeroingFOV"；夜视模式 visionMode[]={"Normal","NVG"}；scope 必须 ≥1/2（scope=0 的瞄具游戏/VA/Eden 中不出现）；新瞄具必须加进武器 CowsSlot>>compatibleItems 否则装不上；多模式用 class 模式名: 父模式 继承改写，或加 opticsDisplayName 区分
- 备注：ACE3 用 class CBA_ScriptedOptic 外壳（reticleTexture/reticleTextureNight/hideMagnification）做脚本化瞄具，modelOptics 指 cba_optic_big_90.p3d；论坛实测失败案例见 examples/attachment-optics-config/
- 来源任务：Arma 3 瞄具 optics 配置学习

[2026-10-25] 消音器与侧挂附件：ItemInfo 系数改写发射行为
- 现象：装上消音器 AI 照样精准定位开枪位置；或枪口火光/后坐没有明显变化
- 原因：消音器不是"换音效"，而是通过 ItemInfo（InventoryMuzzleItem_Base_F）三类系数改写发射参数：MagazineCoef{initSpeed}、AmmoCoef{hit,visibleFire,audibleFire,visibleFireTime,audibleFireTime,cost,typicalSpeed,airFriction}、MuzzleCoef{dispersionCoef,artilleryDispersionCoef,fireLightCoef,recoilCoef,recoilProneCoef,min/mid/maxRangeCoef}
- 修复：audibleFire/visibleFire 决定 AI 侦测（每项是乘算系数）；声音切换靠 soundTypeIndex 指向武器 sounds[] 索引（0=无消音器，1=SilencedSound）；侧挂附件（手电/IR 激光）用 ItemInfo : InventoryFlashLightItem_Base_F + class Pointer{irLaserPos,irLaserEnd} + class FlashLight{}
- 备注：1.24 版起消音器音效处理改为 soundTypeIndex 方式（旧写法失效）；直接在 CfgAmmo 上改 audibleFire 会波及所有用该弹药武器
- 来源任务：Arma 3 附件 ItemInfo 系数学习

[2026-10-25] 弹匣 magazineWell：武器能否装入的关键机制
- 现象：自定义弹匣在军械库/背包里显示了、悬停也显示"兼容"，但拖到武器上就是装不上（提示 not compatible）
- 原因：弹匣可装性由 CfgMagazineWells 决定——弹匣类名必须出现在武器所关联的某个 magazineWell 的列表里；军械库悬停提示只是静态文本，不代表真兼容（reyhard：BI 开发者）；CfgPatches requiredAddons 若漏填原版加载序（如 A3_Data_F_Enoch_Loadorder）覆盖也不生效
- 修复：正确做法是扩展原版共用 well 的内容，而非在武器上新增 well——
  class CfgMagazineWells { class AK_762x39 /* 共用 well，mod 也生效 */ { Test_Custom_AK_Magazines[] = { "30Rnd_762x39_Mag_Tracer_F_new" }; }; };
  错误做法（会覆盖/冲突）：class CfgWeapons { class arifle_MSBS65_base_F: Rifle_Base_F { magazineWell[] += { "Test_Custom_Promet_Magwell" }; }; };
- 备注：magazineWell 用 += 是想"追加"（但仍需同名 CfgMagazineWells 类定义该 well）；弹匣通过 CfgMagazines>>ammo 字符串指向 CfgAmmo 弹类（改弹药要先继承 CfgAmmo 弹类再让弹匣 ammo 指向它）
- 来源任务：Arma 3 弹匣与弹道学习（论坛 topic 229351）

[2026-10-25] 初速 initSpeed 三级联动：武器/弹匣/枪口附件
- 现象：同一种子弹在步枪/手枪/机枪上初速一样，或装了消音器后弹道没变；想给武器/弹匣改初速但无效
- 原因：初速由"三级"共同决定，优先级 武器>弹匣>附件：①武器 initSpeed>0 直接用；②否则取 CfgMagazines 对应条目 initSpeed 乘以其绝对值；③枪口附件再乘 ItemInfo>>MagazineCoef>>initSpeed（如消音器常见 1.05=增快）。1.42 之前初速只由弹匣决定（同弹匣不同枪无差别），之后武器可覆盖/修饰
- 修复：脚本取弹速 getNumber(configfile >> "CfgWeapons" >> _weapon >> "initSpeed")；取弹丸阻力须经 ammo 间接：getNumber(configFile >> "CfgAmmo" >> getText(configFile >> "CfgMagazines" >> currentMagazine _u >> "ammo") >> "airFriction")（不能把 currentMagazine 当 CfgAmmo 类名）
- 备注：CfgAmmo>>initSpeed 也可以设，但通常优先在弹匣/武器设；magazinesAmmo/magazinesAmmoFull 命令辅助读弹种
- 来源任务：Arma 3 弹匣与弹道学习（论坛 topic 189305 + OPREP Muzzle Velocity）

[2026-10-25] 空气阻力 airFriction 与动力学伤害：子弹仿真不是运动学
- 现象：弹道下坠/衰减不符合预期；不理解 airFriction、hit、caliber、armor 各自作用
- 原因：A3 子弹仿真是动力学（基于力）而非运动学——弹丸受两种力=空气阻力（airFriction，弹丸所受阻力加速度，质量已计入，单位≈m/s²）+ 重力；初速 initSpeed(m/s) 被 airFriction 指数衰减，无风、无空气密度
- 修复：想改下坠/射程调 CfgAmmo>>airFriction（负值=减速，数值越大衰减越快）；伤害由 CfgAmmo>>hit（弹丸能量）+ 命中块 armor/caliber 共同决定——caliber>0 且够高可穿透材质，caliber=0 直接杀死；速度与 typicalSpeed 比较决定部分表现
- 备注：CfgMagazines 也存部分弹丸属性、muzzle velocity 实际在 CfgMagazines/CfgWeapons 而非 CfgAmmo（Config_Properties_Megalist 结论）；子母弹 shotSubmunition / 落地雷 shotDeploy 属 CfgAmmo 高级玩法
- 来源任务：Arma 3 弹匣与弹道学习（BIKI Weapons_settings + Arma_3_Damage_Description + Steam 指南 + fextralife）

[2026-10-25] 载具继承树：LandVehicle → Tank/Tank_F、Car/Car_F，空壳基类只继承不修改
- 现象：自建载具写 class TAG_X: Tank_F 后编译报「基类 NewTurret/MainTurret 不存在」，或在载具类里覆盖 class Turrets 导致全游戏所有坦克炮塔异常
- 原因：A3 的载具基类树是原版自己声明的，NewTurret/MainTurret/CommanderOptics/ViewOptics/ViewPilot/ViewCargo/HeadLimits/AnimationSources/Sounds/HitPoints 都是**空壳声明**（只有名字没有内容），自己的 config 必须先照抄这一段声明才能 : MainTurret 派生。原版注释："Do not modify the inheritance tree, unless you want to alter game's internal configs, or REALLY know what you're doing."
- 修复：照抄原版树再派生——地面 class LandVehicle; class Tank: LandVehicle { class NewTurret; class Sounds; class HitPoints; }; class Tank_F: Tank { class Turrets { class MainTurret: NewTurret { class Turrets { class CommanderOptics; }; }; }; class AnimationSources; class ViewPilot; class ViewOptics; class ViewCargo; class HeadLimits; class HitPoints: HitPoints { class HitHull; class HitEngine; class HitLTrack; class HitRTrack; }; class Sounds: Sounds { class Engine; class Movement; }; }; 轮式把 Tank 换 Car（Car_F 里声明 HitLFWheel/HitLF2Wheel/HitRFWheel/HitRF2Wheel/HitGlass1~6）。自己的类写成 class TAG_MBT_base: Tank_F，可用类再 class TAG_MBT: TAG_MBT_base { scope=2; scopeCurator=2; }
- 备注（常用基类）：地面 LandVehicle→Tank/Tank_F、Car/Car_F、Motorcycle；空中 Air→Helicopter、Plane；水面 Ship→Ship_F；固定 StaticWeapon→StaticMGWeapon/StaticCannon/StaticMortar/StaticAAWeapon/StaticATWeapon。scopeCurator=2 表示 Zeus 可刷
- 来源任务：Arma 3 CfgVehicles 载具配置学习

[2026-10-25] 炮塔层级 Turrets：可无限嵌套 + 多档光学 OpticsIn
- 现象：车长周视镜不转/切不了倍率/探出车外还有黑边光学视图；或炮塔转了但炮管不跟着俯仰
- 原因：炮塔是**嵌套结构**，每层自成一套 body/gun + weapons + optics + hitpoints；body/gun 分别对应模型里"水平转"和"俯仰"的 selection，且要配同名 animationSourceBody/animationSourceGun 动画源。倍率切换靠炮塔里的 class OpticsIn（Wide/Medium/Narrow 三档），不是瞄具那套 OpticsModes
- 修复：class Turrets: Turrets { class MainTurret: MainTurret { body="mainTurret"; gun="mainGun"; animationSourceBody="mainTurret"; animationSourceGun="mainGun"; maxHorizontalRotSpeed=0.78; maxVerticalRotSpeed=0.26;（1 = 45°/秒）stabilizedInAxes=stabilizedInAxesBoth;（0 无/1 仅X/2 仅Y/3 双轴/4 三轴）minElev=-5; maxElev=80; initElev=10; minTurn=-360; maxTurn=360; initTurn=0; weapons[]={"cannon_120mm"}; magazines[]={"24Rnd_120mm_APFSDS_shells_Tracer_Red"}; gunBeg="usti hlavne"; gunEnd="konec hlavne"; memoryPointGun="usti hlavne2"; turretInfoType="RscWeaponRangeZeroingFOV"; discreteDistance[]={100,200,400,600,800,1000,1500,2000,2500,3000}; discreteDistanceInitIndex=3; memoryPointGunnerOptics="gunnerview"; gunnerOpticsModel="...optics_empty"; gunnerOutOpticsModel="";（空串=探出时不要光学视图）class ViewOptics: ViewOptics { initFov=0.155; minFov=0.034; maxFov=0.155; visionMode[]={"Normal","TI"}; thermalMode[]={0,1}; }; class OpticsIn { class Wide: ViewOptics { initFov=0.3; opticsDisplayName="W"; visionMode[]={"Normal","NVG"}; gunnerOpticsModel="..."; }; class Medium: Wide { initFov=0.07; opticsDisplayName="M"; }; class Narrow: Wide { initFov=0.028; opticsDisplayName="N"; }; }; class Turrets: Turrets { class CommanderOptics: CommanderOptics { body="obsTurret"; gun="obsGun"; weapons[]={"SmokeLauncher"}; magazines[]={"SmokeLauncherMag"}; }; }; class HitPoints { class HitTurret {...}; class HitGun {...}; }; }; };
- 备注：FOV 数值 1 = 120°（0.155≈18.6°，0.034≈4°）；viewGunnerInExternal=1 才能被穿甲弹打死炮手；commanding 数字最大者为车长；炮手骨骼名 gunnerLeft/RightHandAnimName 写错直接 CTD；gunnerForceOptics=0 + outGunnerMayFire/inGunnerMayFire=1 才是"能自由看外面"的组合；turretInfoType 还有 RscWeaponRangeArtilleryAuto（自行火炮）/RscOptics_UAV_gunner；weapons[] 里必须是 CfgWeapons 的 VehicleWeapon 派生类，士兵枪械类不能直接挂炮塔
- 来源任务：Arma 3 载具炮塔与炮塔光学学习

[2026-10-25] 载具伤害模型：HitPoints 七字段与 passThrough/explosionShielding
- 现象：自制载具被步枪扫射就爆，或反之手雷贴脸炸不掉；打爆炮塔整车报废；损伤贴图不出现
- 原因：伤害是**按 HitPoint 结算**的，不是整车一坨。车体的 class HitPoints 与炮塔内的 class HitPoints（子类名固定 HitTurret/HitGun）各写一份，字段：armor（该点装甲系数）、material（-1=装甲材质）、name（绑定模型 selection/bone）、visual（受损换材质的视觉 selection）、passThrough、minimalHit、explosionShielding、radius（命中球半径）
- 修复：class HitHull: HitHull { armor=0.8; material=-1; name="telo"; visual="zbytek"; passThrough=1; minimalHit=0.14; explosionShielding=2.0; radius=0.25; }; 要害件 passThrough=1（打爆整车报废），局部件 passThrough=0（断履带/碎玻璃只报废该件），中间态用 0~1；minimalHit 过滤掉步枪弹（如 0.14）；整车还有 armor（结构强度，与包围球体积一起算）与 armorStructural（hull 伤害先除以它）
- 备注（explosionShielding 是唯一的爆炸防护）：动能弹走 FireGeometry 命中球落到 HitPoint；爆炸（indirectHit）直接穿 FireGeometry 不理会装甲，只受该 HitPoint 的 explosionShielding 影响（>1 减伤、<1 更脆）——所以"加钢板"挡不住爆炸。HitPoint 与 FireGeometry 四诫命：① FG 块不要重叠；② 不同类型 FG（armor 与 HP）之间留缝；③ HP 的 FG 要包在均匀分布的命中球阵里；④ 命中球可重叠但只许接触同一类 HP 的 FG。损伤贴图 class Damage { mat[] = {...} } 按**三元组**（完好/受损/报废）排列；A3 坦克 selection 用 zbytek（车体）/vez（炮塔）/zbran（炮管）/vezVelitele/zbranVelitele，ArmA 1 的 trup/telo/karoserie/zbytek 表在 A3 不适用
- 来源任务：Arma 3 载具伤害模型学习

[2026-10-25] 轮式车辆 PhysX 行驶：simulation="carx" + Wheels + complexGearbox
- 现象：自制轮式车起步打滑/原地抖/上坡没劲/高速翻车；或装进游戏后轮子不转、车悬空
- 原因：A3 轮式车是 PhysX 3 **动力学**模型（旧 simulation="car" 已弃用），行驶感由 enginePower/torqueCurve/complexGearbox/Wheels 悬挂四组参数共同决定；且模型必须先满足 PhysX LOD（4e13 车身凸包）+ memory LOD 里 wheel_<纵>_<横>_axis（转轴点）与 wheel_<纵>_<横>_bound（到轴距离=轮半径，纵=从车头数，横=1 左/2 右）
- 修复：simulation="carx"; enginePower=276; maxOmega=471; peakTorque=1253; idleRpm=800; redRpm=4500; brakeIdleSpeed=1.78; thrustDelay=0.2; dampingRateFullThrottle=0.08; dampingRateZeroThrottleClutchEngaged=2.0; dampingRateZeroThrottleClutchDisengaged=0.35; torqueCurve[]={{0.0,0.0},{0.278,0.5},{0.461,1.0},{0.6,0.95},{0.8,0.75},{1.0,0.5}}; class complexGearbox { GearboxRatios[]={"R1",-5.75,"N",0,"D1",4.3,"D2",2.3,"D3",1.5,"D4",1.0,"D5",0.73}; TransmissionRatios[]={"High",6.759}; moveOffGear=1; driveString="D"; neutralString="N"; reverseString="R"; }; changeGearMinEffectivity[]={0.95,0.15,0.95,0.95,0.95,0.95,0.95}; switchTime=0.31; latency=1.0; differentialType="all_limited"; frontRearSplit=0.5; frontBias=1.3; rearBias=1.3; centreBias=1.3; clutchStrength=20.0; antiRollbarForceCoef=12; antiRollbarForceLimit=10; antiRollbarSpeedMin=20; antiRollbarSpeedMax=50; class Wheels { class LF { boneName="wheel_1_1_damper"; steering=1; side="left"; center="wheel_1_1_axis"; boundary="wheel_1_1_bound"; width=0.126; mass=30; MOI=12.8; maxBrakeTorque=10000; maxHandBrakeTorque=0; suspTravelDirection[]={0,-1,0}; suspForceAppPointOffset="wheel_1_1_axis"; tireForceAppPointOffset="wheel_1_1_axis"; maxCompression=0.05; mMaxDroop=0.1; sprungMass=825; springStrength=51625; springDamperRate=8920; longitudinalStiffnessPerUnitGravity=10000; latStiffX=25; latStiffY=180; frictionVsSlipGraph[]={{0,1},{0.5,1},{1,1}}; }; class LR: LF {...}; }
- 备注：GearboxRatios 从倒档开始（负值），N 必须为 0；antiRollbarForceCoef=0 即关闭防侧倾杆（民用车常见）；latency 必须大于 switchTime 否则换挡抖；ARB 的 ForceCoef 是强度、Limit 是上限、SpeedMin/Max 是启用速度窗（低速 0 → Max 升满）；轮子损坏阈值 wheelDamageThreshold=0.7 / wheelDestroyThreshold=0.99 / wheelDamageRadiusCoef=0.95 / wheelDestroyRadiusCoef=0.45；浮水用 simulation="ship" + WaterLeakiness=10（升/秒），canFloat=1 也生效
- 来源任务：Arma 3 载具行驶物理配置学习

## 学习进度（下次继续）
- CfgMoves 移动/姿态动画：已学（relSpeedMin/Max、CfgMovesMaleSdr 继承链、sleep 需 spawn、炮塔 memory 点）
- CfgGestures 手势：已学（本文件 2026-10-25 条目，gestures 类 + CfgMoves 绑定）
- CfgWeapons 武器动作：已学（本文件 2026-10-25 条目，MuzzlePos/muzzleFlash/reloadMagazinePos/reloadMagazineAnim/reloadAction/瞄准）
- CfgWeapons 附件/瞄具 optics 联动：已学（本文件 2026-10-25 三条条目：WeaponSlotsInfo 槽位+compatibleItems 两道门、ItemInfo/OpticsModes/weaponInfoType 三层、消音器/侧挂 ItemInfo 系数）
- CfgMagazines/CfgAmmo 弹药与弹道：已学（本文件 2026-10-25 三条条目：magazineWell 关键机制、initSpeed 三级联动、airFriction 与动力学伤害）
- CfgVehicles 载具：已学（本文件 2026-10-25 四条条目：继承树与类型基类、炮塔层级 Turrets+OpticsIn 多档光学、伤害模型 HitPoints 七字段与 passThrough/explosionShielding、PhysX 轮式行驶 carx+Wheels+complexGearbox）
已完成：CfgVehicles 航空器与舰船（Helicopter/Plane/Ship/StaticWeapon 专属字段、rotorLib 与 AFM/RTD 飞行模型、吊挂 slingload、航母/舰船 simulation="ship"）
- 已产出样例：`examples/weapon-action-config/`（config.cpp 骨架 + README.md），对照原版 pbo 核对 CfgWeapons 枪口/换弹/切枪/瞄准字段（MuzzlePos/muzzleFlash/reloadMagazinePos/reloadMagazineAnim/reloadAction/OpticsModes）
- 已产出样例：`examples/vehicle-weapon-action/`（config.cpp + README.md），核对车载武器 VehicleWeapon 派生、turret weapons[]/magazines[] 成对、gunBeg/gunEnd + memoryPointGetWeaponDir、AI 武器动画状态（车载无需单独 CfgMoves 开火动画）
- 已产出样例：`examples/attachment-optics-config/`（config.cpp + README.md），核对附件槽位两道门（WeaponSlotsInfo/linkProxy + compatibleItems）、瞄具 ItemInfo/OpticsModes/weaponInfoType、消音器三类系数、侧挂 Pointer/FlashLight；资料源＝PMC 镜像官方指南 + ACE3 + CBA Joint Rails + 论坛 210711/182939
- 已产出样例：`examples/magazine-ammo-config/`（config.cpp + README.md），核对弹匣 magazineWell 机制、CfgAmmo 弹药继承、initSpeed 三级联动、airFriction 与动力学伤害；资料源＝论坛 229351/189305 + OPREP Muzzle Velocity + BIKI Weapons_settings
- 已产出样例：`examples/aircraft-ship-config/`（config.cpp + README.md），核对航空器 AFM 参数分离、舰船 simulation="ship" + WaterLeakiness、吊挂 slingload 系统；资料源＝RotorLib XML Profile Authoring Guide + 原版 Boat_F/Frigate config 反推。
- 已产出样例：`examples/vehicle-config/`（config.cpp + README.md），核对载具继承树（Tank_F/Car_F 空壳基类）、Turrets 嵌套 + OpticsIn 三档镜 + ViewOptics、HitPoints 七字段与 passThrough/explosionShielding、Damage mat 三元组、AnimationSources 武器动画源、PhysX 车轮/变速箱/ARB；资料源＝PMC 镜像 BI Cars Config Guidelines + A3 完整载具 config 样例（PLZ05/HMMWV）+ 论坛 201319
