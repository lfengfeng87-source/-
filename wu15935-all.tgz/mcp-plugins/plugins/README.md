# plugins/

存放所有已完成的 MCP 插件。每个插件一个子目录（见根目录 README 的推荐结构）。

