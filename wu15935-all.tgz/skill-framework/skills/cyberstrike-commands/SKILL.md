---
name: cyberstrike-commands
description: CyberStrike 命令行参考技能。触发关键词：cyberstrike, cs, 命令, TUI
---
# CyberStrike 命令行参考

本技能由 skill-framework 生成。核心工作流：先读经验库 → 按规范执行 → 强制自检 → 新经验写回。系统不写死领域逻辑，本文件与同目录 lessons.md 均可在使用中随时补充。

## 0. 自我进化机制（每次任务必做）

**任务开始前**：读本目录 `lessons.md`，逐条对照历史经验，涉及的坑直接套用已验证修复。

**任务结束后**：过第 3 节自检清单，发现新问题立即写回 `lessons.md`：

```
[YYYY-MM-DD] 问题一句话描述
- 现象：
- 原因：
- 修复：
- 来源任务：<一句话>
```

写回前查重，同主题合并更新原条目（更新日期），保持文件精简。跳过写回等于技能退化。

## 1. 责任与范围

**负责**：
- CyberStrike CLI 所有命令的使用与语法记录
- TUI 界面快捷键与操作模式
- 选项参数格式与组合使用
- 会话管理相关命令

**不做**：
- 不提供非法入侵或未授权测试的使用指南
- 不绕过组织安全政策或合规要求

**边界**：
- 仅记录官方提供的命令与选项
- 用户必须在授权的测试范围内使用 CyberStrike
- Token 使用和成本需自行监控

## 2. 执行规范

### 2.1 命令结构概览

CyberStrike CLI 遵循统一的命令结构：

```
cyberstrike [project] [options] [command [args..]]
```

其中：
- `project`：工作目录路径（可选，默认当前目录）
- `options`：全局选项（-h, -v, -m, 等）
- `command`：子命令
- `args`：命令参数

### 2.2 完整命令速查表

| 命令 | 简介 | 关键选项 | 示例 |
|------|------|----------|------|
| `cyberstrike [project]` | 启动 TUI 界面 (默认) | `--port`, `--hostname`, `--model` | `cyberstrike /path/to/project` |
| `cyberstrike --help` | 显示帮助信息 | 无 | `cyberstrike --help` |
| `cyberstrike --version` | 显示版本号 | 无 | `cyberstrike --version` |
| `cyberstrike run [message]` | 运行 CyberStrike 并发送消息 | `-m, --model`, `-p, --prompt` | `cyberstrike run "安全扫描任务"` |
| `cyberstrike hackbrowser <target>` | 爬取 Web 应用并分析 | `--mdns`, `--cors`, `--port` | `cyberstrike hackbrowser https://example.com` |
| `cyberstrike attach <url>` | 连接到运行中的服务器 | `--port`, `--hostname` | `cyberstrike attach http://cyberstrike.local:4096` |
| `cyberstrike auth` | 管理凭据和配置 | 子命令见下表 | `cyberstrike auth list` |
| `cyberstrike models [provider]` | 列出可用 AI 模型 | `--model` 筛选 | `cyberstrike models openai` |
| `cyberstrike stats` | 显示 Token 使用统计 | 无 | `cyberstrike stats` |
| `cyberstrike upgrade [target]` | 升级 CyberStrike | `[target: package@version]` | `cyberstrike upgrade` |
| `cyberstrike uninstall` | 卸载 CyberStrike | 无 | `cyberstrike uninstall` |
| `cyberstrike serve` | 启动头less 服务器 | `--port`, `--hostname`, `--mdns` | `cyberstrike serve --port 8080` |
| `cyberstrike web` | 启动 Web 界面 | `--port`, `--hostname` | `cyberstrike web` |
| `cyberstrike github` | 管理 GitHub 智能体 | 子命令见下表 | `cyberstrike github list` |
| `cyberstrike pr <number>` | 获取并检出 GitHub PR | `<number: PR编号>` | `cyberstrike pr 42` |
| `cyberstrike session` | 管理会话 | 子命令见下表 | `cyberstrike session list` |
| `cyberstrike provider` | 管理 AI 提供商 | 子命令见下表 | `cyberstrike provider add` |
| `cyberstrike skill` | 管理 offensive security 技能 | 子命令见下表 | `cyberstrike skill list` |

### 2.3 子命令细分

#### auth 子命令：
- `cyberstrike auth list` - 列出已保存的凭据
- `cyberstrike auth add` - 添加新凭据
- `cyberstrike auth remove` - 移除凭据

#### github 子命令：
- `cyberstrike github list` - 列出 GitHub 代理
- `cyberstrike github create` - 创建新代理

#### session 子命令：
- `cyberstrike session list` - 列出会话
- `cyberstrike session new` - 创建新会话
- `cyberstrike session continue` - 继续会话

#### provider 子命令：
- `cyberstrike provider list` - 列出提供商
- `cyberstrike provider add` - 添加新提供商
- `cyberstrike provider remove` - 移除提供商

#### skill 子命令：
- `cyberstrike skill list` - 列出技能
- `cyberstrike skill install` - 安装技能

### 2.4 全局选项速查表

| 选项 | 简介 | 数值范围/格式 | 默认值 |
|------|------|--------------|--------|
| `-h, --help` | 显示帮助 | 无 | 无 |
| `-v, --version` | 显示版本 | 无 | 无 |
| `-m, --model` | 使用的 AI 模型 | `provider/model` 格式 | 系统默认 |
| `-c, --continue` | 继续上次会话 | 无 | false |
| `-s, --session` | 指定会话 ID | 字符串 ID | 无 |
| `--fork` | fork 会话时继续 | 无 | false |
| `--prompt` | 使用的提示词 | 字符串 | 无 |
| `--agent` | 使用的智能体 | 字符串 | 无 |
| `--print-logs` | 打印日志到 stderr | 无 | false |
| `--log-level` | 日志级别 | "DEBUG"|"INFO"|"WARN"|"ERROR" | "INFO" |
| `--port` | 监听端口 | 1..65535 | 4096 |
| `--hostname` | 监听地址 | IPv4/IPv6 字符串 | "127.0.0.1" |
| `--mdns` | 启用 mDNS 发现 | 布尔值 | false |
| `--mdns-domain` | mDNS 域名 | 字符串 | "cyberstrike.local" |
| `--cors` | CORS 允许域名 | 字符串数组 | [] |

### 2.5 TUI 界面快捷键

| 功能 | 快捷键 | 说明 |
|------|--------|------|
| 导航上下 | ↑/↓/W/A/S/D | 在选项间移动 |
| 确认执行 | Enter | 选择并执行 |
| 退出层级 | Q/Esc | 返回上一级 |
| 标签页切换 | Tab | 在面板间切换 |
| 搜索过滤 | / | 在当前视图中搜索 |
| 刷新 | F5 | 刷新当前视图 |

## 3. 自检清单（每次产出后逐条过）

通用项：引用 `checks/common-checklists.md`（跨领域通用，系统维护，所有技能共享）。
本领域追加项：

- [ ] 所引用的命令是否与 CyberStrike 官方帮助输出一致？
- [ ] 选项参数的格式是否符合官方文档规定？
- [ ] 是否标注了命令的默认值和有效范围？
- [ ] TUI 快捷键是否基于官方界面交互规范？
- [ ] 是否区分了"CLI 命令使用"（本技能）与"实际测试操作"（红队/攻击路径）的边界，没有越权？

## 4. 快速参考

**常用启动模式**:
```
# TUI 模式 (默认)
cyberstrike

# 指定项目
cyberstrike /my/project

# 继续上次会话
cyberstrike --continue

# 使用指定模型
cyberstrike -m openai/gpt-4o

# Web 界面模式
cyberstrike web

# 服务器模式
cyberstrike serve --port 8080
```

**模型格式**: `provider/model`，常用示例：
- `openai/gpt-4o`, `openai/gpt-4-turbo`
- `anthropic/claude-3-opus`, `anthropic/claude-3-sonnet`
- `google/gemini-pro`, `google/gemini-1.5-flash`

**常用组合**:
```
cyberstrike -m openai/gpt-4o --continue --session sess_12345
cyberstrike hackbrowser https://target.com --mdns
cyberstrike run "扫描任务" --prompt "重点检测 SQL 注入"
```

## 5. 完成标准

产出后：过完第 3 节清单 + 新经验写回 lessons.md，才算完成。回复给出：改动文件清单、执行说明、自检结果。