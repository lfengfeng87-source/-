# User Instruction Memory

This file records user instructions, preferences, and teachings for reference in future interactions.

## Format

### User Instruction Entry
User instruction entries should follow this format:

[User Instruction Summary]
- Date: [YYYY-MM-DD]
- Context: [Mentioned scenario or time]
- Instructions:
  - [Content of user teaching or instruction, described line by line]

### Project Knowledge Entry
Entries discovered by the Agent during task execution should follow this format:

[Project Knowledge Summary]
- Date: [YYYY-MM-DD]
- Context: Discovered by Agent while performing [specific task description]
- Category: [Operations & Deployment|Build Methods|Testing Methods|Troubleshooting & Debugging|Workflow & Collaboration|Environment Configuration]
- Instructions:
  - [Specific knowledge points, described line by line]

## Deduplication Strategy
- Before adding a new entry, check for similar or identical instructions.
- If a duplicate is found, skip the new entry or merge it with the existing one.
- When merging, update the context or date information.

## Entries

[User Instruction Summary]
- Date: 2026-10-22
- Context: arma3-dev 技能仓库创建时用户明确指示
- Instructions:
  - 以后所有远程代码仓库只推送到 gitee，不再使用 GitHub

[Project Knowledge Summary]
- Date: 2026-10-22
- Context: Agent 创建并迭代 arma3-dev 技能时发现
- Category: Environment Configuration
- Instructions:
  - 本项目的 opencode 自定义技能位于 `.opencode/skills/<name>/SKILL.md`，创建或修改后必须重启 opencode 才生效
  - arma3-dev 技能自带经验库 `.opencode/skills/arma3-dev/lessons.md`，按技能约定每次任务后须写回新经验；修改该技能时同步维护两个文件

[Project Knowledge Summary]
- Date: 2026-10-22
- Context: Agent 创建 arma3-dev 技能仓库并推送到远程时发现
- Category: Environment Configuration
- Instructions:
  - 凭据助手连接的是 gitee 账号 `wu15935`，gitee 凭据有效可用于 API 创建仓库和 git 推送
  - 用户已决定 arma3-dev 技能仓库仅维护在 gitee（https://gitee.com/wu15935/arma3-dev，本地副本 /workspace/arma3-dev），明确放弃同步 GitHub，后续无需再提
  - 凭据助手中的 github.com token 已失效（401），如需走 GitHub 流程仍需用户提供新 token

[Project Knowledge Summary]
- Date: 2026-10-22
- Context: Agent 用 HEMTT 验证 Arma 3 addon 示例时发现
- Category: Build Methods
- Instructions:
  - 本环境 api.github.com 返回 403，无法用 GitHub API；下载 GitHub release 可走网页解析：先从 releases/latest 的 Location 头取 tag，再抓 releases/expanded_assets/<tag> 页面解析资源名
  - HEMTT Linux 二进制下载地址模式：https://github.com/BrettMayson/HEMTT/releases/download/<tag>/linux-x64（v1.22.0 已验证可用），下载后 chmod +x 直接运行
  - 用法：项目需 .hemtt/project.toml + addons/<prefix名>/ 结构，hemtt check 可离线 rapify config.cpp、编译 SQF、校验 stringtable
