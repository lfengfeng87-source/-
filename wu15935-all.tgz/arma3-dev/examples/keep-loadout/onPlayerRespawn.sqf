// 运行端：仅重生玩家本地（onPlayerRespawn.sqf）
// 职责：重生时按 UID 从服务端取回该玩家最后一次保存的装备。
// 相比旧实现（从旧 body 取变量），走服务端存储的好处：
//  - 不依赖旧 body 变量，JIP 玩家 / 跨端场景同样可用
//  - 服务端是权威，多端写入顺序由服务端统一
params ["_unit", "_corpse"];

// 阵亡瞬间脚本已经把 loadout 同步到服务端，这里只需请求回传。
// 用 remoteExecCall 让服务端执行 TAG_fnc_getLoadout，它再回传 fn_applyLoadout 到本人客户端。
if (isServer) exitWith {};

[getPlayerUID _unit, owner _unit] remoteExecCall ["TAG_fnc_getLoadout", 2];