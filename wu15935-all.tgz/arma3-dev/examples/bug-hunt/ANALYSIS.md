# bug-hunt 分析报告：fn_reinforce_buggy.sqf

7 处问题全部是语义级错误，SQF 编译与 `hemtt check` 均无法发现，只能靠自检清单逐项排查——这正是清单存在的原因。

| # | 问题 | 触犯的清单项 | 修复 |
|---|------|--------------|------|
| 1 | `spawnGroup` 作为全局函数无 TAG 前缀 | 变量卫生 / 原版规范（命名） | 注册进 CfgFunctions，调用 `TAG_fnc_reinforce` |
| 2 | `_pos = _this select 0`、`_grp` 均无 private/params | 变量卫生 | `params [["_pos", [0,0,0]], ...]` 带默认值；`_grp` 加 `private`（否则泄漏为全局变量） |
| 3 | `createUnit` 无执行端保护，任何端调用都会生成一份单位 | 执行端正确 | 函数入口 `if (!isServer) exitWith {}` |
| 4 | `hint` 在服务端执行时无任何效果（无 UI），玩家看不到 | 执行端正确 | `["援军已出发"] remoteExec ["hint", -2]` 广播到客户端 |
| 5 | `doMove (getPos leader _grp)`：裸 `getPos` 属 Arma 2 遗留写法（返回 ASL，与任务坐标制混用易致高度偏差），且目标点写成了队长自己（援军原地不动） | 坐标一致 + 逻辑正确 | 直接 `doMove _objective`，目标由参数传入；createUnit 后等一帧再下发 |
| 6 | `waitUntil` 无 `uiSleep` 无超时，条件不满足时会在调度线程里空转锁死 | 调度安全 | `uiSleep 5` + 120 次计数兜底（约 10 分钟） |
| 7 | 含 `waitUntil` 的代码块经 `call` 直调，跑在非调度环境（`call` 下 `waitUntil` 直接报错，先于第 6 条触发） | 调度安全 | 清理分组部分拆到 `[] spawn` 中执行 |

## 修复版要点（fn_reinforce_fixed.sqf）

- 入口 `params` 带默认值 + 空坐标守卫（`_pos`/`_objective` 默认 `[]`，为空即退出并提示），防止漏传参数时静默刷兵到地图原点 `[0,0,0]`
- 函数落实 ANALYSIS 第 1 条处方：注册进 CfgFunctions，调用名 `TAG_fnc_reinforce`（不再用裸 `spawnGroup`）
- 提示统一 `remoteExec`；瞬态 hint 对 JIP 玩家丢失属可接受行为，持久状态类信息应改用变量同步
- `createUnit` 后 `uiSleep` 一帧再 `doMove`，避免新单位未入组时同帧移动命令被丢弃
- 单位清理用带 sleep 和超时的 `waitUntil`，超时后仍安全 `deleteGroup`（先 `isNull` 判断防重复清理）

## 验证方式

两个文件复制进 HEMTT 项目后 `hemtt check` 均 "Compiled" 通过——语义级 bug 编译器全放行，清单审查是唯一防线。
