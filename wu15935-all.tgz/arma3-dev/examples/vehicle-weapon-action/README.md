# vehicle-weapon-action — 车载武器动作字段参考（学习样例）

演示 Arma 3 载具（坦克/装甲车/车载枪）如何把武器挂进炮塔并让武器开火/转动/瞄准。这是对照原版车辆 pbo（`\A3\Armor_F\`、`\A3\weapons_f\cannon_30mm\`）逐字段核对的骨架，不含可用模型/动画资源。

## 车载武器与士兵武器的差异

车载武器**仍然定义在 `CfgWeapons`**，字段与士兵武器几乎一致（MuzzlePos/muzzleFlash/reload 等），但有 3 个关键差异：

| 差异 | 说明 |
|------|------|
| 基类用 `VehicleWeapon` | 车载武器从 `VehicleWeapon`（或 CannonCore 等）派生，士兵武器从 `Rifle_Base_F` 等派生 |
| memory 点定位在炮塔模型 | 枪口/muzzleFlash 等 memory 点放炮塔模型，不放士兵手臂握持模型 |
| 挂载靠 CfgVehicles 炮塔 | 武器实例装在 `CfgVehicles>>turrets` 里，成对声明 weapons[]/magazines[] |

## 开火/转动的核心：weapons[]/magazines[] 成对 + memory 点

载具武器"活"起来的关键在 `CfgVehicles>>turrets` 的炮塔配置：

- `weapons[]` / `magazines[]` **必须成对且顺序一致**：每个武器对应一个弹种。多管炮/同轴机枪用子 `Turrets` 层层嵌套。
- `gunBeg` / `gunEnd`：炮管起点与终点 memory 点，决定弹道方向。
- `memoryPointGetWeaponDir`：弹道方向判定点，`canHit` 遮挡判定依赖它在炮塔模型里存在（缺了会"能转但打不中/从错误位置开火"）。
- `memoryPointGunnerOptics` / `memoryPointsGetInGunner`：炮手光学与入座 memory 点。

**关联经验库**：`炮塔 memory point 缺失/拼写错是最高频坑`（lessons.md 2026-10-22）已记录这组 memory 点缺失的 4 种现象。

## AI 武器动画状态（AI weapon animation）

车载武器**不需要给 AI 单独配 CfgMoves 开火动画**——AI 开火就是炮塔旋转 + 炮管指向往复数时间点，武器本身"打"的动作由 ammo 的 muzzleFlash 特效和音效承担。这与士兵武器不同：

- 士兵（CfgMovesMaleSdr）才有独立的手持武器开火/换弹/瞄准姿势动画（weaponState 系列状态）。
- AI 单位**自动复用**士兵动画状态机，任务里无需给 AI 写武器动画，只需保证单位 config 继承正确（AI 与玩家共用同一套 CfgMoves）。
- 想让 AI 有"开火后坐"等额外表现，靠武器后坐力/动画事件（ammo 的 impact/recoil），不是新增状态机。

## 相关经验库条目

- `CfgGestures` 手势动画挂载结构（2026-10-25）
- `CfgWeapons` 武器动作模块（2026-10-25）
- `炮塔 memory point` / `载具炮塔 memory point`（2026-10-22）
- `动画 config 三坑`（2026-10-22，CfgMoves 继承链/sleep 执行上下文）

## 备注
本样例为**配置结构参考**，非可编译 addon。BI 官方 wiki 反爬不可直读，字段以社区实战 + 领域整理为准，仍以原版车辆 pbo 内 config.bin 为权威出处。