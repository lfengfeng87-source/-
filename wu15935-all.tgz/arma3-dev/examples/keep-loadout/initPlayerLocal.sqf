// 运行端：仅每个玩家本地（initPlayerLocal.sqf）
// 职责：
//  1. 监听 Killed：玩家阵亡瞬间把当前装备按 UID 同步到服务端，供重生恢复
//  2. JIP 覆盖：中途加入的玩家没有 onPlayerRespawn 事件，主动向服务端请求自己的 loadout

// --- 阵亡时保存装备到服务端 ---
player addEventHandler ["Killed", {
    params ["_unit"];
    [getPlayerUID _unit, getUnitLoadout _unit] remoteExecCall ["TAG_fnc_setLoadout", 2];
}];

// --- JIP 玩家（中途加入）主动拉取装备 ---
if (didJIP) then {
    // JIP 玩家没有死亡重生的机会，只能从服务端读取"之前保存过"的 loadout
    [getPlayerUID player, owner player] remoteExecCall ["TAG_fnc_getLoadout", 2];
};