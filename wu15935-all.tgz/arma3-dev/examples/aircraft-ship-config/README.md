aircraft-ship-config — 航空器与舰船 CfgVehicles 骨架（学习样例）

对照原版 Heli_Transport_02、Heli_Attack_02 与 Ship_F/Frigate 的 config，演示 A3 航空器与舰船配置的三条主线：
**AFM 参数分离（RotorLib XML）**、**舰船水上物理（simulation="ship"）**、**吊挂 slingload 系统**。文件不可直接进游戏（模型/动画/memory 点都是占位），用途是当字段清单查。

## 核心约定

| 概念 | 写在哪 | 关键点 |
|---|---|---|
| AFM 参数 | `class RotorLibHelicopterProperties`（仅十几个调参/损伤/悬停辅助字段） | **AFM 物理参数不在 config.cpp，而在外部 RotorLib XML**（RTDconfig 指向）。config.cpp 只放常规载具字段（maxSpeed/fuelCapacity）。 |
| 坐标系 | RotorLib XML：X=右 Y=前 Z=上 | 以最接近可用 BIS XML 为基线保留传动/控制器段；不可强行三轴轮式布局。 |
| 舰船水上 | `simulation = "ship"` + `canFloat = 1` + `WaterLeakiness ≈ 10升/秒` | WaterLeakiness 约 10 L/s 是合理起点；两栖动画用 altSource；Propeller 控制器驱动螺旋桨动画。 |
| 舰船命中点 | `class HitPoints` 内 HitHull/HitEngine/HitFuel | 按舱段在 Fire Geometry 之间留空； explosionShielding>1 是唯一防爆手段。 |
| 吊挂 slingload | `class StaticWeapon_Base_F` → `MultipleSlingloads` | 支持将武器吊装并放置在地面。 |
| 继承树 | 航空器：`Helicopter_Base_H → Heli_Transport_02_base_F` / `Heli_Attack_02_base_F` | 舰船：`Ship_F → Frigate_F`。 |

## 1. AFM（高级飞行模型）参数分离

**关键认知**：AFM 物理参数（主旋翼半径、螺距、尾桨配置、传动比、扭矩、惯量等）**不在 config.cpp**，而在外部 RotorLib XML 文件。

- config.cpp 只放 `RotorLibHelicopterProperties` 这十几个「调参/损伤/悬停辅助」字段：
  - `autoHoverCorrection[]`、 `defaultCollective`、 `retreatBladeStallWarningSpeed`、 `maxTorque`、 `stressDamagePerSec`
  - `maxHorizontalStabilizer*`、 `maxVerticalStabilizerStress`、 `horizontalWingsAngleColl*`、 `maxMainRotorStress`、`maxTailRotorStress`
- 真实 AFM 参数在 `RTDconfig` 指向的外部 XML（如 `A3\\Air_F_RTD\\Heli_Transport_02\\RTD_Heli_Transport_02.xml`），内容包含完整的传动/控制器/主旋翼/尾桨参数。

## 2. 舰船水上物理

- `simulation = "ship"`：开启舰船水上物理模型
- `canFloat = 1`：船体不沉，可浮在水面
- `WaterLeakiness ≈ 10升/秒`：进水漏率，约 10 L/s 是合理起点；数值越大漏得越快
- **两栖动画**：用 `altSource` 动画源控制破浪动画
- **Propeller 控制器**：驱动螺旋桨动画（在外部控制器中定义具体映射）
- 舰船命中点：`HitHull`/`HitEngine`/`HitFuel`，`explosionShielding>1` 是唯一防爆手段，Fire Geometry 之间留空

## 3. 吊挂 slingload 系统

- `class StaticWeapon_Base_F` → `class TransportWeapons` → 支持 slingload 吊装
- `class MultipleSlingloads`：多吊点支持，每个吊点对应不同挂载配置
- 可将武器从飞行器或车辆吊装到地面指定位置

## 4. 航空器继承树

```cpp
class Helicopter_Base_H;                              // 基类（AFM 参数于外部 XML）
class Heli_Transport_02_base_F: Helicopter_Base_H {    // 运输直升机
    class RotorLibHelicopterProperties { ... };       // AFM 调参（外部 XML 指向）
    maxSpeed = 300; fuelCapacity = 2500; radarType = 8;
};
class Heli_Attack_02_base_F: Helicopter_Base_H {      // 攻击直升机
    class RotorLibHelicopterProperties { ... };       // AFM 调参（外部 XML 指向）
    maxSpeed = 350; fuelCapacity = 2000; radarType = 7;
};
```

## 5. 舰船继承树

```cpp
class Ship_F { simulation = "ship"; canFloat = 1; WaterLeakiness = 10; ... };  // 舰船基类
class Frigate_F: Ship_F { maxSpeed = 35; fuelCapacity = 15000; ... };         // 护卫舰
```

## 关联经验库

- AFM 参数分离：参考 RotorLib XML Profile Authoring Guide（kb.rkslstudios.info）
- 舰船水上物理：参考原版 Boat_F/Frigate config 反推 + PMC 镜像缺失备注
- 舰船命中点：参考 Arma 3 Damage Description（indirectHit 直穿 FireGeometry，唯一防护 explosionShielding>1）
- 吊挂系统：参考 CfgMagazines/CfgAmmo 学习中的 magazineWell 与 initSpeed 三级联动思路

## 备注

- 本样例所有数值均从原版 A3 config 反推/抄录，实际游戏平衡以 BIS 默认值与服务器设定为准。
- AFM/XML 参数详见 RotorLib XML Profile Authoring Guide（外部文档，非 config.cpp 所及）。
- 舰船官方指南正文仍缺，此处基于 Boat_F/Frigate config 反推，有待进一步核实。
- 水面船只建议在开阔水域测试，避免浅水区卡底或弹道异常。