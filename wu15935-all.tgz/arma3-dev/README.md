# arma3-dev — MonkeyCode / opencode 武装突袭3 开发技能

一个面向 Arma 3（武装突袭3）开发的 opencode 技能：SQF 脚本与 config.cpp 的查看分析、按 BI 原版规范生成代码、静态自检清单、RPT 运行日志排查，以及跨任务持续进化的经验库机制。

## 功能

| 模块 | 内容 |
|------|------|
| 代码查看 | 任务文件结构（mission.sqm / description.ext / init 系列）、CfgFunctions 映射分析、执行入口追踪 |
| 运行时排查 | RPT 日志定位、6 类关键错误 grep 优先级、排查闭环 |
| 代码生成 | SQF 语法要点、locality/JIP/调度器等 7 条强制约定、description.ext 骨架 |
| 静态自检 | 10 项清单：执行端、JIP、废弃 API、坐标混用、变量卫生等 |
| 原版对齐 | 二开代码 vs BI 官方惯例 7 维度差异表，代码生成自动对齐 |
| 自我进化 | `lessons.md` 经验库：任务自检后写回新踩的坑，下次任务先读库再干活 |

## 安装

### 方式一：克隆到项目技能目录（推荐）

```bash
cd <你的项目根目录>
git clone https://gitee.com/wu15935/arma3-dev.git .opencode/skills/arma3-dev
```

### 方式二：配置 skills.paths 指向仓库位置

在 `opencode.json` 中：

```json
{
  "skills": {
    "paths": ["/path/to/arma3-dev"]
  }
}
```

### 激活

重启 opencode 使技能加载。之后对话中提到 Arma 3、武装突袭、SQF、mission.sqm 等关键词即自动触发。

## 使用

对 AI 说人话即可，例如：

- 「帮我写一个 Arma 3 任务：重生后保留武器」
- 「检查这个 fn_reammo.sqf 有没有 locality 问题」
- 「分析这份任务包的 RPT 报错」

技能会自动执行：读经验库 → 按原版规范生成/审查 → 过自检清单 → 新经验写回 lessons.md。

## 示例

- `examples/keep-loadout/` — 重生保留装备：Killed 事件存装备 + onPlayerRespawn 恢复，演示 locality 与 corpse 变量技巧
- `examples/addon-inherited-unit/` — HEMTT 项目结构的 addon 示例：CfgPatches 声明依赖 + 继承 B_Soldier_F 只改差异属性 + stringtable 本地化
- `examples/bug-hunt/` — 教学反面示例：7 处语义级错误（编译全通过）+ 逐条分析报告 + 修复版，演示清单查错流程
- `examples/weapon-action-config/` — 武器动作字段参考：枪口/弹壳 memory 点、换弹（reloadMagazinePos/Anim）、切枪槽位、瞄准 OpticsModes
- `examples/vehicle-weapon-action/` — 车载武器参考：VehicleWeapon 派生、turret weapons[]/magazines[] 成对、炮塔 memory 点、AI 武器动画状态
- `examples/attachment-optics-config/` — 附件槽位 + 瞄具 optics 参考：WeaponSlotsInfo 两道门（linkProxy + compatibleItems）、ItemInfo/OpticsModes/weaponInfoType、消音器三类系数、侧挂 Pointer/FlashLight
- `examples/magazine-ammo-config/` — 弹匣 + 弹药与弹道参考：CfgMagazineWells 关键机制、CfgAmmo 弹药继承、initSpeed 三级联动、airFriction 与动力学伤害
- `examples/vehicle-config/` — 载具 CfgVehicles 参考：Tank_F/Car_F 空壳继承树、Turrets 嵌套 + OpticsIn 三档镜、HitPoints 七字段（passThrough/explosionShielding）、Damage 三元组伤贴、AnimationSources 武器动画源、PhysX 车轮/变速箱/ARB

前三个示例通过 HEMTT v1.22 `hemtt check` 校验（config rapify、SQF 编译、stringtable）；后四个为配置结构参考样例（骨架不含可用模型资源）。addon 示例可离线复现验证：

```bash
cd examples/addon-inherited-unit
hemtt build
```

## 经验库机制

`lessons.md` 是技能的自我进化载体：每次任务中发现的坑（现象/原因/修复）都会追加进去，追加前查重合并。把本地使用中更新的 lessons.md 提交回来，可以让整个仓库的技能越用越强。

## 参考

- [BI Coding Conventions](https://community.bistudio.com/wiki/Coding_Conventions)
- [SQF Syntax](https://community.bistudio.com/wiki/SQF_syntax)
- [CfgPatches](https://community.bistudio.com/wiki/CfgPatches)
