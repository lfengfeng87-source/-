---
name: reverse-tools
description: 逆向工程工具收集与选型技能。负责检索、分类、推荐逆向工具（静态分析/动态调试/脱壳混淆/网络协议/加密分析/移动应用/固件嵌入式），并给出安装与上手指引。触发关键词：reverse, 逆向, 反汇编, 反编译, 脱壳, 工具收集, disassembl, decompil
---

# reverse-tools 技能

本技能由 skill-framework 生成。核心工作流：先读经验库 → 按规范执行 → 强制自检 → 新经验写回。系统不写死领域逻辑，本文件与同目录 lessons.md 均可在使用中随时补充。

## 0. 自我进化机制（每次任务必做）

**任务开始前**：读本目录 `lessons.md`，逐条对照历史经验，涉及的坑直接套用已验证修复。

**任务结束后**：过第 3 节自检清单，发现新问题立即写回 `lessons.md`：

```
[YYYY-MM-DD] 问题一句话描述
- 现象：
- 原因：
- 修复：
- 来源任务：<一句话>
```

写回前查重，同主题合并更新原条目（更新日期），保持文件精简。跳过写回等于技能退化。

## 1. 职责与范围

**负责**：
- 收集、检索、分类逆向工程（RE）工具元数据：名称、分类、用途、标签、安装方式、官网、替代品。
- 根据用户意图（反汇编 / 反编译 / 脱壳 / 抓包 / 加密 / 移动 / 固件）推荐合适的工具。
- 给出工具的安装命令与上手路径（apt / pip / 官网下载）。

**不做**：
- 不直接执行反汇编/反编译/加密恢复（那是 capstone / IG5 数据车道 / 各引擎的职责，本技能只做"工具选型"）。
- 不做被逆向样本本身的分析。

**边界**：数据以工具元数据为主；本机实际可用的引擎受平台/权限限制（如 linux-arm64 无 root 装 gcc、GitHub 不可达等），选型时必须结合本机可安装性给出务实建议。

## 2. 执行规范

**选型流程**：
1. 听清用户意图 → 归入分类：反汇编/反编译/静态 → 静态分析；调试/动态/单步 → 动态调试；脱壳/混淆 → 脱壳混淆；协议/抓包/网络 → 网络协议；加密/解密 → 加密分析；Android/iOS/App → 移动应用；固件/IoT/嵌入式 → 固件嵌入式。
2. 用 `reverse-tools-collector` MCP 的 `suggest_tool` / `search_tools` / `get_tool` 检索候选工具。
3. **结合本机环境过滤**：本机是 linux-arm64 (Android rootfs, glibc, 用户 dshbox 非 root, 无 gcc)。
   - 可用：python 生态（`pip install capstone/unicorn/angr/frida/mitmproxy`）、纯命令（`apt` 类需 root 会失败，改用源码/静态/纯脚本）。
   - 需 root 或编译的（gdb 源码、radare2 源码、ghidra 需 JDK）在本机可能装不上，如实说明。
4. 给出结论：推荐 1-3 个 + 安装命令 + 官网。

**强制约定**：
- 涉及 GitHub 下载时先测网络可达（本机 github.com 常 000 不可达，api.github.com 可达），不可达要给替代源。
- 涉及需 root 的安装先说明 dpkg 的 "requires superuser privilege" 限制。
- 不臆造版本号/命令，未验证的安装命令标注"待验证"。

## 3. 自检清单（每次产出后逐条过）

通用项：引用 `checks/common-checklists.md`（跨领域通用，系统维护，所有技能共享）。
本领域追加项：

- [ ] 推荐的工具是否真的可用于本机（linux-arm64/无root/GitHub可达性）？
- [ ] 安装命令是否经过验证或明确标注"待验证"？没有臆造版本号？
- [ ] 是否给出了官网/官方来源？替代品是否合理？
- [ ] 是否区分了"工具元数据收集"（本技能）与"实际分析"（capstone/IG5）的边界，没有越权？

## 4. 快速参考

**本机可用逆向工具速查（实测）**：
- capstone 5.0.7：`venv/bin/pip install capstone`，多架构反汇编库（本机已有 disasm.py 封装，ELF/PE/Mach-O + --funcs/--strings/--xrefs）。
- pyelftools 0.33：`pip install pyelftools`，ELF 解析（节表/符号表）。
- unicorn / angr / frida / mitmproxy：`pip install ...` 均可（纯 wheel，无需 gcc）。
- 需 root 才装的（本机装不上，如实说明）：apt 系 gdb/radare2/wireshark、ghidra(需 JDK 且 GitHub 不可达)。

**分类速查**：静态分析=radare2/rizin/ghidra/idapro/cutter/capstone；动态调试=gdb/lldb/x64dbg/unicorn/angr；脱壳混淆=upx/obfuscator-llvm；网络协议=wireshark/tshark/tcpdump/burpsuite/mitmproxy；加密分析=openssl/hashcat/john；移动应用=frida/apktool/jadx；固件嵌入式=binwalk/qemu。

**MCP 接入**：`node plugins/reverse-tools-collector/server.js`（stdio），tools: list_tools/search_tools/get_tool/list_categories/suggest_tool/add_tool。

## 5. 完成标准

产出后：过完第 3 节清单 + 新经验写回 lessons.md，才算完成。回复给出：改动文件清单、执行说明、自检结果。