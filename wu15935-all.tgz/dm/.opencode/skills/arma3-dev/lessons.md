# Arma 3 开发经验库 (lessons.md)

本文件由 arma3-dev 技能维护：每次任务自检后追加新经验，追加前查重、合并旧条目。

## 条目

[2026-10-22] BI 官方 wiki 直接抓取被拦截
- 现象：webfetch 抓取 community.bistudio.com 返回 403，Google 搜索页也无法直读
- 原因：BI wiki 有反爬限制
- 修复：按已确认的官方惯例整理内容；需要核实时改用 websearch 获取引用片段，仍以 Coding_Conventions、SQF_syntax、CfgPatches 为权威出处
- 来源任务：讲解原版 A3 代码规范

[2026-10-22] 重生后 unit 更换导致变量丢失
- 现象：把状态 setVariable 在旧 body 上，重生后新 unit 取不到
- 原因：重生（BASE 等模式）会创建新 unit 对象，任务中挂在旧对象上的变量随之消失
- 修复：onPlayerRespawn.sqf 的 params 第二项 _corpse 在触发时刻仍存在，直接 `_corpse getVariable` 取；跨机状态则存服务器按 UID 索引
- 来源任务：生成 keep-loadout（重生保留装备）示例脚本

[2026-10-22] HEMTT 报 Addon prefix not found / Duplicate prefix
- 现象：addons/tag_myunit 无论有无 $PBOPREFIX$ 都报前缀类错误
- 原因：HEMTT 要求每个 addon 文件夹必须有 $PBOPREFIX$（无扩展名），内容为完整路径 `mainprefix\prefix\addons\文件夹名`；内容与文件夹末段不一致报 not found，文件与文件夹推导冲突报 duplicate
- 修复：$PBOPREFIX$ 写 `z\tag\addons\tag_myunit` 并保证文件夹名一致
- 来源任务：用 HEMTT 验证 addon-inherited-unit 示例

[2026-10-22] HEMTT v1.22 项目配置与版本声明迁移
- 现象：根目录 hemtt.toml 报 `.hemtt/project.toml not found`，随后要求版本定义
- 原因：v1.22 配置已迁移至 `.hemtt/project.toml`；版本需 `[version]` 表或 script_version.hpp；非 git 项目还须 `git_hash = 0`
- 修复：创建 .hemtt/project.toml 含 name/prefix/mainprefix + [version] major/minor/patch + git_hash = 0
- 来源任务：同上

[2026-10-22] SQF 赋值内联进比较表达式导致解析失败
- 现象：`(_ticks = _ticks + 1) > 120` 被 HEMTT 判 unparseable syntax
- 原因：赋值是语句级构造，静态解析器无法处理其出现在表达式中的形式
- 修复：赋值单独成行再写条件：`_ticks = _ticks + 1; (... == 0) || _ticks > 120`
- 来源任务：生成 bug-hunt 示例修复版（HEMMT 静态分析捕获）

[2026-10-22] params 数组默认值被多包一层导致类型错误
- 现象：`[["_objective", [0,0,0]]]` 报 type not expected（expected String）
- 原因：params 元素形状固定为 [名称, 默认值]，数组默认值外再加方括号会破坏形状解析
- 修复：`["_objective", [0,0,0]]`，所有参数元素保持同一形状
- 来源任务：同上（HEMMT 静态分析捕获）
