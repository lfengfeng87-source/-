class CfgVehicles
{
    // Helicopter Base - AFM parameters in external RotorLib XML, config.cpp only has tuning/damage/hover helpers
    class Helicopter_Base_H
    {
        class Turrets { class MainTurret; class RotorLibHelicopterProperties };
    };

    // Transport helicopter - AFM params separated into RotorLib XML
    class Heli_Transport_02_base_F: Helicopter_Base_H
    {
        // RotorLibHelicopterProperties: AFM 物理参数不在 config.cpp，而在外部 RotorLib XML（RTDconfig 指向）
        class RotorLibHelicopterProperties
        {
            RTDconfig = "A3\\Air_F_RTD\\Heli_Transport_02\\RTD_Heli_Transport_02.xml";
            // 以下为常规调参/损伤/悬停辅助字段（配合 RTDconfig 使用）
            autoHoverCorrection[] = {4.7,3.8,0};
            defaultCollective = 0.665;
            retreatBladeStallWarningSpeed = 92.583;
            maxTorque = 4014;
            stressDamagePerSec = 0.0033333332;
            maxHorizontalStabilizerLeftStress = 10000;
            maxHorizontalStabilizerRightStress = 10000;
            maxVerticalStabilizerStress = 10000;
            horizontalWingsAngleCollMin = 0;
            horizontalWingsAngleCollMax = 0;
            maxMainRotorStress = 250000;
            maxTailRotorStress = 20000;
        };

        maxSpeed = 300;
        fuelCapacity = 2500;
        fuelConsumptionRate = 0.138;
        radarType = 8;
    };

    // Attack helicopter - AFM params in external XML
    class Heli_Attack_02_base_F: Helicopter_Base_H
    {
        class RotorLibHelicopterProperties
        {
            RTDconfig = "A3\\Air_F_RTD\\Heli_Attack_02\\RTD_Heli_Attack_02.xml";
            autoHoverCorrection[] = {5.2,4.1,0};
            defaultCollective = 0.71;
            retreatBladeStallWarningSpeed = 88.4;
            maxTorque = 3500;
            stressDamagePerSec = 0.0035;
            maxHorizontalStabilizerLeftStress = 12000;
            maxHorizontalStabilizerRightStress = 12000;
            maxVerticalStabilizerStress = 12000;
            horizontalWingsAngleCollMin = 0;
            horizontalWingsAngleCollMax = 0;
            maxMainRotorStress = 300000;
            maxTailRotorStress = 25000;
        };

        maxSpeed = 350;
        fuelCapacity = 2000;
        fuelConsumptionRate = 0.15;
        radarType = 7;
    };

    // Ship base - simulation="ship" for water physics
    class Ship_F
    {
        simulation = "ship";
        canFloat = 1;
        // WaterLeakiness: 约 10 升/秒（合理起点，具体视船体大小调整）
        WaterLeakiness = 10;
        // 两栖动画用 altSource 动画源
        class AnimationSources
        {
            class AltSurface
            {
                source = "user";
                animPeriod = 1.0;
                initPhase = 0;
            };
        };
        // 螺旋桨控制器驱动螺旋桨动画
        class Propeller
        {
            source = "user";
            id = 1;
        };
        // 舰船命中点：HitEngine/HitHull/HitFuel（按舱段在 Fire Geometry 之间留空）
        class HitPoints: HitPoints
        {
            class HitHull
            {
                armor = 1.2;
                material = -1;
                name = "telo";
                visual = "";
                passThrough = 1;
                minimalHit = 0.1;
                explosionShielding = 1.5;
                radius = 0.3;
            };
            class HitEngine
            {
                armor = 1.0;
                material = -1;
                name = "motor";
                passThrough = 0.8;
                minimalHit = 0.2;
                explosionShielding = 1.2;
                radius = 0.35;
            };
            class HitFuel
            {
                armor = 0.5;
                material = -1;
                name = "palivo";
                visual = "";
                passThrough = 0;
                minimalHit = 0.15;
                explosionShielding = 0.8;
                radius = 0.25;
            };
        };
        maxSpeed = 30;
        fuelCapacity = 5000;
    };

    // Frigate - larger ship with detailed ship config
    class Frigate_F: Ship_F
    {
        // Additional ship-specific fields
        // canFloat=1 + WaterLeakiness≈10升/秒 继承自 Ship_F
        // 舰船官方指南正文仍缺，此处按 Boat_F/Frigate config 反推填入
        maxSpeed = 35;
        fuelCapacity = 15000;
        // Propeller 控制器驱动螺旋桨动画（具体映射在外部控制器中）
        class Propeller: Propeller {};
    };

    // Static weapon with slingload support
    class StaticWeapon_Base_F
    {
        // slingload 系统：可以吊装该武器并放置在地面
        class TransportWeapons
        {
            // 可被 slingload 吊装的武器类型
        };
        // 吊挂点定义
        class MultipleSlingloads
        {
            // 多吊点支持：每个吊点对应不同的挂载配置
        };
    };
};