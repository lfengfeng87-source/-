// 教学用反面示例：含 7 处典型问题，编译全部通过
// 逐条分析见同目录 ANALYSIS.md，修复版见 fn_reinforce_fixed.sqf
spawnGroup = {
    _pos = _this select 0;
    private _grp = createGroup east;
    "O_Soldier_F" createUnit [_pos, _grp];
    { _x doMove (getPos leader _grp) } forEach units _grp;
    hint "援军已出发";
    waitUntil { ({ alive _x } count units _grp) == 0 };
    deleteGroup _grp;
};

[getMarkerPos "mkr_reinforce"] call spawnGroup;
