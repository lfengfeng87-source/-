# attachment-optics-config — 附件槽位 + 瞄具 optics 参考（学习样例）

演示 Arma 3 附件体系的规范写法：**槽位系统（WeaponSlotsInfo / compatibleItems）**、**瞄具 optic 类**、**消音器 / 侧挂附件的 ItemInfo 系数**。这是对照原版 pbo（`\A3\weapons_f\acc`、`\A3\weapons_f_mark\acc` 的 config.bin）与 ACE3 / CBA 真实 config 核对的骨架，不含可用模型资源。

## 核心约定：附件可装 = 两道门

附件"做出来了但在游戏里装不上"是武器 mod 最高频问题，根因几乎都在联动关系而不是附件本身：

| 门 | 位置 | 内容 |
|---|---|---|
| 门1：槽要有代理 | 武器类下的 `class WeaponSlotsInfo` 子类（CowsSlot / PointerSlot / MuzzleSlot / UnderBarrelSlot） | `linkProxy` 指向模型槽位代理 |
| 门2：附件要入列表 | 同槽的 `compatibleItems` | 附件类名必须在列表里，否则报 *is not compatible with the weapon* |

常用代理路径：

| 槽 | linkProxy |
|---|---|
| 枪口附件（消音器） | `\A3\data_f\proxies\weapon_slots\MUZZLE` |
| 顶部瞄具 | `\A3\data_f\proxies\weapon_slots\TOP` |
| 侧挂（手电/激光） | `\A3\data_f\proxies\weapon_slots\SIDE` |
| 下挂（两脚架） | `\a3\data_f_mark\Proxies\Weapon_Slots\UNDERBARREL` |

## 字段对照

### 1. 槽位系统（WeaponSlotsInfo）

- **`CowsSlot` / `PointerSlot` 是 `CfgWeapons` 根下的全局槽类（全游戏一份）**：基类 `SlotInfo`，不是每把武器各自定义。在自己的 `CfgWeapons` 里重写它们 = 对所有武器一次性生效（mod 常用手法，CBA Joint Rails 整个 `asdg_*` 体系就是这么组织的）。
- 武器侧只引用：`class CowsSlot : CowsSlot {};`、`class PointerSlot : PointerSlot {};`。
- `compatibleItems` 两种写法等价：数组 `compatibleItems[] = {"optic_Arco", ...};` 或类表 `class compatibleItems { optic_Arco = 1; };`。**类表写法下 `= 0` 可删除继承条目**（`class compatibleItems: compatibleItems { optic_DMS = 0; };`）。
- `allowedSlots[]` **是库存槽**（701 战术背心 / 801 制服 / 901 背包），决定这件附件放哪个"衣兜/背包"里，**和附件槽不是一回事**，别写混。
- 脚本读取兼容列表：`getArray (configFile >> "CfgWeapons" >> _typeName >> "WeaponSlotsInfo" >> "CowsSlot" >> "compatibleitems")`。

### 2. 瞄具 optic（ItemCore → ItemInfo → OpticsModes）

A3 原版**没有** `CfgWeaponOptics` 这个类——瞄具就是 `CfgWeapons` 下继承 `ItemCore` 的 optic 类。三层结构：

```
class ItemCore;
class InventoryOpticsItem_Base_F;
class MyOptic : ItemCore {
    scope = 2;
    weaponInfoType = "RscWeaponZeroing";     // 引用 RscInGameUI 界面类
    class ItemInfo : InventoryOpticsItem_Base_F {
        class OpticsModes {
            class Collimator { ... };
            class Scope { ... };
        };
    };
};
```

每模式（`OpticsModes` 子类）字段：

| 字段 | 作用 |
|---|---|
| `opticsID` | 模式编号（切换顺序） |
| `useModelOptics` | 0 = 纯 FOV，1 = 用 `modelOptics` 2D 贴图 |
| `opticsZoomMin` / `Max` / `Init` | 视野缩放（放大倍率高 → 数值小） |
| `discreteDistance[]` + `discreteDistanceInitIndex` | 调零距离档位与初始档 |
| `modelOptics[]` | 准星贴图 p3d（可多级） |
| `memoryPointCamera` | 相机挂点（"eye" / "opticView" 等，需模型有对应 memory 点） |
| `visionMode[]` | 视效模式，夜视需 `{"Normal", "NVG"}` |
| `opticsPPEffects[]` | 开镜后处理（如 "OpticsCHAbera1"、"OpticsBlur1"） |
| `opticsFlare` / `opticsDisablePeripherialVision` | 眩光 / 关闭周边视野 |
| `opticsDisplayName` | 模式显示名（如 "WFOV"） |

**关键联动（论坛 topic 210711 实测）**：新瞄具必须在武器的 `WeaponSlotsInfo >> CowsSlot >> compatibleItems` 里收录，否则一切配置都对也装不上。另外 `scope = 0` 的瞄具在游戏 / VA / Eden 中完全不出现。

### 3. 消音器（ItemInfo: InventoryMuzzleItem_Base_F）

消音器不是"改音效"，而是改写发射系数：

- `MagazineCoef { initSpeed }`：初速系数。
- `AmmoCoef { hit, visibleFire, audibleFire, visibleFireTime, audibleFireTime, cost, typicalSpeed, airFriction }`：可见/可听程度（**AI 侦测核心**）、命中、弹道系数。
- `MuzzleCoef { dispersionCoef, artilleryDispersionCoef, fireLightCoef, recoilCoef, recoilProneCoef, min/mid/maxRangeCoef }`：散布、后坐、射程。
- `soundTypeIndex`：选武器 `sounds[]` 的索引（0 = 无消音器，1 = "SilencedSound"）。

### 4. 侧挂（ItemInfo: InventoryFlashLightItem_Base_F）

```
class ItemInfo : InventoryFlashLightItem_Base_F {
    class Pointer { irLaserPos = "laser_pos"; irLaserEnd = "laser_dir"; };
    class FlashLight {};    // 留空 = 只发光
};
```

`Pointer` 的两个 memory 点决定 IR 激光从哪里射出、指向哪里，同样要求模型 memory LOD 有同名点。

## 与相关经验库条目的关联

- `CfgWeapons 武器动作模块`（lessons.md 2026-10-25，MuzzlePos / reloadMagazinePos / muzzleFlash memory 点体系）
- `车载武器动作`（lessons.md 2026-10-25，WeaponSlotsInfo 在载具武器上的用法）
- `CfgGestures 手势动画`（lessons.md 2026-10-25，reloadAction 等动作名落到 CfgMoves/CfgGestures）

## 备注

本样例为**配置结构参考**，非可编译 addon。资料来源：PMC Editing Wiki 镜像的 BI 官方《BIS Weapon Config Guidelines》、ACE3（`addons/optics/CfgWeapons.hpp`）、CBA_A3（`addons/jr/jr_classes.hpp` Joint Rails 全局槽类）、Bohemia 论坛实战帖（topic 210711 / 182939）。BI 官方 wiki 本体反爬 403，以社区镜像与实战 config 为准，最终仍以原版 pbo 内 config.bin 为权威出处。
