// =============================================================
//  magazine-ammo-config — 弹匣 magazineWell + 弹药与弹道参考（学习样例）
// -------------------------------------------------------------
//  演示 Arma 3 弹药体系的三件事：
//   1) 弹匣可装性：CfgMagazineWells 的 magazineWell 关键机制
//   2) 弹药继承：CfgAmmo 弹类 + 弹匣 ammo 字段指向
//   3) 初速 initSpeed 三级联动 + 空气阻力 airFriction 与伤害
//  不含可用模型资源，仅作配置结构参考。
// =============================================================

class CfgPatches
{
    class TAG_Magazines
    {
        units[] = {};
        weapons[] = {};
        magazines[] = {"TAG_30Rnd_762x39_Mag"};
        requiredVersion = 1.96;
        // requiredAddons 必须含原版加载序，否则覆盖不生效（漏填是本主题最常见的坑）
        requiredAddons[] = {"A3_Data_F", "A3_Weapons_F"};
    };
};

// ---------- 弹药：继承原版弹类，改伤害/初速 ----------
class CfgAmmo
{
    // 父类声明（原版已有，重定义只为继承）
    class BulletBase;
    class B_762x39_Ball_F;
    class B_556x45_Ball;

    // 自定义弹类：继承原版 7.62x39 弹，改 hit 提升伤害
    class TAG_762x39_Ball : B_762x39_Ball_F
    {
        hit = 240;              // 弹丸能量（伤害值），越大越痛
        // initSpeed 通常不在此设，优先在弹匣/武器设（见 initSpeed 三级联动）
        // airFriction 是弹丸所受空气阻力加速度（质量已计入，单位≈m/s²），
        //   负值=减速，数值越大衰减越快；想改下坠/射程就调它
        airFriction = -0.00042;
    };

    // 子母弹 / 落地雷是 CfgAmmo 高级玩法（此处仅注释示例）
    // class TAG_Sub : BulletBase { shotSubmunition = 1; submunitionAmmo="..."; triggerDistance=...; };
};

// ---------- 弹匣：ammo 指向自定义弹类 ----------
class CfgMagazines
{
    // 父类声明
    class CA_Magazine;
    class 30Rnd_762x39_Mag_F;

    // 自定义弹匣：继承原版 7.62x39 弹匣，改弹药
    class TAG_30Rnd_762x39_Mag : 30Rnd_762x39_Mag_F
    {
        ammo = "TAG_762x39_Ball";    // 弹匣通过 ammo 字符串指向 CfgAmmo 弹类
        displayName = "30Rnd 7.62mm TAG Mag";
        // initSpeed 可在此设（m/s 初速），但武器 initSpeed>0 时以武器为准
        initSpeed = 3000;
    };
};

// ---------- 关键：magazineWell 决定弹匣能否装入武器 ----------
class CfgMagazineWells
{
    // 正确做法：扩展原版"共用 well"的内容，而非在武器上新增 well。
    // AK_762x39 是所有 7.62x39 AK 家族共用的 well，mod 也能共享它。
    class AK_762x39
    {
        TAG_762x39_Mags[] =
        {
            "TAG_30Rnd_762x39_Mag"   // 把自定义弹匣挂进这个 well
        };
    };
};

// ---------- 错误做法（对比，勿用） ----------
// 在武器上 += 新增 well 会覆盖/冲突，且仍需同名 CfgMagazineWells 类定义该 well。
/*
class CfgWeapons
{
    class Rifle_Base_F;
    class arifle_AK12_F : Rifle_Base_F
    {
        magazineWell[] += { "TAG_New_Magwell" };
    };
};
*/

// ---------- 脚本参考 ----------
// 取武器初速：      getNumber(configfile >> "CfgWeapons" >> _weapon >> "initSpeed")
// 取弹丸阻力：      getNumber(configFile >> "CfgAmmo" >> getText(configFile >> "CfgMagazines"
//                        >> currentMagazine _unit >> "ammo") >> "airFriction")
// 注意：不能把 currentMagazine 直接当 CfgAmmo 类名，要经弹匣 ammo 字段间接