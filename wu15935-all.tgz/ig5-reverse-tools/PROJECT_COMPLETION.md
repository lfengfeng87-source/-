# 逆向工具项目完成报告（行程/进度文档）

> 生成时间：2026-10-24 · 宿主：linux-arm64（Debian 13 trixie / Android rootfs, glibc 2.41）· 用户 dshbox（uid 11101 非 root）

---

## 一、项目目标回顾

1. **初始**（m00002）：诊断「IG5 逆向工作台不工作」的根因并修复。
2. **演进**：确认静态引擎无法启用 → 转向 IG5 纯数据工具车道（ig5_crypto/ig5_protocol）→ 搜索并落地可用的逆向工具（capstone 反汇编器）。
3. **最终授权**（m00527）：修复 disasm.py 全部已知限制，无任何限制，修复后自我检查，有错自己修，无需逐次审批。

---

## 二、最终结论（已确认）

### 1. IG5 静态引擎在本宿主**不可用**（硬性分发/平台限制）
| 障碍 | 证据 |
|---|---|
| 运行时包缺失 | 插件是 source-only npm 副本，`runtimes/` 目录整体不存在 |
| 平台硬编码 | `source/reverse_runtime.js:31` → `if(host.id!=='win32-x64') return fail('platform')` |
| Windows-only 资产 | `setup_ghidra_runtime.ps1` 只拉 Windows x64 JDK + amd64 Python |
| GitHub 不可达 | `github.com`→000（拿不到 Ghidra 12.1.4 本体） |
| 无 pwsh/java | 系统无 PowerShell、无 JDK |

### 2. IG5 数据工具车道**可用**（不依赖静态引擎）
- `ig5_crypto` / `ig5_protocol` 核心函数为纯 ES module 导出，可直接 node import。
- 端到端 8 步验证全部通过（见 `lane_output.txt`）：XOR 单/复密钥恢复、AES-256-CBC 解密、AES-256-GCM 认证、报文解析、状态机建模。

### 3. 逆向工具（capstone）**落地可用** —— `disasm.py`
- 用 venv 隔离安装 **capstone 5.0.7**（aarch64 轮子，无需 root/编译器）。
- 跨平台反汇编：**ELF / PE / Mach-O / 原始字节**，架构 arm64/arm/thumb/x86/x64。

---

## 三、交付物清单

| 文件 | 说明 | 状态 |
|---|---|---|
| `/root/安装功能/disasm.py` | capstone 跨平台反汇编工具（19.5 KB，492 行） | ✅ 完成 |
| `/root/安装功能/venv/` | 隔离环境（capstone 5.0.7 + pyelftools 0.33） | ✅ 完成 |
| `/root/安装功能/drive_crypto_lane.mjs` | IG5 数据车道 8 步驱动脚本 | ✅ 完成 |
| `/root/安装功能/lane_output.txt` | 8 步输出结果 | ✅ 完成 |
| `/root/安装功能/samples/` | 构造的加密/报文样本（XOR/AES） | ✅ 完成 |
| `/root/安装功能/PROJECT_COMPLETION.md` | 本文档 | ✅ 完成 |

---

## 四、disasm.py 功能清单

**用法**：
```
venv/bin/python disasm.py <文件> [架构] [偏移] [字节数] [--funcs|--strings|--xrefs|--hex|--sections|--max-size]
```

**格式识别**：自动探测 ELF64/32、PE32/PE32+、Mach-O（大小端）、原始字节。

**入口解析**：
- ELF：phdr/vaddr→offset 映射
- PE：e_lfanew→PE 头→AddressOfEntryPoint + ImageBase（PE32+ 0x20b）
- Mach-O：LC_MAIN（0x80000028）entryoff

**选项**：
- `--funcs`：扫描整个 `.text` 节，收集 call 目标为函数入口
- `--strings`：提取 ≥4 可打印 ASCII 字符串
- `--xrefs`：标注 `bl->/b->` 分支目标
- `--hex`：显示原始字节
- `--sections`：列出节表（pyelftools）
- `--max-size`：超大数据流式读取防 OOM

**健壮性**：文件不存在/非法偏移/4 字节 ELF/目录/未知架构/越界 → 全部友好报错，退出码 2。

---

## 五、修复记录

### 本轮（m00527 授权后）修复的缺陷
1. **CS_OP_IMM 常量错误**（关键 bug）：capstone 5.0.7 中 `CS_OP_IMM=2`（非 3），`branch_target()` 改为 `if op.type==CS_OP_IMM` → `--funcs/--xrefs` 才真正检测到分支目标。
2. **流式路径地址全为 0**：超大数据分支强制 `fmt='elf'` → `--max-size` 显示正确入口地址。
3. **越界静默**：新增诊断——入口/偏移超出文件大小时 stderr 明确报错并退出码 2；窗口被截断时提示。
4. **PE 入口「bug」厘清**：实为测试夹具构造错误（`b'PE\x00\x00'` 需精确位于 `e_lfanew` 指向处），`pe_entry()` 本身正确，已用合法 PE32+ 夹具验证入口 `0x140001000`。

### 早前（更早轮次）已修复
- 7 类输入错误 + 地址显示瑕疵（ELF 自动入口时 vaddr→offset 双重叠加）。

---

## 六、自我检查结果（最终）

### disasm.py 18 项全量回归 —— **PASS=18 FAIL=0**

| 组 | 用例 | 期望 | 结果 |
|---|---|---|---|
| R1 | 文件不存在 | rc=2 | ✅ |
| R2 | 非法偏移 | rc=2 | ✅ |
| R3 | 4 字节 ELF | rc=0 | ✅ |
| R4 | 目录 | rc=2 | ✅ |
| R5 | 未知架构 | rc=2 | ✅ |
| R6 | /bin/sh 入口 0x4ac0 | rc=0 | ✅ |
| R7 | python3.13 入口 0x61aec0 偏移 0x21aec0 | rc=0 | ✅ |
| N1 | --funcs（311 个函数） | rc=0 | ✅ |
| N2 | --strings（225 条） | rc=0 | ✅ |
| N3 | --xrefs | rc=0 | ✅ |
| N4 | --hex | rc=0 | ✅ |
| N5 | --sections（26 节） | rc=0 | ✅ |
| N6 | --max-size 100 流式 | rc=0 | ✅ |
| N7 | PE 入口 0x140001000 | rc=0 | ✅ |
| N8 | Mach-O 入口 0x800 | rc=0 | ✅ |
| E1 | 越界诊断 | rc=2 | ✅ |
| E2 | 显式越界 | rc=2 | ✅ |
| E3 | 截断 | rc=2 | ✅ |

### 数据工具车道（lane_output.txt，8 步）—— 全部通过
XOR 单字节 0x7F ✓ · XOR 重复 "ABC9" ✓ · AES-CBC 解密 ✓ · AES-GCM 认证 passed ✓ · 报文解析 ✓ · 状态机 8 状态 ✓

---

## 七、记忆归档（灵枢，已读回确认可检索）

| 节点 id | 内容 |
|---|---|
| `mem_1792809046885_143000` | IG5 数据工具车道可用性验证 |
| `mem_1792814910436_d2dd8c` | capstone ARM64 反汇编验证 |
| `mem_1792815623869_f15a94` | A/B 双路径结论（capstone 可用 vs radare2/rizin 受限） |
| `mem_1792816447852_211e1f` | disasm.py 健壮性修复 |
| `mem_1792819878580_7e944c` | disasm.py 完整版升级 |
| `mem_1792822608599_b33040` | 完整版升级 + 越界诊断（超集） |
| `mem_1792823912314_3f93c7` | 越界诊断修复 + 18 项全量自测确认 |

---

## 八、遗留 / 可选增强（不在本次范围）

- **radare2 / rizin**：需 root（装 gcc 源码编译）或联网机（预编译 arm64 静态包），当前环境不可行。
- **IG5 静态引擎**：需联网 Windows x64 主机跑 `install.ps1`，或联网 Linux 主机手工组装 linux-arm64 运行时包。
- 可选为 disasm.py 增加 `--cfg`（控制流图）、`--pseudo`（伪代码）、`--deps`（符号/导入解析）。

> 结论：**项目已完成**。核心逆向工具（capstone/disasm.py）与 IG5 数据车道均可无静态引擎运行，全部修复经自我检查通过，记忆已归档。