# vehicle-config — 载具 CfgVehicles 骨架（学习样例）

对照原版 `Tank_F` / `Car_F` 与 PLZ05、HMMWV 的 config，演示 A3 载具配置的三条主线：**类型继承树**、**炮塔层级 + 炮塔光学**、**伤害模型 HitPoints**。文件不可直接进游戏（模型/动画/memory 点都是占位），用途是当字段清单查。

## 核心约定

| 概念 | 写在哪 | 关键点 |
|---|---|---|
| 内部继承树 | `LandVehicle → Tank → Tank_F` / `LandVehicle → Car → Car_F` | `NewTurret`/`MainTurret`/`CommanderOptics`/`ViewOptics`/`HeadLimits` 是空壳基类，**只继承不修改** |
| 炮塔 | `CfgVehicles >> Turrets >> MainTurret` | 可无限嵌套；每层自带 body/gun、weapons、optics、hitpoints |
| 炮塔光学 | 炮塔里的 `class ViewOptics` / `class OpticsIn` | `OpticsIn` 里 Wide/Medium/Narrow 三档，可切换倍率 |
| 火控 | 炮塔里的 `turretInfoType` + `discreteDistance[]` | 决定 HUD 用哪个调零界面、预设距离档位 |
| 伤害 | `class HitPoints`（车体）+ 炮塔内的 `class HitPoints` | 七字段：armor/material/name/visual/passThrough/minimalHit/explosionShielding(+radius) |
| 损伤贴图 | `class Damage >> mat[]` | 每材质三元组：完好 / 受损 / 报废 |
| 武器动画 | `class AnimationSources` | `source="reload"/"ammorandom"/"revolving"` + `weapon="..."` |
| 行驶物理 | `simulation="carx"` + `class Wheels` + `class complexGearbox` | PhysX 3 动力学模型，参数在原版车 config 里抄最稳 |

## 1. 类型继承树

A3 原版自己这样声明（`Tank_F` 为例，照抄进自己的 config 才不会冲掉全局）：

```cpp
class LandVehicle;
class Tank: LandVehicle { class NewTurret; class Sounds; class HitPoints; };
class Tank_F: Tank
{
    class Turrets { class MainTurret: NewTurret { class Turrets { class CommanderOptics; }; }; };
    class AnimationSources; class ViewPilot; class ViewOptics; class ViewCargo; class HeadLimits;
    class HitPoints: HitPoints { class HitHull; class HitEngine; class HitLTrack; class HitRTrack; };
    class Sounds: Sounds { class Engine; class Movement; };
};
```

原版注释写得很清楚：*"Do not modify the inheritance tree, unless you want to alter game's internal configs, or REALLY know what you're doing."* 自己的载具一律 `class TAG_X: Tank_F` / `: Car_F` 派生，只填空壳类，不改树。

常用类型基类：

- 地面：`LandVehicle` → `Tank`/`Tank_F`、`Car`/`Car_F`、`Motorcycle`
- 空中：`Air` → `Helicopter`、`Plane`
- 水面：`Ship` → `Ship_F`
- 固定：`StaticWeapon` → `StaticMGWeapon`/`StaticCannon`/`StaticMortar`/`StaticAAWeapon`/`StaticATWeapon`

## 2. 炮塔层级与炮塔字段

```
Turrets
└─ MainTurret              ← 主炮塔（body/gun = 水平/俯仰 selection）
   ├─ Turrets
   │  └─ CommanderOptics   ← 车长周视镜，再嵌一层
   ├─ class OpticsIn       ← 多档光学（W/M/N）
   ├─ class ViewOptics     ← 单档视镜
   └─ class HitPoints      ← HitTurret / HitGun（名字固定）
```

核心字段分组：

| 组 | 字段 | 说明 |
|---|---|---|
| 动画 | `body` `gun` `animationSourceBody` `animationSourceGun` `animationSourceHatch` `selectionFireAnim` | 指向模型 bone/selection |
| 转速 | `maxHorizontalRotSpeed` `maxVerticalRotSpeed` | **1 = 45°/秒** |
| 稳定器 | `stabilizedInAxes` | 0 无 / 1 仅 X / 2 仅 Y / 3 双轴 / 4 三轴 |
| 限位 | `minElev` `maxElev` `initElev` `minTurn` `maxTurn` `initTurn` `maxCamElev` `elevationMode` | 单位度 |
| 火炮 | `weapons[]` `magazines[]` `gunBeg` `gunEnd` `memoryPointGun` | weapons 与 magazines 成对；弹种可多于武器 |
| 火控 | `turretInfoType` `discreteDistance[]` `discreteDistanceInitIndex` | 如 `RscWeaponRangeZeroing` / `RscWeaponRangeZeroingFOV` / `RscWeaponRangeArtilleryAuto` |
| 光学 | `memoryPointGunnerOptics` `memoryPointGunnerOutOptics` `gunnerOpticsModel` `gunnerOutOpticsModel` `gunnerOpticsEffect[]` `gunnerHasFlares` | `gunnerOutOpticsModel=""` = 探出时不给光学视图 |
| 动作 | `gunnerAction` `gunnerInAction` `gunnerGetInAction` `gunnerGetOutAction` `*HandAnimName` | 骨骼名写错会 **CTD** |
| 交互 | `commanding` `hasGunner` `startEngine` `viewGunnerInExternal` `outGunnerMayFire` `inGunnerMayFire` `gunnerForceOptics` | `viewGunnerInExternal=1` 才能用穿甲弹打死炮手 |

**FOV 数值约定：`1 = 120°`**。`initFov=0.155` ≈ 18.6°，`0.034` ≈ 4°。

多档光学（能在游戏里按档位切换的那个系统）：

```cpp
class OpticsIn
{
    class Wide: ViewOptics      // 也可 : Wide 继承
    {
        initFov = 0.3; minFov = 0.3; maxFov = 0.3;
        opticsDisplayName = "W";                    // HUD 上显示
        visionMode[] = {"Normal", "NVG"};           // NVG/TI 可选
        thermalMode[] = {4, 5};
        gunnerOpticsModel = "...\optics_w.p3d";
    };
    class Medium: Wide { initFov = 0.07; opticsDisplayName = "M"; };
    class Narrow: Wide { initFov = 0.028; opticsDisplayName = "N"; };
};
```

## 3. 伤害模型 HitPoints

字段语义：

| 字段 | 含义 |
|---|---|
| `armor` | 该命中点装甲系数，越大越难穿 |
| `material` | `-1` = 用装甲材质 |
| `name` | 绑定模型 selection / bone（贴图与命中都靠它） |
| `visual` | 受损时换材质的视觉 selection，`""` = 无 |
| `passThrough` | `1` = 要害（打爆整车报废）；`0` = 局部件（断履带/碎玻璃）；`0<p<1` = 中间态 |
| `minimalHit` | 低于此值的伤害不计（过滤步枪弹） |
| `explosionShielding` | **爆炸伤害系数，唯一能挡 `indirectHit` 的手**：`>1` 减伤、`<1` 更脆 |
| `radius` | 命中球半径 |

同一套字段在**车体**和**炮塔**各写一份，炮塔里子类名固定为 `HitTurret` / `HitGun`。

两个必须知道的机制：

1. **动能弹**走 FireGeometry 命中球 → 落到某个 HitPoint；**爆炸（indirectHit）直接穿 FireGeometry**，只受 `explosionShielding` 影响——所以「贴纸装甲挡不住爆炸」。
2. HitPoint 与 FireGeometry 的**四诫命**（BI《Vehicle Hitpoint Creation》）：① FG 块之间不要重叠；② 不同类型 FG（armor 与 HP）之间留缝隙；③ HP 的 FG 要包在**均匀分布**的 HP 命中球阵里；④ 命中球之间可以重叠，但只许接触同一类 HP 的 FG。

爆炸伤害判定链（`explosionShielding` 生效的地方）：

```
CfgAmmo(indirectHit / indirectHitRange)
   → 穿 FireGeometry（不受阻挡）
   → 命中点所在 HitPoints >> explosionShielding 折算
   → 累加到该 HitPoint 的伤害池 → 超过 armor 阈值后受损/摧毁
```

## 4. 损伤贴图 class Damage

`mat[]` 是**三元组**排列：完好 / 受损 / 报废，顺序不能错。

```cpp
class Damage
{
    tex[] = {};
    mat[] =
    {
        "...\body.rvmat", "...\body_damage.rvmat", "...\body_destruct.rvmat",
        "...\turret.rvmat", "...\turret_damage.rvmat", "...\turret_destruct.rvmat"
    };
};
```

伤贴靠 `visual` 指定的 selection 换材质：A3 坦克车体用 `zbytek`，炮塔 `vez`，炮管 `zbran`，车长镜 `vezVelitele`，车长机枪 `zbranVelitele`。
（ArmA 1 时代的表是 `trup` 直升机 / `telo` 履带车 / `karoserie` 轮式 / `zbytek` 飞机，**和 A3 不一样**，照 A1 教程抄会不生效。）

## 5. 武器驱动动画 AnimationSources

```cpp
class AnimationSources: AnimationSources
{
    class muzzle_rot_cannon { source = "ammorandom"; weapon = "autocannon_35mm"; };
    class recoil_source     { source = "reload";     weapon = "autocannon_35mm"; };
    // 还有 reloadmagazine / revolving / trigger
};
```

`weapon=` 必须和炮塔 `weapons[]` 里的类名一致，否则动画源永远不动。

## 6. 轮式车辆行驶（PhysX 3）

```
simulation = "carx";              // 轮式载具唯一选择
```

- **模型要求**：一个 PhysX LOD（4e13）放车身凸包（60 面够用，轮子由引擎加）；memory LOD 里每个轮子要 `wheel_<纵>_<横>_axis`（转轴）与 `wheel_<纵>_<横>_bound`（到轴距离=轮半径），`纵`=从车头数，`横`=1 左 / 2 右。
- **Wheels 子类**：`boneName` `steering` `side` `center` `boundary` `width` `mass` `MOI` `maxBrakeTorque` `maxHandBrakeTorque` `suspTravelDirection[]` `suspForceAppPointOffset` `tireForceAppPointOffset` `maxCompression` `mMaxDroop` `sprungMass` `springStrength` `springDamperRate` `longitudinalStiffnessPerUnitGravity` `latStiffX/Y` `frictionVsSlipGraph[]`
- **complexGearbox**：`GearboxRatios[]` 从倒档开始（负值）、`N` 必须为 0、前进档正；`TransmissionRatios[]` 可选高低档；`moveOffGear` / `driveString` / `neutralString` / `reverseString`
- **自动挡**：`changeGearMinEffectivity[]`（空档 ~0.15，前进档 ~0.95）、`switchTime`（~0.3s）、`latency`（须 > switchTime）
- **防侧倾杆 ARB**：`antiRollbarForceCoef`（0 = 关闭）、`antiRollbarForceLimit`、`antiRollbarSpeedMin/Max`（低速 0 系数，到 Max 升满）
- **其它**：`thrustDelay`（起步油门爬升）、`brakeIdleSpeed`（低于此速自动刹）、`idleRpm`/`redRpm`、`dampersBumpCoef`、`differentialType`/`frontRearSplit`/`frontBias`/`rearBias`/`centreBias`/`clutchStrength`
- **损坏**：`wheelDamageThreshold=0.7` `wheelDestroyThreshold=0.99` `wheelDamageRadiusCoef=0.95` `wheelDestroyRadiusCoef=0.45`

## 7. 车灯 / 尾气 / 后视镜

- `class Reflectors`：`color[]` `ambient[]` `position` `direction` `hitpoint` `selection` `size` `innerAngle` `outerAngle` `coneFadeCoef` `intensity` `useFlare` `dayLight` `flareSize` + `class Attenuation{start, constant, linear, quadratic, hardLimitStart, hardLimitEnd}`；`aggregateReflectors[]` 把多灯合并计算省性能。
- `class Exhausts`：`position` `direction` `effect`（如 `ExhaustEffectTankBack`）。
- `class RenderTargets`：`renderTarget="rendertarget0"` + `class CameraView1{pointPosition, pointDirection, renderQuality(0~2), renderVisionMode(0=HDR/1=NV/2=TI/3=Color/4=Mirror), fov}`；模型里材质用 `#(argb,256,512,1)r2t(rendertarget0,1.0)`。

## 关联经验库

- `lessons.md`「[2026-10-25] 车载武器动作：weapons[]/magazines[] 成对 + VehicleWeapon 派生」——本文件第 2 节的武器侧细节在那条。
- `lessons.md`「[2026-10-25] 载具伤害模型：HitPoints 七字段与 passThrough/explosionShielding」——本文件第 3 节的来源条目。
- `examples/vehicle-weapon-action/`——只讲武器怎么挂上炮塔；本文件讲载具本体。

## 备注

- 资料源：PMC Editing Wiki 镜像的 BI《Cars Config Guidelines》（pmc.editing.wiki/doku.php?id=arma3:config:bis-cars-config-guidelines，2024-08-02）、`Port ArmA 2 Vehicles To ArmA 3` 的完整 A3 config 样例、PLZ05 自行火炮 A3 config（含 OpticsIn 三档镜）、Bohemia 论坛 topic 201319（炮塔相机/opticsDisplayName 写法）、BI《Turret Config Reference》《Damage Description》《Vehicle Hitpoint Creation》。
- BI 官方 wiki（community.bistudio.com）直抓仍 403，本文件内容取自 PMC 镜像与带完整 config 的第三方样例，字段名均能在原版 pbo 里对照到。
- **Tanks Config Guidelines 页在 PMC 镜像上没有**（只有 cars / weapon 两份），坦克专有内容靠原版 config 反推。
