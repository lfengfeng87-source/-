# reverse-tools 经验库（lessons.md）

本文件记录逆向工具收集/选型过程中踩过的坑与已验证结论，随使用持续更新。任务前先读，逐条对照。

## 已收录经验

[2026-05-06] 本机 linux-arm64 的逆向工具可用性边界
- 现象：选型时若不先考虑本机环境，容易推荐"装不上"的工具。
- 原因：宿主是 Android rootfs / glibc / 用户 dshbox 非 root；无 gcc/编译器；apt/dpkg 需 root（"requires superuser privilege"）；github.com 下载常 000 不可达（api.github.com 可达）。
- 修复：先确认意图分类 → 再用 MCP 检索 → **最后必须按本机可安装性过滤**。python 生态（capstone/unicorn/angr/frida/mitmproxy 纯 wheel）可 pip 装；需 root 或编译或 GitHub 资产的一律说明替代路径。
- 来源任务：reverse-tools 技能创建时整理本会话 capstone/radare2 实测结论。

[2026-05-06] capstone 是本机唯一跑通的逆向引擎
- 现象：radare2/rizin/ghidra 在本机都装不上（无 root / GitHub 不可达 / 需 JDK）。
- 原因：见上一条环境边界。
- 修复：用 capstone（`venv/bin/pip install capstone`，实测 5.0.7 aarch64 wheel 成功），已封装成 disasm.py（ELF/PE/Mach-O + --funcs/--strings/--xrefs/--hex/--max-size 流式）。
- 来源任务：A/B 双路径验证（capstone 可用 vs radare2 受限）。

[2026-05-06] MCP 客户端配置注意
- 现象：社区版 mcp-gitee 包名曾被我臆断为 @gitee/mcp-gitee@latest，未经验证。
- 原因：Gitee 官方仓库以 Go 源码为主，npm 分发在 feat/distribute-by-npm 分支。
- 修复：不臆造安装命令；社区版先 go install gitee.com/oschina/mcp-gitee@latest 或查官方分支确认，未验证标注"待验证"。
- 来源任务：Gitee 个人版 MCP 调研。