// =============================================================
//  vehicle-weapon-action — 车载武器动作字段参考（学习样例）
// -------------------------------------------------------------
//  演示载具(坦克/装甲车/车载枪)如何把武器挂到炮塔、让武器能开火/
//  转动/瞄准。这是对照原版车辆 pbo（\A3\weapons_f\...\config.bin、
//  \A3\Armor_F\...）逐字段核对的骨架，不含可用模型/动画资源。
//  关联经验库："炮塔 memory point 缺失/拼写错是最高频坑"、
//  "载具炮塔 memory point" 两条。
// =============================================================

// ---------- 1) 载具武器类（CfgWeapons，本质是"炮管"）----------
// 车载武器与士兵武器同在一个 CfgWeapons，但作为炮塔武器时要用
// VehicleWeapon 派生，且 muzzle 系 memory 点定位在炮塔模型上。
class CfgWeapons
{
    class VehicleWeapon;                       // 车载武器基类（官方）

    class TAG_VehCannon: VehicleWeapon
    {
        scope = 2;
        displayName = "TAG 30mm Cannon";
        // 车载武器的枪口/memory 点指向炮塔模型（见 CfgVehicles turret）
        model = "\A3\weapons_f\cannon_30mm\cannon_30mm.p3d"; // 占位
        cursor = "EmptyCursor";
        cursorSize = 1;
        reloadTime = 0.15;
        // 炮管弹药：单根炮管用 magazineName 声明弹种，威力和特效在 CfgAmmo
        magazineReloadTime = 10;
        magazines[] = {"TAG_30Rnd_30mm_shells"};
        // 车载武器开火特效/音效同样由 ammo 的 muzzleFlash 驱动，
        // 武器只挂 memory 点（muzzle/muzzleFlash），位置在炮塔模型里。
        class GunParticles   // 炮口烟雾等，挂 muzzle memory 点
        {
            class effect1
            {
                positionName = "muzzleFlash";
                directionName = "muzzle";
                effectName = "TAG_smoke";
            };
        };
    };

    class TAG_VehMG: VehicleWeapon  // 同轴机枪（第二根炮管）
    {
        scope = 2;
        displayName = "TAG Coaxial MG";
        model = "\A3\weapons_f\mg\mg.p3d";       // 占位
        cursor = "EmptyCursor";
        reloadTime = 0.09;
        magazines[] = {"TAG_200Rnd_762x51_shells"};
    };
};

// ---------- 2) 载具类（CfgVehicles：把武器装进炮塔）----------
// 关键：turret 里的 weapons[]/magazines[] 必须成对出现且数量对得上，
// 引用的武器类须已在 CfgWeapons 定义（用 VehicleWeapon 派生）。
class CfgVehicles
{
    class Tank_F;

    class TAG_Tank: Tank_F
    {
        scope = 2;
        side = 1;
        faction = "BLU_F";
        displayName = "TAG MBT";
        // 主炮塔：weapons[] 列出该炮塔能用的武器，magazines[] 对应每种弹药
        class Turrets
        {
            class MainTurret
            {
                isPersonTurret = 0;             // 无人/有人炮塔
                gunBeg = "gun_muzzle";          // 炮管起点 memory 点
                gunEnd = "gun_muzzle_end";      // 炮管终点 memory 点
                gunnerOutOpticsModel = "\A3\weapons_f\acc\acco2_2d.p3d"; // 占位
                memoryPointGunnerOptics = "eye";// 炮手光学 memory 点
                memoryPointGetWeaponDir = "gun_muzzle";  // 弹道方向判定点
                memoryPointsGetInGunner = "pos_gunner";
                // 载具武器挂进炮塔：与 CfgWeapons 的 TAG_VehCannon 对应
                weapons[] = {"TAG_VehCannon"};
                magazines[] = {"TAG_30Rnd_30mm_shells"};
                // 同轴机枪作为子炮塔
                class Turrets
                {
                    class CoaxialMG
                    {
                        isPersonTurret = 0;
                        gunBeg = "mg_muzzle";
                        gunEnd = "mg_muzzle_end";
                        memoryPointGunnerOptics = "eye";
                        memoryPointGetWeaponDir = "mg_muzzle";
                        memoryPointsGetInGunner = "pos_coax";
                        weapons[] = {"TAG_VehMG"};
                        magazines[] = {"TAG_200Rnd_762x51_shells"};
                    };
                };
            };
        };
    };
};

// 备注：
// - weapons[]/magazines[] 是成对的：数组里每个武器对应一个弹种，
//   顺序一致。多管炮/同轴机枪用子 Turrets 层层嵌套。
// - 开火方向由 gunBeg/gunEnd + memoryPointGetWeaponDir 决定，
//   canHit 遮挡判定依赖 memoryPointGetWeaponDir 在炮塔模型里存在。
// - 车载武器几乎复用士兵武器的 CfgWeapons 字段（MuzzlePos/muzzleFlash/
//   reload），差异在：1)用 VehicleWeapon 派生；2)memory 点位置在炮塔
//   模型而非士兵手臂握持模型；3)magazineName 单弹种 vs 士兵多弹匣。
// - AI 使用车载武器：AI 通过炮塔 turret 的单元自动索敌转向开火，
//   不需给 AI 单独配 CfgMoves 开火动画——车载武器动画是炮塔旋转 +
//   炮管后坐，配在模型动画源，不依赖士兵姿势动画。